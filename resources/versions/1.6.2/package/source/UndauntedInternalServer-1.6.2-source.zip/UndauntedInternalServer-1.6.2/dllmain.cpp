// Dauntless Forever - Dauntless 1.6.2 server DLL (UndauntedInternalServer)
// Copyright (C) 2026 Addison2k (port to this Dauntless build and all changes). https://github.com/addison2k/DauntlessForever
// Based on Undaunted, Copyright (C) gwog and contributors, https://github.com/SyST3MDeV/Undaunted
// Licence: AGPL-3.0-only (LICENSE-AGPL-3.0.txt). Keep this notice: the licence requires it.
#include <windows.h>
#include <clocale>
#include <shellapi.h>
#include <string>
#include <cstring>
#include <vector>
#include <thread>
#include <iostream>
#include <ranges>
#include <cwchar>
#include <map>
#include <set>
#include <mutex>
#include <atomic>
#include <unordered_map>

#include "framework.h"
#include "SDK.hpp"
#include "MinHook/MinHook.h"
#include "constants.h"
#include "Networking.h"

#include "SDK/GameplayAbilities_parameters.hpp"
#include "SDK/Archon_parameters.hpp"
#include "SDK/lantern_equipped_ab_parameters.hpp"

using namespace SDK;

namespace Globals {
    static bool AmServer = false;
    static uintptr_t BaseAddress = 0x0;
    bool Listening = false;
    bool DoListen = false;
    const wchar_t* ServerAPIKey = nullptr;
    const wchar_t* MapPath = nullptr;
    const wchar_t* BehemothPath = nullptr;
    const wchar_t* MatchmakerHuntId = nullptr;
    const wchar_t* ExpectedPlayerString = nullptr;
    int Port = 0;
    const wchar_t* MyIpAndPort = nullptr;
    std::wstring MetagameAddress;

    bool EnableLogging = true;
}

std::map<std::wstring, std::wstring> EndpointMap = {};
void EvalEndpointMap() {
    static bool DidEvalEndpointMap = false;

    if (DidEvalEndpointMap || Globals::MetagameAddress.size() == 0)
        return;

    DidEvalEndpointMap = true;

    EndpointMap = {
        {L"AuthEndpoint", L"http://" + Globals::MetagameAddress + L"/game/login"},
        {L"AuthAvailableEndpoint", L"http://" + Globals::MetagameAddress + L"/checkavailable"},
        {L"AuthTagsEndpoint", L"http://" + Globals::MetagameAddress + L"/tags"},
        {L"AccountInfoEndpoint", L"http://" + Globals::MetagameAddress + L"/accountinfo"},
        {L"DauntlessSessionTokenEndpoint", L"http://" + Globals::MetagameAddress + L"/gamesession/{linkedaccountservice}"},
        {L"CreatePhoenixAccountEndpoint", L"http://" + Globals::MetagameAddress + L"/account"},
        {L"LinkAccountEndpoint", L"http://" + Globals::MetagameAddress + L"/account/link"},
        {L"IsAccountLinkedEndpoint", L"http://" + Globals::MetagameAddress + L"/account/link/{service}/{accountid}"},
        {L"LinkPhoenixToServicePinGenerationEndpoint", L"http://" + Globals::MetagameAddress + L"/account/link/pin/{service}/generate"},
        {L"LinkPhoenixToServicePinStatusEndpoint", L"http://" + Globals::MetagameAddress + L"/account/link/pin/{service}/status"},
        {L"QueryLoginQueueEndpoint", L"http://" + Globals::MetagameAddress + L"/login"},
        {L"PublicAccountInfoEndpoint", L"http://" + Globals::MetagameAddress + L"/accountinfo/public"},
        {L"QueryAccountMappingsEndpoint", L"http://" + Globals::MetagameAddress + L"/account/mapping"},
        {L"PlayerDataMigrationEndpoint", L"http://" + Globals::MetagameAddress + L"/account/migrate"},
        {L"PhoenixEventsEndpoint", L"http://" + Globals::MetagameAddress + L"/event?id={environment}"},
        {L"PhoenixEventsMessageEndpoint", L"http://" + Globals::MetagameAddress + L"/services/T02H74TGF/B8GG4RATX/EGSR335K7as3GFBq4dPCm7js"},
        {L"CharacterEndpoint", L"http://" + Globals::MetagameAddress + L"/character"},
        {L"FindCharacterEndpoint", L"http://" + Globals::MetagameAddress + L"/character/{characterid}"},
        {L"CharacterNameEndpoint", L"http://" + Globals::MetagameAddress + L"/character/name"},
        {L"FindCharactersEndpoint", L"http://" + Globals::MetagameAddress + L"/character/batch/account"},
        {L"ResetCharacterEndpoint", L"http://" + Globals::MetagameAddress + L"/character"},
        {L"InventoryEndpoint", L"http://" + Globals::MetagameAddress + L"/inventory"},
        {L"InventoryGetAllEndpoint", L"http://" + Globals::MetagameAddress + L"/inventory/{accountid}/{characterid}"},
        {L"InventoryGetInstanceItemsEndpoint", L"http://" + Globals::MetagameAddress + L"/inventory/instanceditemsbyaccount"},
        {L"InventoryUpdateInstanceEndpoint", L"http://" + Globals::MetagameAddress + L"/inventory/instanceditem"},
        {L"InventoryMigrateEndpoint", L"http://" + Globals::MetagameAddress + L"/inventory/{characterid}/{gameversion}"},
        {L"DeleteProgressionEndpoint", L"http://" + Globals::MetagameAddress + L"/progression/{accountid}/{progressionid}"},
        {L"ProgressionEndpoint", L"http://" + Globals::MetagameAddress + L"/progression"},
        {L"ProgressionConfigEndpoint", L"http://" + Globals::MetagameAddress + L"/progression/config"},
        {L"FindProgressionEndpoint", L"http://" + Globals::MetagameAddress + L"/progression/{accountid}"},
        {L"FindProgressionTrackEndpoint", L"http://" + Globals::MetagameAddress + L"/progression/{accountid}/{progressionid}"},
        {L"FindObjectiveEndpoint", L"http://" + Globals::MetagameAddress + L"/progression/objectives/{accountid}/{objectiveid}"},
        {L"FindObjectivesEndpoint", L"http://" + Globals::MetagameAddress + L"/progression/objectives/{accountid}"},
        {L"GrantProgressionWithObjectives", L"http://" + Globals::MetagameAddress + L"/progression/{accountid}"},
        {L"GrantProgressionEndpoint", L"http://" + Globals::MetagameAddress + L"/progression/{accountid}/{progressionid}/{amount}"},
        {L"ConfirmProgressionEndpoint", L"http://" + Globals::MetagameAddress + L"/progression/{accountid}/{progressionid}/{rank}/confirm/{kind}"},
        {L"GetBountiesConfigEndpoint", L"http://" + Globals::MetagameAddress + L"/bounty/game-data"},
        {L"GetBountiesEndpoint", L"http://" + Globals::MetagameAddress + L"/bounty/{accountid}"},
        {L"SetBountiesEndpoint", L"http://" + Globals::MetagameAddress + L"/bounty/{accountid}"},
        {L"GetPlayerJourneyEndpointServer", L"http://" + Globals::MetagameAddress + L"/pjm/{accountid}"},
        {L"GetPlayerJourneyEndpointClient", L"http://" + Globals::MetagameAddress + L"/pjm"},
        {L"SetPlayerJourneyEndpoint", L"http://" + Globals::MetagameAddress + L"/pjm/{accountid}"},
        {L"GetPlayerFactionsEndpointClient", L"http://" + Globals::MetagameAddress + L"/factions/{season}"},
        {L"GetPlayerFactionsEndpointServer", L"http://" + Globals::MetagameAddress + L"/factions/{accountid}/{season}"},
        {L"SetPlayerFactionEndpoint", L"http://" + Globals::MetagameAddress + L"/factions/{accountid}/{season}/{faction}"},
        {L"GetTrialsLeaderboardsEndpoint", L"http://" + Globals::MetagameAddress + L"/trials/leaderboards"},
        {L"DeleteBountiesEndpoint", L"http://" + Globals::MetagameAddress + L"/bounty/delete/{accountid}"},
        {L"GetCooldownEndpoint", L"http://" + Globals::MetagameAddress + L"/cooldown/{accountid}"},
        {L"StartCooldownEndpoint", L"http://" + Globals::MetagameAddress + L"/cooldown/{accountid}/{cooldownid}"},
        {L"SetCooldownEndpoint", L"http://" + Globals::MetagameAddress + L"/cooldown/{accountid}"},
        {L"SetCooldownBatchEndpoint", L"http://" + Globals::MetagameAddress + L"/cooldown/batch/{accountid}"},
        {L"GetSeasonalEscalationEndpoint", L"http://" + Globals::MetagameAddress + L"/escalation/{season_id}/{account_id}"},
        {L"UpdateSeasonalEscalationEndpoint", L"http://" + Globals::MetagameAddress + L"/escalation/{season_id}/{account_id}"},
        {L"GameTuningEndpoint", L"http://" + Globals::MetagameAddress + L"/game_tuning/{blobid}"},
        {L"SelectedHuntPassEndpoint", L"http://" + Globals::MetagameAddress + L"/huntpass/{accountid}"},
        {L"TitleNewsEndpoint", L"http://" + Globals::MetagameAddress + L"/patcher-news/{environment}.json"},
        {L"LoginNewsEndpoint", L"http://" + Globals::MetagameAddress + L"/motd/"},
        {L"AfterHuntNewsEndpoint", L"http://" + Globals::MetagameAddress + L"/motd/trigger?event_name={eventname}"},
        {L"MailboxQueryEndpoint", L"http://" + Globals::MetagameAddress + L"/all/"},
        {L"MailboxQuerySurveyEndpoint", L"http://" + Globals::MetagameAddress + L"/survey/{surveyid}"},
        {L"MessageInboxReadEndpoint", L"http://" + Globals::MetagameAddress + L"/mailbox/markAsRead"},
        {L"MessageInboxDeletedEndpoint", L"http://" + Globals::MetagameAddress + L"/mailbox/markAsDeleted"},
        {L"MessageInboxClaimItemEndpoint", L"http://" + Globals::MetagameAddress + L"/mailbox/redeemParcel"},
        {L"MailboxSubmitSurveyEndpoint", L"http://" + Globals::MetagameAddress + L"/survey/responses"},
        {L"MailboxClaimSurveyRewardEndpoint", L"http://" + Globals::MetagameAddress + L"/survey/redeemReward"},
        {L"MailboxSurveyEndpoint", L"http://" + Globals::MetagameAddress + L"/survey"},
        {L"ExperimentalRealmValidationEndpoint", L"http://" + Globals::MetagameAddress + L"/experiment/validate"},
        {L"SanitizeEndpoint", L"http://" + Globals::MetagameAddress + L"/check"},
        {L"GuildEndpoint", L"http://" + Globals::MetagameAddress + L"/guild"},
        {L"GuildInvitesEndpoint", L"http://" + Globals::MetagameAddress + L"/guild/invites"},
        {L"FindGuildEndpoint", L"http://" + Globals::MetagameAddress + L"/guild/{guildid}"},
        {L"FindCharactersGuildEndpoint", L"http://" + Globals::MetagameAddress + L"/guild/member/{characterid}"},
        {L"GuildMemberEndpoint", L"http://" + Globals::MetagameAddress + L"/guild/member"},
        {L"GuildInviteEndpoint", L"http://" + Globals::MetagameAddress + L"/guild/invite"},
        {L"GuildViewCharacterInviteEndpoint", L"http://" + Globals::MetagameAddress + L"/guild/invite/member/{characterid}"},
        {L"GuildAcceptInviteEndpoint", L"http://" + Globals::MetagameAddress + L"/guild/invite/accept"},
        {L"GuildViewGuildInviteEndpoint", L"http://" + Globals::MetagameAddress + L"/guild/invite/guild"},
        {L"GuildLeaderEndpoint", L"http://" + Globals::MetagameAddress + L"/guild/leader"},
        {L"GuildCreateValidateEndpoint_v2", L"http://" + Globals::MetagameAddress + L"/guild/validate"},
        {L"GuildEndpoint_v2", L"http://" + Globals::MetagameAddress + L"/guild"},
        {L"GuildDisbandEndpoint_v2", L"http://" + Globals::MetagameAddress + L"/guild/{guildId}"},
        {L"GuildViewInvitesEndpoint_v2", L"http://" + Globals::MetagameAddress + L"/guild/invite/player"},
        {L"GuildInviteEndpoint_v2", L"http://" + Globals::MetagameAddress + L"/guild/invite/{accountId}"},
        {L"GuildInviteAcceptEndpoint_v2", L"http://" + Globals::MetagameAddress + L"/guild/invite/accept/{guild_invite_id}"},
        {L"GuildInviteDeclineEndpoint_v2", L"http://" + Globals::MetagameAddress + L"/guild/invite/{guild_invite_id}"},
        {L"GuildLeaveEndpoint_v2", L"http://" + Globals::MetagameAddress + L"/guild/player"},
        {L"GuildKickEndpoint_v2", L"http://" + Globals::MetagameAddress + L"/guild/player/{accountId}"},
        {L"GuildChangeRankEndpoint_v2", L"http://" + Globals::MetagameAddress + L"/guild/rank/{accountId}/{rank}"},
        {L"PartyEndpoint", L"http://" + Globals::MetagameAddress + L"/party"},
        {L"PartyStatusEndpoint", L"http://" + Globals::MetagameAddress + L"/party/status"},
        {L"PartyMemberEndpoint", L"http://" + Globals::MetagameAddress + L"/party/member"},
        {L"PartyKickMemberEndpoint", L"http://" + Globals::MetagameAddress + L"/party/member/{memberid}"},
        {L"PartyRemoveOfflineLeaderEndpoint", L"http://" + Globals::MetagameAddress + L"/party/leader/{leaderid}"},
        {L"PartyPromoteEndpoint", L"http://" + Globals::MetagameAddress + L"/party/member/promote/{memberId}"},
        {L"PartyInvitesEndpoint", L"http://" + Globals::MetagameAddress + L"/party/invites"},
        {L"PartyInviteEndpoint", L"http://" + Globals::MetagameAddress + L"/party/invite"},
        {L"PartyAcceptInviteEndpoint", L"http://" + Globals::MetagameAddress + L"/party/invite/accept/{inviteId}"},
        {L"PartyMemberSetConsoleSessionEndpoint", L"http://" + Globals::MetagameAddress + L"/party/console_session"},
        {L"PartyFinderCreateEndpoint", L"http://" + Globals::MetagameAddress + L"/party/finder/entry/create"},
        {L"PartyFinderEntryEndpoint", L"http://" + Globals::MetagameAddress + L"/party/finder/entry/{partyId}"},
        {L"PartyFinderJoinEndpoint", L"http://" + Globals::MetagameAddress + L"/party/finder/join/{partyId}"},
        {L"PartyFinderListEntriesEndpoint", L"http://" + Globals::MetagameAddress + L"/party/finder/entries"},
        {L"ExpectedPlayerStatusEndpoint", L"http://" + Globals::MetagameAddress + L"/candidate/player/alive"},
        {L"KeepAlivePlayerStatusEndpoint", L"http://" + Globals::MetagameAddress + L"/candidate/player/alive"},
        {L"StoreEndpointDev", L"http://" + Globals::MetagameAddress + L"/{tracking}#{path}"},
        {L"StoreEndpoint", L"http://" + Globals::MetagameAddress + L"/{tracking}#{path}"},
        {L"StoreInternationalEndpointDev", L"http://" + Globals::MetagameAddress + L"/{locale}/{tracking}#{path}"},
        {L"StoreInternationalEndpoint", L"http://" + Globals::MetagameAddress + L"/{locale}/{tracking}#{path}"},
        {L"StoreGetItemByTagEndpoint", L"http://" + Globals::MetagameAddress + L"/product/skus/public?requiredTags={tag}"},
        {L"StoreGetItemByIdEndpoint", L"http://" + Globals::MetagameAddress + L"/product/sku/{sku_id}"},
        {L"StorePurchaseItemEndpoint", L"http://" + Globals::MetagameAddress + L"/token/{currency}/{sku_id}"},
        {L"StorePurchaseItemConfirmEndpoint", L"http://" + Globals::MetagameAddress + L"/notification/{currency}?token={purchase_token}"},
        {L"StoreReconcileUrl", L"http://" + Globals::MetagameAddress + L"/reconcile"},
        {L"StoreBalancesEndpoint", L"http://" + Globals::MetagameAddress + L"/balance"},
        {L"SupportACreatorEndpoint", L"http://" + Globals::MetagameAddress + L"/creator"},
        {L"EntitlementsEndpoint", L"http://" + Globals::MetagameAddress + L"/entitlementsv2"},
        {L"GrantEntitlementEndpoint", L"http://" + Globals::MetagameAddress + L"/entitlementv2/{accountid}"},
        {L"RevokeEntitlementEndpoint", L"http://" + Globals::MetagameAddress + L"/entitlement/{accountid}/{entitlement}"},
        {L"ServiceSessionEndpoint", L"http://" + Globals::MetagameAddress + L"/ws/{accountid}"},
        {L"QueryUserPresenceEndpoint", L"http://" + Globals::MetagameAddress + L"/present/{accountid}"},
        {L"MatchmakingEndpoint", L"http://" + Globals::MetagameAddress},
        {L"TrackingEndpoint", L"http://" + Globals::MetagameAddress},
        {L"VoiceChatLoginEndpoint", L"http://" + Globals::MetagameAddress + L"/vivox/login"},
        {L"VoiceChatJoinPartyEndpoint", L"http://" + Globals::MetagameAddress + L"/vivox/join/party/{channel_type}"},
        {L"VoiceChatJoinGameEndpoint", L"http://" + Globals::MetagameAddress + L"/vivox/join/game/{game_id}/{channel_type}"},
        {L"VoiceChatJoinDebugEndpoint", L"http://" + Globals::MetagameAddress + L"/vivox/join/channel/{channel_id}/{channel_type}"},
        {L"PlatformPoolRegistrationEndpoint", L"http://" + Globals::MetagameAddress + L"/candidate/player/register"},
        {L"CheckCrossPlayProgressionEndpoint", L"http://" + Globals::MetagameAddress + L"/features/platform/{platform}"},
        {L"LeaderboardDisplayNameRefreshEndpoint", L"http://" + Globals::MetagameAddress + L"/profile/update"},
        {L"PhoenixStatusMessageEndpoint", L"http://" + Globals::MetagameAddress + L"/dauntless-status"},
        {L"TrialsLeaderboardsEndpoint", L"http://" + Globals::MetagameAddress + L"/trials/leaderboards"},
        {L"TrialsSoloLeaderboardsEndpoint", L"http://" + Globals::MetagameAddress + L"/trials/leaderboards/solo"},
        {L"TrialsSoloEntryEndpoint", L"http://" + Globals::MetagameAddress + L"/trials/leaderboards/solo/individual"},
        {L"TrialsGroupLeaderboardsEndpoint", L"http://" + Globals::MetagameAddress + L"/trials/leaderboards/group"},
        {L"TrialsGroupEntryEndpoint", L"http://" + Globals::MetagameAddress + L"/trials/leaderboards/group/individual"},
        {L"GetActiveLoadoutEndpoint", L"http://" + Globals::MetagameAddress + L"/loadout/{account_id}/{character_id}"},
        {L"GetAllLoadoutsEndpoint", L"http://" + Globals::MetagameAddress + L"/loadout/{account_id}/{character_id}/all"},
        {L"UpdateLoadoutSlotEndpoint", L"http://" + Globals::MetagameAddress + L"/loadout/{account_id}/{character_id}/{index}"},
        {L"UpdateLoadoutSlotSetActiveEndpoint", L"http://" + Globals::MetagameAddress + L"/loadout/{account_id}/{character_id}/active/{index}"},
        {L"UpdateLoadoutPersistentEndpoint", L"http://" + Globals::MetagameAddress + L"/loadout/{account_id}/{character_id}/persistent"},
        {L"UpdateActiveLoadoutSlotEndpoint", L"http://" + Globals::MetagameAddress + L"/loadout/{account_id}/{character_id}/active/{index}"},
        {L"UnlockAccountSlotEndpoint", L"http://" + Globals::MetagameAddress + L"/loadout/{account_id}/unlock/{num_slots}"},
        {L"UnlockCharacterSlotEndpoint", L"http://" + Globals::MetagameAddress + L"/loadout/{account_id}/{character_id}/unlock/{num_slots}"},
        {L"GetAccountSlotCountEndpoint", L"http://" + Globals::MetagameAddress + L"/loadout/{account_id}/slotcount"},
        {L"GetCharacterSlotCountEndpoint", L"http://" + Globals::MetagameAddress + L"/loadout/{account_id}/{character_id}/slotcount"},
        {L"PlayerInboxMessageEndpoint", L"http://" + Globals::MetagameAddress + L"/subscription"},
        {L"PlayerNewsletterSubscribeEndpoint", L"http://" + Globals::MetagameAddress + L"/subscription"},
        {L"PlayerNewsletterResendEndpoint", L"http://" + Globals::MetagameAddress + L"/subscription/verify/resend"},
        {L"BreadcrumbPlayerEndpoint", L"http://" + Globals::MetagameAddress + L"/breadcrumbs/{character_id}"},
        {L"EncounteredContentGetEndpoint", L"http://" + Globals::MetagameAddress + L"/encountered-content/{character_id}/{content_type}"},
        {L"EncounteredContentQueryEndpoint", L"http://" + Globals::MetagameAddress + L"/encountered-content/query/{character_id}"},
        {L"EncounteredContentUpdateEndpoint", L"http://" + Globals::MetagameAddress + L"/encountered-content/{character_id}"},
        {L"CohortsEndpoint", L"http://" + Globals::MetagameAddress + L"/playertreatments/{account_id}"},
        {L"GetEventStatsEndpoint", L"http://" + Globals::MetagameAddress + L"/eventstats/"},
        {L"IncrementEventStatsEndpoint", L"http://" + Globals::MetagameAddress + L"/eventstats/increment"},
        {L"LinkedSlayersInviteEndpoint", L"http://" + Globals::MetagameAddress + L"/slayerlink/invite"},
        {L"LinkedSlayersAllInvitesEndpoint", L"http://" + Globals::MetagameAddress + L"/slayerlink/invites"},
        {L"LinkedSlayersInviteAcceptDeclineEndpoint", L"http://" + Globals::MetagameAddress + L"/slayerlink/invite"},
        {L"LinkedSlayersInviteCancelEndpoint", L"http://" + Globals::MetagameAddress + L"/slayerlink/invite"},
        {L"LinkedSlayersDeleteAllInvitesEndpoint", L"http://" + Globals::MetagameAddress + L"/slayerlink/invites/{account_id}"},
        {L"LinkedSlayersAllLinksProgressEndpoint", L"http://" + Globals::MetagameAddress + L"/slayerlink/progress"},
        {L"LinkedSlayersAddLinkProgressEndpoint", L"http://" + Globals::MetagameAddress + L"/slayerlink/progress"},
        {L"LinkedSlayersAllLinkSlotsDataEndpoint", L"http://" + Globals::MetagameAddress + L"/slayerlink/links"},
        {L"LinkedSlayersDeleteInviteDataEndpoint", L"http://" + Globals::MetagameAddress + L"/slayerlink/link"},
        {L"LinkedSlayersSendRewardsEndpoint", L"http://" + Globals::MetagameAddress + L"/slayerlink/links/rewards"},
        {L"LinkedSlayersGetFriendsAvailabilityEndpoint", L"http://" + Globals::MetagameAddress + L"/slayerlink/availability"},
        {L"LinkedSlayersGetRewardsGrantEndpoint", L"http://" + Globals::MetagameAddress + L"/slayerlink/links/rewards/{account_id}/{slot}"},
        {L"LinkedSlayersSetEndTimeEndpoint", L"http://" + Globals::MetagameAddress + L"/slayerlink/links/endtime"},
        {L"LinkedSlayersSetRemainingTimeEndpoint", L"http://" + Globals::MetagameAddress + L"/slayerlink/links/timeleft"},
        {L"LinkedSlayersStatusEndpoint", L"http://" + Globals::MetagameAddress + L"/slayerlink/status_good"},
        {L"AccountCheckpointDebugEndpoint", L"http://" + Globals::MetagameAddress + L"/checkpoint/account/save"},
    };
}


__declspec(dllexport) const char* DummyLinkFunc() {
    return "mrow :3";
}

void ResolveEyeGlowToggleHideName();

void MainThread() {
    while (!UWorld::GetWorld()) {
        if (Globals::AmServer) {
            Sleep(1000);
        }
        else {
            Sleep(1);
        }
    }

    Sleep(3 * 1000);

    if (!Globals::AmServer) {
        UEngine* Engine = UEngine::GetEngine();

        UInputSettings::GetDefaultObj()->ConsoleKeys[0].KeyName = UKismetStringLibrary::Conv_StringToName(L"F2");

        UObject* NewObject = UGameplayStatics::SpawnObject(Engine->ConsoleClass, Engine->GameViewport);

        Engine->GameViewport->ViewportConsole = static_cast<UConsole*>(NewObject);

        if (Globals::EnableLogging)
            std::cout << "Spawned UConsole!" << std::endl;

        // [1.6.2 port] Master's Hat eye glow: name id of the blueprint function ToggleHide (see EyeGlowProcessEventHook)
        ResolveEyeGlowToggleHideName();
    }
    else {
        if (Globals::EnableLogging)
            std::cout << "UWorld is live!" << std::endl;

        Globals::DoListen = true;
    }
}

void* OrigGetDefaultMap = nullptr;

FString* GetGameDefaultMap(FString* a1) {
    FString* Ret = reinterpret_cast<FString * (*)(FString*)>(OrigGetDefaultMap)(a1);

    std::wstring FinalURL(Globals::MapPath);

    std::wstring BehemothPath(Globals::BehemothPath);

    if (!BehemothPath.contains(L"NO_BEHEMOTH")) {
        FinalURL += std::wstring(L"?MonsterClass=");
        FinalURL += std::wstring(BehemothPath);
    }

    std::wstring MatchmakerHuntId(Globals::MatchmakerHuntId);

    if (!MatchmakerHuntId.contains(L"NO_MM_HUNTID")) {
        FinalURL += std::wstring(L"?HuntId=");
        FinalURL += std::wstring(MatchmakerHuntId);
    }

    std::wstring ExpectedPlayers(Globals::ExpectedPlayerString);

    if (!ExpectedPlayers.contains(L"NO_EXPECTED_PLAYERS")) {
        FinalURL += std::wstring(L"?PlayerHuntIds=");
        FinalURL += std::wstring(ExpectedPlayers);
    }

    *Ret = FinalURL.c_str();

    //*Ret = L"ramsgate_01_persistent?game=/Game/Blueprints/BPGM_Archon_Prototype.BPGM_Archon_Prototype_C?MonsterClass=/Game/Monsters/mcrollin/mcbeaver_tutorial_bp.mcbeaver_tutorial_bp_C";

    //*Ret = L"/Game/Maps/islands/1705/dia_moss_triforce?MonsterClass=/Game/Monsters/mcrollin/mcbeaver_tutorial_bp.mcbeaver_tutorial_bp_C";
    //*Ret = L"/Game/Maps/islands/1705/dia_snow_big?MonsterClass=/Game/Monsters/mcrollin/mcbeaver_tutorial_bp.mcbeaver_tutorial_bp_C?HuntId=CR19_MatchmakerHunt_Beaver?PlayerHuntIds=GWOG-UID-1:CR19_PlayerHunt_Expedition_Island04,GWOG-UID-2:CR19_PlayerHunt_Expedition_Island04,GWOG-UID-3:CR19_PlayerHunt_Expedition_Island04?ZonePreset=0";
    //*Ret = L"/Game/Maps/ramsgate/ramsgate_01_persistent";
    //*Ret = L"/Game/Maps/islands/dojo/training_dojo_persistent";
    //*Ret = L"/Game/Maps/islands/1705/dia_moss_triforce?MonsterClass=/Game/Monsters/mcrollin/mcbeaver_tutorial_bp.mcbeaver_tutorial_bp_C";

    return Ret;
}

void* OrigGetCommandLine = nullptr;

const wchar_t* GetCommandLineHook() {
    // [Dauntless Forever] Server copies run on the player's PC. -CULTURE=en-US keeps the engine's number parsing on a
    // decimal point whatever the Windows region (decimal-comma regions broke part breaks: stage NONE, no sever, no loot).
    // This hook replaces the real command line, so the flag has to live here, not in the deploy server's arguments.
    return L"Dauntless-Win64-Shipping.exe -server -unattended -nullrhi -nosound -EpicPortal -RepDriverDisable -CULTURE=en-US";
}

void* OrigServerBootCrash = nullptr;

void ServerBootCrash() {
    return;
}

void* OrigEncounterableSetup = nullptr;

void EncounterableSetupHook() {
    return;
}

float TotalNoPlayersTime = 0.0f;

bool EnableWatchdog = true;
#include "ObjectivePriming.inl"
void* OrigGameEngineTick = nullptr;

void GameEngineTickHook(UGameEngine* GameEngine, float DeltaTime, char CanRender) {
    reinterpret_cast<void(*)(UGameEngine*, float, char)>(OrigGameEngineTick)(GameEngine, DeltaTime, CanRender);

    if (Globals::Listening) {
        Networking::TickNetworking();
    }

    if (Globals::DoListen) {
        Globals::DoListen = false;
        Networking::Listen(UEngine::GetEngine(), Globals::Port);

        Globals::Listening = true;
    }

    if (Globals::Listening && Networking::NetDriver) {
        TickObjectivePriming(DeltaTime);
        bool HasConnection = false;

        for (UNetConnection* Connection : Networking::NetDriver->ClientConnections) {
            if (!Connection->OwningActor || *(uint32_t*)((uintptr_t)Connection + 0x134) != 3)
                continue;

            HasConnection = true;
        }

        if (EnableWatchdog) {
            if (!HasConnection) {
                TotalNoPlayersTime += DeltaTime;

                if (TotalNoPlayersTime >= 50.0f) {
                    exit(0);
                }
            }
        }

        for (UNetConnection* Conn : Networking::NetDriver->ClientConnections) {
            if (Conn->PlayerController && Conn->PlayerController->Pawn) {
                ((ABP_PlayerCharacter_C*)Conn->PlayerController->Pawn)->TickStamina(ECityExecFilter::Both, ERemoteExecFilter::All); // TODO: Risky cast, but IsA brutalizes our speed
            }
        }
    }
}

void* OrigFixupNetworkNotify = nullptr;

void* FixupNetworkNotifyHook(void* a1) {
    if (UWorld::GetWorld())
        *(void**)((uintptr_t)a1 + 0x208) = &UWorld::GetWorld()->NetworkNotify;

    return reinterpret_cast<void* (*)(void*)>(OrigFixupNetworkNotify)(a1);
}

void* OrigProcessRequest = nullptr;

char ProcessRequest(void* Request) {
    FString APIHeader(L"x-undaunted-gameserver-apikey");
    FString APIKey(Globals::ServerAPIKey);

    reinterpret_cast<void(*)(void*, FString*, FString*)>(Globals::BaseAddress + 0x2A64080)(Request, &APIHeader, &APIKey);

    return reinterpret_cast<char(*)(void*)>(OrigProcessRequest)(Request);
}

enum EFunctionCallspace : uint32_t
{
    /** This function call should be absorbed (ie client side with no authority) */
    Absorbed = 0x0,
    /** This function call should be called remotely via its net driver */
    Remote = 0x1,
    /** This function call should be called locally */
    Local = 0x2
};

void* OrigGetActorCallspace = nullptr;

EFunctionCallspace GetActorCallspace(AActor* Actor, UFunction* Function, void* Stack) {
    if (Function->GetFullName().contains("Ammo")) {
        std::cout << Actor->GetFullName() << " - " << Function->GetFullName() << std::endl;
    }

    return reinterpret_cast<EFunctionCallspace(*)(AActor*, UFunction*, void*)>(OrigGetActorCallspace)(Actor, Function, Stack);
}

void* OrigPostLogin = nullptr;

void PostLoginHook(void* a1, AArchonPlayerController* a2) {
    reinterpret_cast<void(*)(void*, void*)>(OrigPostLogin)(a1, a2);
}

void* OrigHasFinishedLoading = nullptr;

bool HasFinishedLoadingHook(UObject* a1) {
    bool Ret = reinterpret_cast<bool(*)(UObject*)>(OrigHasFinishedLoading)(a1);

    if (!Ret) {
        // [Dauntless Forever] a1 is the controller's loading INTERFACE (a pointer into the controller, not the start of
        // a UObject), so a1->GetFullName() read garbage and crashed players whose loading was slower (seen on a friend
        // joining through the VPS relay: access violation reading 0x19). Only log that it happened, a few times.
        static int ForceReadyLogged = 0;
        if (Globals::EnableLogging && ForceReadyLogged < 5) {
            ++ForceReadyLogged;
            std::cout << "[FORCEREADY] player was not finished loading; marked ready" << std::endl;
        }
        return true;
    }

    return Ret;
}

void* OrigIsNetReady = nullptr;

bool IsNetReadyHook() {
    return true;
}

void* OrigSetReplicationDriver = nullptr;

void SetReplicationDriverHook(UNetDriver* NetDriver, UReplicationDriver* RepDriver) {
    return reinterpret_cast<void(*)(UNetDriver*, UReplicationDriver*)>(OrigSetReplicationDriver)(NetDriver, nullptr);
}

void* OrigGetNetDriverInternal = nullptr;

UNetDriver* GetNetDriverInternalHook(void* a1, void* a2) {
    UNetDriver* NetDriver = reinterpret_cast<UNetDriver * (*)(void*, void*)>(OrigGetNetDriverInternal)(a1, a2);

    if (!NetDriver) {
        NetDriver = Networking::NetDriver;
    }

    return NetDriver;
}

void* OrigIsLevelInitForActor = nullptr;

bool IsLevelInitForActorHook(void* a1, char a2) {
    bool NetDriver = reinterpret_cast<bool (*)(void*, char)>(OrigIsLevelInitForActor)(a1, a2);

    if (!NetDriver) {
        return true;
    }

    return NetDriver;
}

void* OrigGetStartSpot = nullptr;

APlayerStart* GetStartSpotHook(void* a1, void* a2, void* a3) {
    for (int i = 0; i < SDK::UObject::GObjects->Num(); i++)
    {
        SDK::UObject* Obj = SDK::UObject::GObjects->GetByIndex(i);

        if (!Obj)
            continue;

        if (Obj->IsDefaultObject())
            continue;

        if (Obj->IsA(SDK::APlayerStart::StaticClass()))
        {
            return (APlayerStart*)Obj;
        }
    }

    if (Globals::EnableLogging)
        std::cout << "No startspot found!" << std::endl;

    return nullptr;
}

bool ServerTryActivateAbilityInternal(UAbilitySystemComponent* Component, FGameplayAbilitySpecHandle& AbilityHandle, bool InputPressed, FPredictionKey& PredictionKey, FGameplayEventData* TriggerEventData) {
    if (InputPressed)
        Component->ServerSetInputPressed(AbilityHandle);

    void* InstancedAbility = nullptr;

    bool Activated = reinterpret_cast<bool(*)(UAbilitySystemComponent*, uint32_t, FPredictionKey*, void**, void*, FGameplayEventData*)>(Globals::BaseAddress + 0x1132110)(Component, AbilityHandle.Handle, &PredictionKey, &InstancedAbility, nullptr, TriggerEventData);

    if (!Activated && InputPressed)
        Component->ServerSetInputReleased(AbilityHandle);

    return Activated;
}

void* OrigMakeDoDamage = nullptr;

bool MakeDoDamageHook(void* a1, void* a2, void* a3) {
    *(uint8_t*)((uintptr_t)a1 + 0x57C) = 1;

    return true;
}

#include <fstream>

void* OrigProcessEventClient = nullptr;

void ProcessEventClientHook(UObject* Object, UFunction* Function, void* Parms) {
    if (GetAsyncKeyState(VK_F7)) {
        for (int i = 0; i < SDK::UObject::GObjects->Num(); i++)
        {
            SDK::UObject* Obj = SDK::UObject::GObjects->GetByIndex(i);

            if (!Obj)
                continue;

            if (Obj->IsA(SDK::UArenaMapHuntsFeature::StaticClass()))
            {
                UArenaMapHuntsFeature* Quest = (UArenaMapHuntsFeature*)Obj;

                std::cout << Quest->bEnabled << std::endl;
            }
        }

        while (GetAsyncKeyState(VK_F7)) {

        }
    }

    reinterpret_cast<void(*)(UObject*, UFunction*, void*)>(OrigProcessEventClient)(Object, Function, Parms);
}

static int NumTimesOnAirshipUpdated = 0;
bool DidDoTravelReset = false;

void* OrigProcessEvent = nullptr;

void ProcessEventHook(UObject* Object, UFunction* Function, void* Parms) {
    static UFunction* ServerTryActivateAbilityWithEventData = nullptr;
    static UFunction* ServerTryActivateAbility = nullptr;

    if (Function == ServerTryActivateAbilityWithEventData || (!ServerTryActivateAbilityWithEventData && Function->GetFullName().contains("ServerTryActivateAbilityWithEventData"))) {
        ServerTryActivateAbilityWithEventData = Function;

        Params::AbilitySystemComponent_ServerTryActivateAbilityWithEventData* ActivateAbilityParams = (Params::AbilitySystemComponent_ServerTryActivateAbilityWithEventData*)Parms;

        ServerTryActivateAbilityInternal((UAbilitySystemComponent*)Object, ActivateAbilityParams->AbilityToActivate, ActivateAbilityParams->InputPressed, ActivateAbilityParams->PredictionKey, &ActivateAbilityParams->TriggerEventData);
    }
    else if (Function == ServerTryActivateAbility || (!ServerTryActivateAbility && Function->GetFullName().contains("ServerTryActivateAbility"))) {
        ServerTryActivateAbility = Function;

        Params::AbilitySystemComponent_ServerTryActivateAbility* ActivateAbilityParams = (Params::AbilitySystemComponent_ServerTryActivateAbility*)Parms;

        ServerTryActivateAbilityInternal((UAbilitySystemComponent*)Object, ActivateAbilityParams->AbilityToActivate, ActivateAbilityParams->InputPressed, ActivateAbilityParams->PredictionKey, nullptr);
    }

    reinterpret_cast<void(*)(UObject*, UFunction*, void*)>(OrigProcessEvent)(Object, Function, Parms);
}

void* OrigConfigCacheIniGetString = nullptr;

bool ConfigCacheInitGetStringHook(void* a1, const wchar_t* Section, const wchar_t* Key, FString* Value, FString* Filename) {
    EvalEndpointMap();

    if (EndpointMap.contains(Key)) {
        *Value = FString(EndpointMap.at(Key).c_str());

        return true;
    }

    if (std::wstring(Section).contains(L"Mcp")) {
        if (std::wstring(Key).contains(L"protocol") || std::wstring(Key).contains(L"Protocol")) {
            *Value = FString(L"http");

            return true;
        }

        if (std::wstring(Key).contains(L"Domain") || std::wstring(Key).contains(L"RedirectUrl")) {
            *Value = FString(Globals::MetagameAddress.c_str());

            return true;
        }
    }

    return reinterpret_cast<bool(*)(void* a1, const wchar_t* Section, const wchar_t* Key, FString * Value, FString * Filename)>(OrigConfigCacheIniGetString)(a1, Section, Key, Value, Filename);
}

void* OrigGetEscalationSeason = nullptr;

bool GetEscalationSeason(UHuntCatalog* a1, FString* HuntID, FHunt_UnlockInfo* UnlockInfo, FHunt_UnlockInfo* AltUnlockInfo, AArchonPlayerController* PC) { // TODO: Fixup scheduling & Player leveling so this hack isn't necessary
    if (HuntID->ToString().contains("Arena") || (HuntID->ToString().contains("Esca") && !HuntID->ToString().contains("Mint"))) {
        return true;
    }

    return reinterpret_cast<bool(*)(UHuntCatalog * a1, FString * HuntID, FHunt_UnlockInfo * UnlockInfo, FHunt_UnlockInfo * AltUnlockInfo, AArchonPlayerController * PC)>(OrigGetEscalationSeason)(a1, HuntID, UnlockInfo, AltUnlockInfo, PC);
}

void* OrigGetTrackProgress = nullptr;

__int64 GetTrackProgress(void* a1, FName* a2, void* a3) {
    if (a2) {
        std::cout << a2->ToString() << std::endl;
    }

    return 9999999;
}

//__int64 *__fastcall sub_141428060(__int64 a1, __int64 *a2, unsigned __int8 a3, char a4)
// Guard: UImage::SetBrushFromTexture (1.6.2 RVA 0x2FEC910)
// An empty platform name makes a widget pass a garbage texture pointer, which crashes on entering Ramsgate.
void* OrigSetBrushFromTexture = nullptr;

static bool LooksLikeValidPtr(void* p)
{
    auto a = reinterpret_cast<uintptr_t>(p);
    if (a < 0x10000 || a > 0x00007FFFFFFEFFFFull) return false;
    MEMORY_BASIC_INFORMATION mbi{};
    if (!VirtualQuery(p, &mbi, sizeof(mbi)) || mbi.State != MEM_COMMIT) return false;
    if (mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS)) return false;
    return true;
}

static bool IsLiveUObject(void* p)
{
    if (!LooksLikeValidPtr(p) || !LooksLikeValidPtr((uint8_t*)p + 0x28)) return false;
    auto* Obj = reinterpret_cast<SDK::UObject*>(p);
    return SDK::UObject::GObjects->GetByIndex(Obj->Index) == Obj;
}

void SetBrushFromTextureHook(void* Image, void* Texture, bool bMatchSize)
{
    if (Texture && !IsLiveUObject(Texture))
    {
        uintptr_t CallerRva = (uintptr_t)_ReturnAddress() - Globals::BaseAddress;
        std::cout << "[Guard] SetBrushFromTexture: bad texture " << Texture
            << " from caller RVA 0x" << std::hex << CallerRva << std::dec << std::endl;
        Texture = nullptr;
    }
    reinterpret_cast<void(*)(void*, void*, bool)>(OrigSetBrushFromTexture)(Image, Texture, bMatchSize);
}

// ===== [1.6.2 port] Hunt Pass Elite: own the premium gate ================================
// UEntitlementsComponent::HasEntitlement (1.6.2 RVA 0x14B3DB0): bool (UEntitlementsComponent*, FString Name).
// The FString is passed by value (as a pointer to a temporary) and the function frees it before returning,
// so the name is copied first and the original always runs.
// The Elite row of the Hunt Pass stays locked unless the player owns the pass's gating entitlement, and the
// entitlement reply from the metagame does not get there. Names ending in "_premium" (the Elite pass gates,
// e.g. season13a_premium) therefore count as owned. Everything else (Patron, VIP, boosts, ...) is untouched.
// Each distinct name is logged once: "[1.6.2 port] HasEntitlement(<name>) = <game's answer> -> <answer given>".

static void* OrigHasEntitlement = nullptr;
static std::mutex EntitlementLogMutex;
static std::set<std::wstring> LoggedEntitlementNames;

static std::wstring CopyFStringRaw(const void* Str) {
    // FString layout: wchar_t* Data @0x0, int32 Num @0x8 (includes the terminator), int32 Max @0xC
    if (!Str || !LooksLikeValidPtr(const_cast<void*>(Str))) return L"";
    const wchar_t* Data = *reinterpret_cast<wchar_t* const*>(Str);
    const int32_t Num = *reinterpret_cast<const int32_t*>(reinterpret_cast<const uint8_t*>(Str) + 0x8);
    if (!Data || Num <= 1 || Num > 1024 || !LooksLikeValidPtr(const_cast<wchar_t*>(Data))) return L"";
    return std::wstring(Data, Num - 1);
}

bool HasEntitlementHook(void* Component, void* Name) {
    const std::wstring Wanted = CopyFStringRaw(Name);   // before the original frees it
    const bool Owned = reinterpret_cast<bool(*)(void*, void*)>(OrigHasEntitlement)(Component, Name);

    bool Result = Owned;
    const std::wstring Suffix = L"_premium";
    if (!Owned && Wanted.size() > Suffix.size() && Wanted.compare(Wanted.size() - Suffix.size(), Suffix.size(), Suffix) == 0) {
        Result = true;
    }

    if (Globals::EnableLogging) {
        std::lock_guard<std::mutex> Lock(EntitlementLogMutex);
        if (LoggedEntitlementNames.insert(Wanted).second) {
            // Narrow copy for std::cout (mixing wcout and cout on the redirected stdout can drop output)
            std::string NameA;
            for (wchar_t c : Wanted) NameA += (c >= 32 && c < 127) ? static_cast<char>(c) : '?';
            std::cout << "[1.6.2 port] HasEntitlement(" << (NameA.empty() ? "<empty>" : NameA) << ") = "
                << (Owned ? "true" : "false") << " -> " << (Result ? "true" : "false") << std::endl;
        }
    }
    return Result;
}
// =========================================================================================

// ===== [cell-exchange] Cell fusion: unlock exchange slots 2 and 3 ========================
// ArchonInventory::IsExchangeSlotLocked (1.6.2 RVA 0x15BF660): bool (UArchonInventory*, int32 SlotID).
// Slot 1 is never locked. For other slots the game scans PlayerState.Entitlements (offset 0x538) for
// "exchange_slot_<N>" (FUN_1416eba70, a plain name compare). That array is never filled on our server
// (the Hunt Pass Elite works only via HasEntitlementHook), so slots 2 and 3 stay locked. Always unlocked.
// Each slot is logged once: "[cell-exchange] IsExchangeSlotLocked(<N>) -> false".

static void* OrigIsExchangeSlotLocked = nullptr;

bool IsExchangeSlotLockedHook(void* Inventory, int SlotID) {
    static bool Logged[8] = {};
    if (Globals::EnableLogging && SlotID >= 0 && SlotID < 8 && !Logged[SlotID]) {
        Logged[SlotID] = true;
        std::cout << "[cell-exchange] IsExchangeSlotLocked(" << SlotID << ") -> false" << std::endl;
    }
    return false;
}
// =========================================================================================

// ===== [Dauntless Forever] No Easy Anti-Cheat / Phoenix Labs welcome pop-ups (client) =====
// 1. FEasyAntiCheatClient::LoadEACLibrary (1.6.2 RVA 0xF5E7D0): bool (FEasyAntiCheatClient*, const FString& Path).
//    Easy Anti-Cheat is not installed offline, so it fails and stores "Failed to create IGameClient instance!
//    Check that the game was run from the correct launcher. Online Play may not be available." in the client's
//    ErrorMessage (FString at +0x68: Data @+0x68, Num @+0x70), which the game shows as a pop-up after start.
//    The original still runs; on failure the message is emptied.
// 2. UArchonLocalPlayer::ShouldShowMOTD (RVA 0x1703460, bool() const) and AArchonHUD::CanDisplayMOTDScreen
//    (RVA 0x17C0F30, bool(AArchonHUD*)): the "Welcome to Dauntless! ... From everyone here at Phoenix Labs ..."
//    message-of-the-day screen. Both answer false, so it never opens.
// Set HidePhoenixPopups = false to get both back. Logged once each: "[popups] ...".

static bool HidePhoenixPopups = true;
static void PopLog(const std::string& Line);
static void* OrigLoadEACLibrary = nullptr;
static void* OrigShouldShowMOTD = nullptr;
static void* OrigCanDisplayMOTDScreen = nullptr;

bool LoadEACLibraryHook(void* Client, void* Path) {
    const bool Loaded = reinterpret_cast<bool(*)(void*, void*)>(OrigLoadEACLibrary)(Client, Path);
    if (!Loaded && HidePhoenixPopups && Client && LooksLikeValidPtr(Client)) {
        int32_t* Num = reinterpret_cast<int32_t*>(reinterpret_cast<uint8_t*>(Client) + 0x70);
        *Num = 0;   // FString with Num 0 is empty; the buffer stays allocated
        PopLog("[popups] Easy Anti-Cheat not loaded (offline): its error pop-up is hidden");
    }
    return Loaded;
}

bool ShouldShowMOTDHook(void* LocalPlayer) {
    if (!HidePhoenixPopups) return reinterpret_cast<bool(*)(void*)>(OrigShouldShowMOTD)(LocalPlayer);
    static bool Logged = false;
    if (!Logged) { Logged = true; PopLog("[popups] ShouldShowMOTD -> false"); }
    return false;
}

bool CanDisplayMOTDScreenHook(void* HUD) {
    if (!HidePhoenixPopups) return reinterpret_cast<bool(*)(void*)>(OrigCanDisplayMOTDScreen)(HUD);
    return false;
}
// =========================================================================================

// ===== [1.6.2 port] Master's Hat: keep the eye glow when the helm is hidden (client) =====
// The glow is the blueprint armour_part_eye_glow_rage_C (parent of armour_part_eye_glow_C, the Master's Hat /
// AR_HP07A_MONK_HELM_ULTRA custom function). Two of its events can switch the glow off when the helm is hidden
// (the April 2021 change): ToggleHide(bool Hide) and OwnerHid(bool bNewHidden) (the owner is the helm piece).
// Blueprint events are called through ProcessEvent (RVA 0x2119CC0), so this hook passes "false" to both: the helm
// still hides, the glow stays. Every function called on the eye-glow classes is logged once by name, and the first
// calls of the two events with their value, so it is visible what the game does.
// Cheap: each distinct UFunction is classified once (cached per thread), then it is one hash lookup per call.
// Set KeepEyeGlowWhenHelmHidden = false to disable.

static bool KeepEyeGlowWhenHelmHidden = true;
static std::atomic<int32_t> ToggleHideNameIndex{ -1 };
static std::atomic<int32_t> OwnerHidNameIndex{ -1 };
static std::atomic<int32_t> SetWelcomeTextNameIndex{ -1 };   // [Dauntless Forever] see WelcomeTextProcessEvent
static void* OrigProcessEventEyeGlow = nullptr;

// FName in UE 4.25: the first 4 bytes are the name's comparison index (read raw, whatever the SDK calls the field)
static int32_t FNameIndexRaw(const void* NamePtr) {
    return *reinterpret_cast<const int32_t*>(NamePtr);
}

void ResolveEyeGlowToggleHideName() {
    FName ToggleHide = UKismetStringLibrary::Conv_StringToName(L"ToggleHide");
    FName OwnerHid = UKismetStringLibrary::Conv_StringToName(L"OwnerHid");
    ToggleHideNameIndex = FNameIndexRaw(&ToggleHide);
    OwnerHidNameIndex = FNameIndexRaw(&OwnerHid);
    // [Dauntless Forever] welcome box text (see WelcomeTextProcessEvent)
    FName SetWelcomeText = UKismetStringLibrary::Conv_StringToName(L"SetWelcomeText");
    SetWelcomeTextNameIndex = FNameIndexRaw(&SetWelcomeText);
    PopLog("[popups] ProcessEvent watch ready");
    if (Globals::EnableLogging)
        std::cout << "[1.6.2 port] Eye glow hook ready (ToggleHide " << ToggleHideNameIndex.load()
        << ", OwnerHid " << OwnerHidNameIndex.load() << ")" << std::endl;
}

// 0 = not an eye-glow function, 1 = other eye-glow function (logged only), 2 = ToggleHide/OwnerHid (bool forced false)
static int ClassifyEyeGlowFunction(UFunction* Function) {
    UObject* Owner = Function->Outer;
    if (!Owner || !Owner->GetName().contains("armour_part_eye_glow")) return 0;
    const int32_t Id = FNameIndexRaw(&Function->Name);
    const bool Hider = (Id == ToggleHideNameIndex.load() || Id == OwnerHidNameIndex.load());
    if (Globals::EnableLogging)
        std::cout << "[1.6.2 port] Eye glow: " << Owner->GetName() << "." << Function->GetName()
        << (Hider ? "  (glow kept on)" : "") << std::endl;
    return Hider ? 2 : 1;
}

// ===== [Dauntless Forever] Our text in the title-screen welcome box (client) ==============
// The "Welcome to Dauntless! ... From everyone here at Phoenix Labs ..." box on the title screen is
// UPressStartScreen (its blueprint PressStartScreen_bps): the text is its FText PTRWelcomeText (+0x478) and the
// blueprint event SetWelcomeText(const FText& newText) puts it on screen. Both are replaced with WelcomeBoxText:
// PTRWelcomeText the first time the screen object goes through ProcessEvent, and the newText of every
// SetWelcomeText call. Each replacement is a fresh FText (Conv_StringToText), so the game frees it normally.
// Logged: "[popups] welcome box: ...". Set HidePhoenixPopups = false to keep the original text.
static const wchar_t* WelcomeBoxText = L"Welcome to Dauntless Forever, the free way to always play Dauntless. Forever!";

// [popups] lines also go to popups.log next to the game exe (the client console is not saved anywhere)
static std::mutex PopLogMutex;
static void PopLog(const std::string& Line) {
    std::cout << Line << std::endl;
    std::lock_guard<std::mutex> Lock(PopLogMutex);
    static FILE* F = nullptr;
    static int Count = 0;
    if (!F) fopen_s(&F, "popups.log", "w");
    if (F && Count++ < 2000) { fprintf(F, "%s\n", Line.c_str()); fflush(F); }
}

// Diagnostic: which UI functions run, so the welcome box can be found. Every distinct function whose name or
// owner contains one of these words is logged once, with the object's class. Remove when the box is found.
static bool LogUiFunctions = false;   // true logs UI function names to popups.log (how the box was found)
static bool IsUiWord(const std::string& N) {
    static const char* Words[] = { "Welcome", "PressStart", "MOTD", "Motd", "News", "Dialog", "Popup", "PopUp", "Modal",
        "Message", "Notice", "Prompt", "Legal", "Eula", "EULA", "FirstTime", "Splash", "Announcement", "Intro", "Login" };
    for (const char* W : Words) if (N.find(W) != std::string::npos) return true;
    return false;
}
static void LogUiFunction(UObject* Object, UFunction* Function) {
    if (!LogUiFunctions || !Function) return;
    thread_local std::unordered_map<UFunction*, bool> Seen;
    if (Seen.count(Function)) return;
    const std::string Fn = Function->GetName();
    const std::string Owner = Function->Outer ? Function->Outer->GetName() : "?";
    const bool Hit = IsUiWord(Fn) || IsUiWord(Owner);
    Seen[Function] = true;
    if (!Hit) return;
    const std::string ObjClass = (Object && Object->Class) ? Object->Class->GetName() : "?";
    PopLog("[popups] ui: " + Owner + "." + Fn + "  on " + ObjClass);
}

static void PutWelcomeText(void* Where) {
    FText Ours = UKismetTextLibrary::Conv_StringToText(FString(WelcomeBoxText));
    std::memcpy(Where, &Ours, sizeof(FText));   // the old FText keeps one reference (leaked on purpose, never freed twice)
}

static void WelcomeTextProcessEvent(UObject* Object, UFunction* Function, void* Parms) {
    if (SetWelcomeTextNameIndex.load(std::memory_order_relaxed) >= 0) LogUiFunction(Object, Function);
    if (!HidePhoenixPopups || !Object || SetWelcomeTextNameIndex.load(std::memory_order_relaxed) < 0) return;

    // Is this object the title screen? Decided once per class.
    thread_local std::unordered_map<UClass*, bool> ScreenClasses;
    UClass* Cls = Object->Class;
    auto It = ScreenClasses.find(Cls);
    const bool IsScreen = (It != ScreenClasses.end()) ? It->second
        : (ScreenClasses[Cls] = Object->IsA(UPressStartScreen::StaticClass()));
    if (!IsScreen) return;

    thread_local std::set<UObject*> Patched;
    if (Patched.insert(Object).second) {
        PutWelcomeText(reinterpret_cast<uint8_t*>(Object) + 0x478);   // UPressStartScreen::PTRWelcomeText
        PopLog("[popups] welcome box: PTRWelcomeText replaced on " + Object->GetName());
    }
    if (Function && Parms && FNameIndexRaw(&Function->Name) == SetWelcomeTextNameIndex.load()) {
        PutWelcomeText(Parms);   // PressStartScreen_SetWelcomeText { FText newText } at offset 0
        static std::atomic<int> Logged{ 0 };
        if (Logged.fetch_add(1) < 5) PopLog("[popups] welcome box: SetWelcomeText text replaced");
    }
}
// =========================================================================================

// The box itself is PressStartPanel_bpw_C (found with the popups.log diagnostic, Oct 14): a UTextBlock* WelcomeText
// (+0x398) and an FText Text (+0x3B0, "ExposeOnSpawn"); UpdateText() copies one into the other. After each
// ProcessEvent on a panel (the first one, and every UpdateText) both get WelcomeBoxText. TextBlock.SetText is
// called through ProcessEvent because the SDK's UMG functions are not compiled into this DLL.
// The OK button still works: it is the game's "press start", which starts the login.
static void FixWelcomePanel(UObject* Object, UFunction* Function) {
    if (!HidePhoenixPopups || !Object || SetWelcomeTextNameIndex.load(std::memory_order_relaxed) < 0) return;

    thread_local std::unordered_map<UClass*, bool> PanelClasses;
    UClass* Cls = Object->Class;
    auto It = PanelClasses.find(Cls);
    const bool IsPanel = (It != PanelClasses.end()) ? It->second
        : (PanelClasses[Cls] = Object->IsA(UPressStartPanel_bpw_C::StaticClass()));
    if (!IsPanel) return;

    thread_local std::set<UObject*> Done;
    const bool First = Done.insert(Object).second;
    const bool IsUpdateText = Function && Function->GetName() == "UpdateText";
    if (!First && !IsUpdateText) return;
    if (First && Object->GetName().rfind("Default__", 0) == 0) return;   // the class default object, not a real panel

    UPressStartPanel_bpw_C* Panel = static_cast<UPressStartPanel_bpw_C*>(Object);
    PutWelcomeText(&Panel->Text);

    UObject* TextBlock = reinterpret_cast<UObject*>(Panel->WelcomeText);
    if (TextBlock && LooksLikeValidPtr(TextBlock)) {
        static UFunction* SetTextFn = nullptr;
        if (!SetTextFn) SetTextFn = TextBlock->Class->GetFunction("TextBlock", "SetText");
        if (SetTextFn) {
            struct { FText InText; } SetTextParms;
            PutWelcomeText(&SetTextParms.InText);
            TextBlock->ProcessEvent(SetTextFn, &SetTextParms);
            PopLog(std::string("[popups] welcome box: text set on ") + Object->GetName() + (IsUpdateText ? " (after UpdateText)" : ""));
        }
        else PopLog("[popups] welcome box: TextBlock.SetText not found");
    }
    else PopLog("[popups] welcome box: panel has no WelcomeText yet");
}

void EyeGlowProcessEventHook(UObject* Object, UFunction* Function, void* Parms) {
    WelcomeTextProcessEvent(Object, Function, Parms);
    if (KeepEyeGlowWhenHelmHidden && Function && ToggleHideNameIndex.load(std::memory_order_relaxed) >= 0) {
        thread_local std::unordered_map<UFunction*, int> Known;
        auto It = Known.find(Function);
        const int Kind = (It != Known.end()) ? It->second : (Known[Function] = ClassifyEyeGlowFunction(Function));
        const int32_t Id = FNameIndexRaw(&Function->Name);   // re-check: memory of unloaded functions gets reused
        if (Kind == 2 && Parms && (Id == ToggleHideNameIndex.load() || Id == OwnerHidNameIndex.load())) {
            bool* Hidden = reinterpret_cast<bool*>(Parms);   // ToggleHide(bool Hide) / OwnerHid(bool bNewHidden): offset 0
            static std::atomic<int> Logged{ 0 };
            if (Globals::EnableLogging && Logged.fetch_add(1) < 20)
                std::cout << "[1.6.2 port] Eye glow: " << Function->GetName() << "(" << (*Hidden ? "true" : "false")
                << ")" << (*Hidden ? " -> false (glow kept)" : "") << std::endl;
            *Hidden = false;
        }
    }
    reinterpret_cast<void(*)(UObject*, UFunction*, void*)>(OrigProcessEventEyeGlow)(Object, Function, Parms);
    FixWelcomePanel(Object, Function);   // after the game's own code ran (see FixWelcomePanel)
}
// =========================================================================================

void InitClientHooks() {
    MH_Initialize();

    MH_CreateHook((void*)(Globals::BaseAddress + 0x16EFFC0), HasFinishedLoadingHook, &OrigHasFinishedLoading);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x16EFFC0));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x1EC2570), ConfigCacheInitGetStringHook, &OrigConfigCacheIniGetString);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x1EC2570));

    MH_EnableHook((void*)(Globals::BaseAddress + 0x1EC2570));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x2FEC910), SetBrushFromTextureHook, &OrigSetBrushFromTexture);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x2FEC910));

    // [1.6.2 port] Hunt Pass Elite gate (see HasEntitlementHook)
    MH_CreateHook((void*)(Globals::BaseAddress + 0x14B3DB0), HasEntitlementHook, &OrigHasEntitlement);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x14B3DB0));

    // [cell-exchange] Unlock exchange slots 2 and 3 (see IsExchangeSlotLockedHook)
    MH_CreateHook((void*)(Globals::BaseAddress + 0x15BF660), IsExchangeSlotLockedHook, &OrigIsExchangeSlotLocked);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x15BF660));

    // [Dauntless Forever] hide the Easy Anti-Cheat error and the Phoenix Labs welcome screen (see LoadEACLibraryHook)
    MH_CreateHook((void*)(Globals::BaseAddress + 0xF5E7D0), LoadEACLibraryHook, &OrigLoadEACLibrary);

    MH_EnableHook((void*)(Globals::BaseAddress + 0xF5E7D0));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x1703460), ShouldShowMOTDHook, &OrigShouldShowMOTD);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x1703460));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x17C0F30), CanDisplayMOTDScreenHook, &OrigCanDisplayMOTDScreen);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x17C0F30));

    // [1.6.2 port] Master's Hat eye glow (see EyeGlowProcessEventHook). Client only; the server has its own ProcessEvent hook.
    MH_CreateHook((void*)(Globals::BaseAddress + 0x2119CC0), EyeGlowProcessEventHook, &OrigProcessEventEyeGlow);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x2119CC0));

    // [1.6.2 port] disabled - GetEscalationSeason: optional, not yet found on 1.6.2
    // [1.6.2 port] disabled - GetEscalationSeason: optional, not yet found on 1.6.2
    //MH_CreateHook((void*)(Globals::BaseAddress + 0x14F2A30), GetEscalationSeason, &OrigGetEscalationSeason);

    //MH_EnableHook((void*)(Globals::BaseAddress + 0x14F2A30));

    //

    //1469E00

    //MH_CreateHook((void*)(Globals::BaseAddress + 0x1469E00), GetTrackProgress, &OrigGetTrackProgress);

    //MH_EnableHook((void*)(Globals::BaseAddress + 0x1469E00));


    //MH_CreateHook((void*)(Globals::BaseAddress + 0x362F630), IsNetReadyHook, &OrigIsNetReady);

    //MH_EnableHook((void*)(Globals::BaseAddress + 0x362F630));

    //MH_CreateHook((void*)(Globals::BaseAddress + 0x2119CC0), ProcessEventClientHook, &OrigProcessEventClient);

    //MH_EnableHook((void*)(Globals::BaseAddress + 0x2119CC0));

   // MH_CreateHook((void*)(Globals::BaseAddress + 0x3077710), GetActorCallspace, &OrigGetActorCallspace);

   // MH_EnableHook((void*)(Globals::BaseAddress + 0x3077710));
}

void* OrigSprint = nullptr;

bool SprintHook(uintptr_t a1, uintptr_t a2) { //char __fastcall UArchonStaminaComponent_TryConsumeStamina_Native(__int64 a1, __int64 a2, char a3, char a4)    
    return true;
}

void* OrigNetModeHook = nullptr;

int NetModeHook(void* a1) { //char __fastcall UArchonStaminaComponent_TryConsumeStamina_Native(__int64 a1, __int64 a2, char a3, char a4)   
    return 1;
}

// [1.6.2 port] Write bytes only if the original bytes match Dauntless 1.6.2.
static bool PatchBytes162(uintptr_t Rva, std::initializer_list<uint8_t> Expected, std::initializer_list<uint8_t> Replacement) {
    uint8_t* Target = (uint8_t*)(Globals::BaseAddress + Rva);
    size_t i = 0;
    for (uint8_t b : Expected) {
        if (Target[i++] != b) {
            if (Globals::EnableLogging) std::cout << "[1.6.2 port] Patch at +0x" << std::hex << Rva << std::dec << " does not match, skipped." << std::endl;
            return false;
        }
    }
    DWORD oldProtect;
    VirtualProtect(Target, Replacement.size(), PAGE_EXECUTE_READWRITE, &oldProtect);
    i = 0;
    for (uint8_t b : Replacement) Target[i++] = b;
    VirtualProtect(Target, Replacement.size(), oldProtect, &oldProtect);
    return true;
}
// ===== [1.6.2 port] Bounty season-date fallback =====================================
// PASTE 1: put this block in dllmain.cpp just ABOVE the line "void InitServerHooks() {"
// (above the PatchBytes162 helper is fine too).
//
// In 1.6.2 the server's bounty component asks for the current Hunt Pass season's start/end
// dates (UBountyComponent, 1.6.2 0x1456200, vtable slot +0x4B8). It finds the season through
// a feature flag, then the season's progression config. On a revived server neither exists,
// so it returns false and the server sends the player back to the main menu
// ("ServerInitializeBounties() - failed to get season dates").
// This hook keeps the game's own answer when it has one, and otherwise supplies a wide
// season window (2021-01-01 to 2085-01-01), in Unreal FDateTime ticks (100 ns since 0001-01-01).

static void* OrigBountyGetSeasonDates = nullptr;

bool BountyGetSeasonDatesHook(void* Component, void* Now, int64_t* OutStart, int64_t* OutEnd) {
    if (reinterpret_cast<bool(*)(void*, void*, int64_t*, int64_t*)>(OrigBountyGetSeasonDates)(Component, Now, OutStart, OutEnd)) {
        return true;
    }

    *OutStart = 637450560000000000LL; // 2021-01-01 00:00 UTC
    *OutEnd = 657647424000000000LL; // 2085-01-01 00:00 UTC

    if (Globals::EnableLogging) {
        std::cout << "[1.6.2 port] Bounty season dates: no current season, using fallback window" << std::endl;
    }
    return true;
}
// =====================================================================================

// ===== [1.6.2 port] Skip player input setup on the server ===========================
// PASTE 1: put this block in dllmain.cpp just ABOVE the line "void InitServerHooks() {"
//
// Crash on join (1.6.2): EXCEPTION_ACCESS_VIOLATION reading 0x150 in
// AArchonCharacter::SetupPlayerInputComponent (1.6.2 0x13B2D40, binds "Dodge", "Primary Attack",
// "Special Action" ...). It reaches the player controller's PlayerInput (APlayerController +0x348)
// and adds 0x150; PlayerInput only exists on the player's own PC, so on the server it is null.
// The server never needs input bindings, so in server mode this hook simply skips the function.

static void* OrigSetupPlayerInputComponent = nullptr;

void SetupPlayerInputComponentHook(void* Character, void* InputComponent) {
    if (Globals::EnableLogging) {
        std::cout << "[1.6.2 port] Skipped SetupPlayerInputComponent on the server" << std::endl;
    }
    return;
}
// =====================================================================================
void InitServerHooks() {
    MH_Initialize();

    // [offline package] Serve the backend endpoints from the DLL's own table (EvalEndpointMap) instead of
    // relying on Game.ini. Without this, a server copy on a PC whose profile has no Game.ini sends every
    // request to the dead Phoenix hosts, gets nothing back, and crashes on the first escalation reply.
    MH_CreateHook((void*)(Globals::BaseAddress + 0x1EC2570), ConfigCacheInitGetStringHook, &OrigConfigCacheIniGetString);
    MH_EnableHook((void*)(Globals::BaseAddress + 0x1EC2570));

    // [1.6.2 port] Hunt Pass Elite gate (see HasEntitlementHook); the server may check it too
    MH_CreateHook((void*)(Globals::BaseAddress + 0x14B3DB0), HasEntitlementHook, &OrigHasEntitlement);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x14B3DB0));

    // [cell-exchange] Unlock exchange slots 2 and 3 (see IsExchangeSlotLockedHook); the server validates fusions
    MH_CreateHook((void*)(Globals::BaseAddress + 0x15BF660), IsExchangeSlotLockedHook, &OrigIsExchangeSlotLocked);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x15BF660));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x1456200), BountyGetSeasonDatesHook, &OrigBountyGetSeasonDates);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x1456200));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x13B2D40), SetupPlayerInputComponentHook, &OrigSetupPlayerInputComponent);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x13B2D40));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x275D380), GetGameDefaultMap, &OrigGetDefaultMap);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x275D380));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x1EBF560), GetCommandLineHook, &OrigGetCommandLine);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x1EBF560));

    // [1.6.2 port] disabled - ServerBootCrash: 1.4.4 crash fix, not yet found on 1.6.2 (re-add if the server crashes at boot)
    //MH_CreateHook((void*)(Globals::BaseAddress + 0x2E4D7F0), ServerBootCrash, &OrigServerBootCrash);

    //MH_EnableHook((void*)(Globals::BaseAddress + 0x2E4D7F0));

    // [1.6.2 port] disabled - EncounterableSetup: 1.4.4 crash fix, not yet found on 1.6.2
    //MH_CreateHook((void*)(Globals::BaseAddress + 0x1658f90), EncounterableSetupHook, &OrigEncounterableSetup);

    //MH_EnableHook((void*)(Globals::BaseAddress + 0x1658f90));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x34B8410), GameEngineTickHook, &OrigGameEngineTick);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x34B8410));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x868210), FixupNetworkNotifyHook, &OrigFixupNetworkNotify);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x868210));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x2A60CA0), ProcessRequest, &OrigProcessRequest);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x2A60CA0));

    // [1.6.2 port] disabled - Combat text: 1.4.4 crash fix, not yet found on 1.6.2
    //MH_CreateHook((void*)(Globals::BaseAddress + 0x1390300), EncounterableSetupHook, &OrigEncounterableSetup); // TODO: Rename to combat text

    //MH_EnableHook((void*)(Globals::BaseAddress + 0x1390300));

    //MH_CreateHook((void*)(Globals::BaseAddress + 0x3077710), GetActorCallspace, &OrigGetActorCallspace);

    //MH_EnableHook((void*)(Globals::BaseAddress + 0x3077710));

    // [1.6.2 port] disabled - PostLogin: Undaunted hook only calls the original, not needed
    //MH_CreateHook((void*)(Globals::BaseAddress + 0x14B7460), PostLoginHook, &OrigPostLogin);

    //MH_EnableHook((void*)(Globals::BaseAddress + 0x14B7460));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x16EFFC0), HasFinishedLoadingHook, &OrigHasFinishedLoading);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x16EFFC0));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x362F630), IsNetReadyHook, &OrigIsNetReady);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x362F630));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x3642B70), SetReplicationDriverHook, &OrigSetReplicationDriver);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x3642B70));

    // [1.6.2 port] GetNetDriver_Internal found on 1.6.2 at 0x322A220 (called by AActor::GetNetMode)
    MH_CreateHook((void*)(Globals::BaseAddress + 0x322A220), GetNetDriverInternalHook, &OrigGetNetDriverInternal);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x322A220));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x3609CA0), IsLevelInitForActorHook, &OrigIsLevelInitForActor);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x3609CA0));

    // [1.6.2 port] disabled - GetStartSpot: TODO find on 1.6.2 (game uses its own spawn logic until then)
    //MH_CreateHook((void*)(Globals::BaseAddress + 0x1368660), GetStartSpotHook, &OrigGetStartSpot);

    //MH_EnableHook((void*)(Globals::BaseAddress + 0x1368660));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x2119CC0), ProcessEventHook, &OrigProcessEvent);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x2119CC0));

    //MH_CreateHook((void*)(Globals::BaseAddress + 0x35996D0), MakeDoDamageHook, &OrigMakeDoDamage);

    //MH_EnableHook((void*)(Globals::BaseAddress + 0x35996D0));

    //MH_CreateHook((void*)(Globals::BaseAddress + 0x137A800), SprintHook, &OrigSprint);

    //MH_EnableHook((void*)(Globals::BaseAddress + 0x137A800));

    MH_CreateHook((void*)(Globals::BaseAddress + 0x393CF40), NetModeHook, &OrigNetModeHook);

    MH_EnableHook((void*)(Globals::BaseAddress + 0x393CF40));

    //MH_CreateHook((void*)(Globals::BaseAddress + 0x1469E00), GetTrackProgress, &OrigGetTrackProgress);

   // MH_EnableHook((void*)(Globals::BaseAddress + 0x1469E00));


    // [1.6.2 port] disabled - GetEscalationSeason: optional, not yet found on 1.6.2
    //MH_CreateHook((void*)(Globals::BaseAddress + 0x14F2A30), GetEscalationSeason, &OrigGetEscalationSeason);

    //MH_EnableHook((void*)(Globals::BaseAddress + 0x14F2A30));

    //

    //13CA280

    //GetStartSpotHook

    // [1.6.2 port] Byte patches for Dauntless 1.6.2 (CL 271281).
    // Each patch checks the original bytes first, so a wrong exe is never modified.

    // Fixup Listen failure: UEngine::LoadMap's call to the stripped UWorld::Listen -> mov al,1
    PatchBytes162(0x38DF8E6, { 0xE8, 0x45, 0x19, 0xEF, 0xFC }, { 0xB0, 0x01, 0x90, 0x90, 0x90 });

    // Fixup Ramsgate Crash (1.4.4: 0x1346A98): not yet found on 1.6.2, re-add if Ramsgate crashes

    // GIsServer / GIsClient: stop FEngineLoop::PreInit (0x7E0380) from overwriting them
    PatchBytes162(0x7DE29E, { 0x41, 0x22, 0xC5, 0x88, 0x05, 0x12, 0x98, 0x89, 0x05 }, { 0xC6, 0x05, 0x14, 0x98, 0x89, 0x05, 0x00, 0x90, 0x90 }); // GIsClient = 0
    PatchBytes162(0x7DE2AB, { 0x41, 0x22, 0xC5, 0x88, 0x05, 0x06, 0x98, 0x89, 0x05 }, { 0xC6, 0x05, 0x08, 0x98, 0x89, 0x05, 0x01, 0x90, 0x90 }); // GIsServer = 1
    PatchBytes162(0x7E290B, { 0x44, 0x88, 0x25, 0xA7, 0x51, 0x89, 0x05 }, { 0xC6, 0x05, 0xA7, 0x51, 0x89, 0x05, 0x00 });                         // GIsClient = 0
    PatchBytes162(0x7E2770, { 0x01 }, { 0x00 }); // immediate of mov byte [GIsClient], 1
    PatchBytes162(0x7E2905, { 0x00 }, { 0x01 }); // immediate of mov byte [GIsServer], 0
}

// [Dauntless Forever] Modded mode: load UE4SS (ue4ss\UE4SS.dll next to the game exe) from here instead of its usual
// dwmapi.dll proxy, which loads into every copy of the exe (the game AND the hidden Ramsgate/hunt servers: 3 consoles).
// The game loads it only when the launcher started it with -dfmods; servers only when the host turned on server mods
// (DF_SERVER_MODS=1 in their environment). Loaded on its own thread, never inside DllMain's loader lock.
static DWORD WINAPI LoadUE4SSThread(LPVOID) {
    if (GetModuleHandleW(L"UE4SS.dll")) return 0;   // already loaded (an old dwmapi.dll proxy is still in place)
    // Loading UE4SS this early in start-up (we are loaded from inside the game's first dxgi call) hangs the game. Wait
    // until the engine is up (GWorld set, 1.6.2 RVA 0x624A778) plus a moment, the same as injecting UE4SS into a
    // running game. Gives up after 3 minutes without a world (the game then just runs without mods).
    for (int i = 0; i < 1800; ++i) {
        Sleep(100);
        if (*(void**)(Globals::BaseAddress + 0x624A778) != nullptr) { Sleep(2000); break; }
        if (i == 1799) return 0;
    }
    wchar_t Exe[MAX_PATH] = {};
    DWORD Len = GetModuleFileNameW(nullptr, Exe, MAX_PATH);
    if (!Len || Len >= MAX_PATH) return 0;
    std::wstring Dir(Exe);
    Dir = Dir.substr(0, Dir.find_last_of(L"\\/"));
    std::wstring Dll = Dir + L"\\ue4ss\\UE4SS.dll";
    if (GetFileAttributesW(Dll.c_str()) == INVALID_FILE_ATTRIBUTES) return 0;
    LoadLibraryW(Dll.c_str());
    return 0;
}

static void MaybeLoadUE4SS() {
    bool Want = false;
    if (Globals::AmServer) {
        wchar_t Value[8] = {};
        Want = GetEnvironmentVariableW(L"DF_SERVER_MODS", Value, 8) > 0 && Value[0] == L'1';
    } else {
        Want = std::wstring(GetCommandLineW()).find(L" -dfmods") != std::wstring::npos;
    }
    if (!Want) return;
    DWORD Id;
    HANDLE H = CreateThread(nullptr, 0, LoadUE4SSThread, nullptr, 0, &Id);
    if (H) CloseHandle(H);
}

void Init() {

    // [1.6.2 port] Only run on Dauntless 1.6.2 (CL 271281): check the LoadMap -> Listen call bytes.
    {
        const uint8_t* Probe = (const uint8_t*)((uintptr_t)GetModuleHandleA(nullptr) + 0x38DF8E6);
        const uint8_t Expected[5] = { 0xE8, 0x45, 0x19, 0xEF, 0xFC };
        if (memcmp(Probe, Expected, 5) != 0) {
            MessageBoxA(nullptr, "This DLL is built for Dauntless 1.6.2 (CL 271281) only.", "Undaunted 1.6.2 port", 0);
            return;
        }
    }

    Globals::AmServer = std::string(GetCommandLineA()).contains("-server");
    Globals::BaseAddress = (uintptr_t)GetModuleHandleA(nullptr);

    if (Globals::AmServer) {
        *(uint8_t*)(Globals::BaseAddress + 0x6077ABA) = 0x1; // GIsServer
        *(uint8_t*)(Globals::BaseAddress + 0x6077AB9) = 0x0; // GIsClient
    }

    UC::FMemory::Init((void*)(Globals::BaseAddress + 0x1E4A690));

    if (Globals::AmServer) {
        int NumArgs = 0;

        wchar_t** Args = CommandLineToArgvW(GetCommandLineW(), &NumArgs);

        if (NumArgs > 8) {
            Globals::ServerAPIKey = Args[1];
            Globals::Port = std::stoi(std::wstring(Args[2]));
            Globals::MapPath = Args[3];
            Globals::BehemothPath = Args[4];
            Globals::MatchmakerHuntId = Args[5];
            Globals::ExpectedPlayerString = Args[6];
            Globals::MyIpAndPort = Args[7];

            // [offline package] The backend address for this server copy. Passed by the deploy server as the
            // 8th argument; falls back to the local backend. Used by the config hook below (same as the client),
            // so server copies no longer depend on a Game.ini in the user's profile folder.
            if (NumArgs > 8 && Args[8][0] != L'\0' && Args[8][0] != L'-') {
                Globals::MetagameAddress = Args[8];
            }
            else {
                Globals::MetagameAddress = L"127.0.0.1:61000";
            }

            if (Globals::Port >= 8776) {
                EnableWatchdog = false;
                Globals::EnableLogging = true;
            }
        }
        else {
            MessageBoxA(nullptr, "INVALID GAMESERVER ARGS", "INVALID GAMESERVER ARGS", 0);
            exit(0);
            return;
        }

        if (Globals::EnableLogging) {
            AllocConsole();
            FILE* Dummy;
            std::string LogName = "UndauntedServer_" + std::to_string(Globals::Port) + ".log";
            freopen_s(&Dummy, LogName.c_str(), "w", stdout);
            setvbuf(stdout, nullptr, _IONBF, 0);
            freopen_s(&Dummy, "CONIN$", "r", stdin);

            std::cout << "Welcome to Undaunted v" << UNDAUNTED_INTERNAL_VERSION << "!" << std::endl;
            std::cout << "prod. gwog :3" << std::endl;
            std::cout << "thanks to all who contributed in any way, you know who you are, dm me on discord if you want a named shoutout here :3" << std::endl;

            std::cout << "Running as a server!" << std::endl;
        }

        // [Dauntless Forever] Pin the C runtime locale too, so atof/sscanf/strtod in the game's server code read "105.6"
        // with a decimal point on French, German, Italian... Windows. Backstop to -CULTURE=en-US above.
        _configthreadlocale(_ENABLE_PER_THREAD_LOCALE);
        setlocale(LC_ALL, "C");
        _configthreadlocale(_DISABLE_PER_THREAD_LOCALE);
        setlocale(LC_ALL, "C");

        InitServerHooks();
    }
    else {
        Globals::EnableLogging = true;

        if (Globals::EnableLogging) {
            // [Dauntless Forever] No console window for the player's game: clicking in it (QuickEdit) blocks every
            // write, and the game thread writes here, so the game froze (hang reports Oct 17). Closing it also
            // killed the game. Log to a file next to the exe instead (Get the logs collects it).
            FILE* Dummy;
            freopen_s(&Dummy, "UndauntedClient.log", "w", stdout);
            setvbuf(stdout, nullptr, _IONBF, 0);

            std::cout << "Welcome to Undaunted v" << UNDAUNTED_INTERNAL_VERSION << "!" << std::endl;
            std::cout << "prod. gwog :3" << std::endl;
            std::cout << "thanks to all who contributed in any way, you know who you are, dm me on discord if you want a named shoutout here :3" << std::endl;

            std::cout << "Running as a debug-enabled client!" << std::endl;
        }

        int NumArgs = 0;

        wchar_t** Args = CommandLineToArgvW(GetCommandLineW(), &NumArgs);

        if (NumArgs > 2) {
            Globals::MetagameAddress = Args[1];
        }

        InitClientHooks();
    }

    MaybeLoadUE4SS();   // [Dauntless Forever] modded mode, see LoadUE4SSThread

    DWORD threadId;
    CreateThread(nullptr, 0x1000, (LPTHREAD_START_ROUTINE)MainThread, nullptr, 0, &threadId);
}

BOOL APIENTRY DllMain(HMODULE hModule,
    DWORD  ul_reason_for_call,
    LPVOID lpReserved
)
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        DisableThreadLibraryCalls(hModule);
        Init();
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

