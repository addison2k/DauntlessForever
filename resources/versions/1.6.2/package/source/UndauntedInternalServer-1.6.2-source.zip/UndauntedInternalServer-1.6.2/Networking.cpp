// Dauntless Forever - Dauntless 1.6.2 server DLL (UndauntedInternalServer)
// Copyright (C) 2026 Addison2k (port to this Dauntless build and all changes). https://github.com/addison2k/DauntlessForever
// Based on Undaunted, Copyright (C) gwog and contributors, https://github.com/SyST3MDeV/Undaunted
// Licence: AGPL-3.0-only (LICENSE-AGPL-3.0.txt). Keep this notice: the licence requires it.
#include "networking.h"

#include <iostream>

using namespace SDK;

namespace Networking {
    UNetDriver* NetDriver = nullptr;
    static uintptr_t BaseAddress = 0x0;

    static std::vector<AActor*> BuildConsiderList(UWorld* World, UNetDriver* Driver) {
        std::vector<AActor*> Actors = std::vector<AActor*>();

        for (ULevel* Level : World->Levels) {
            for (AActor* Actor : Level->Actors) {
                if (!Actor)
                    continue;

                if (Actor->RemoteRole == ENetRole::ROLE_None)
                    continue;

                if (Actor->bActorIsBeingDestroyed)
                    continue;

                if (!reinterpret_cast<UWorld * (*)(AActor*)>(*(void**)((uintptr_t)Actor->VTable + 0x150))(Actor)) {
                    continue;
                }

                reinterpret_cast<void(*)(AActor*, UNetDriver*)>(BaseAddress + 0x321C880)(Actor, Driver);

                Actors.push_back(Actor);
            }
        }

        /*
        for (int i = 0; i < SDK::UObject::GObjects->Num(); i++)
        {
            SDK::UObject* Obj = SDK::UObject::GObjects->GetByIndex(i);

            if (!Obj)
                continue;

            if (Obj->IsDefaultObject())
                continue;

            if (Obj->IsA(SDK::AActor::StaticClass()))
            {
                AActor* Actor = (AActor*)Obj;

                if (Actor->RemoteRole == ENetRole::ROLE_None)
                    continue;

                if (Actor->bActorIsBeingDestroyed)
                    continue;

                if (!reinterpret_cast<UWorld * (*)(AActor*)>(*(void**)((uintptr_t)Actor->VTable + 0x150))(Actor)) {
                    continue;
                }
                
                reinterpret_cast<void(*)(AActor*, UNetDriver*)>(BaseAddress + 0x321C880)(Actor, Driver);

                Actors.push_back(Actor);
            }
        }
        */

        return Actors;
    }

    static UActorChannel* GetActorChannelForConnectionAndActor(UNetConnection* Connection, AActor* Actor) {
        for (UChannel* Channel : Connection->OpenChannels) {
            if (Channel->Class == UActorChannel::StaticClass() && ((UActorChannel*)Channel)->Actor == Actor) {
                return ((UActorChannel*)Channel);
            }
        }

        return nullptr;
    }

    void Listen(UEngine* Engine, int Port) {
        BaseAddress = (uintptr_t)GetModuleHandleA(nullptr);

        FName GameNetDriver = UKismetStringLibrary::Conv_StringToName(L"GameNetDriver");

        std::cout << "Net driver create: " << (int)reinterpret_cast<uint8_t(*)(UEngine*, void*, FName, FName)>(BaseAddress + 0x38CB770)(Engine, UWorld::GetWorld(), GameNetDriver, GameNetDriver) << std::endl;

        for (int i = 0; i < SDK::UObject::GObjects->Num(); i++)
        {
            SDK::UObject* Obj = SDK::UObject::GObjects->GetByIndex(i);

            if (!Obj)
                continue;

            if (Obj->IsDefaultObject())
                continue;

            if (Obj->IsA(SDK::UNetDriver::StaticClass()))
            {
                NetDriver = (UNetDriver*)Obj;
                break;
            }
        }

        std::cout << NetDriver->GetFullName() << std::endl;

        reinterpret_cast<void(*)(UNetDriver*, UWorld*)>(BaseAddress + 0x3642CE0)(NetDriver, UWorld::GetWorld());

        FURL url = FURL();

        url.Port = Port;

        FString empy = FString();

        std::cout << "Listen Status: " << (*(reinterpret_cast<bool(**)(UNetDriver*, void*, FURL*, bool, FString*)>(*(__int64*)NetDriver + 0x288 /* [1.6.2 port] was 0x280 */)))(NetDriver, (void*)UWorld::GetWorld()->NetworkNotify, &url, false, &empy) << std::endl;

        reinterpret_cast<void(*)(UNetDriver*, UWorld*)>(BaseAddress + 0x3642CE0)(NetDriver, UWorld::GetWorld());

        UWorld::GetWorld()->NetDriver = NetDriver;
    }

    void TickNetworking() {
        UWorld::GetWorld()->NetDriver = NetDriver;

        NetDriver->World = UWorld::GetWorld();

        static FName name = FName();
        static bool nameInit = false;

        if (!nameInit) {
            nameInit = true;
            name = UKismetStringLibrary::Conv_StringToName(L"Actor");
        }

        ++ * (uint32_t*)((uintptr_t)NetDriver + 0x2AC);

        std::vector<AActor*> Actors = BuildConsiderList(UWorld::GetWorld(), NetDriver);

        for (UNetConnection* Connection : NetDriver->ClientConnections) {
            if (!Connection->OwningActor || *(uint32_t*)((uintptr_t)Connection + 0x134) != 3)
                continue;

            for (AActor* Actor : Actors) {
                if (Actor->Class->CastFlags & EClassCastFlags::PlayerController) {
                    if (Actor != Connection->OwningActor) {
                        continue;
                    }
                    else {
                        Connection->ViewTarget = ((APlayerController*)Actor)->GetViewTarget();

                        reinterpret_cast<void(*)(APlayerController*)>(BaseAddress + 0x3750FA0)((APlayerController*)Actor);
                    }
                }

                //

                UActorChannel* ActorChannel = GetActorChannelForConnectionAndActor(Connection, Actor);

                if (!ActorChannel) {
                    ActorChannel = reinterpret_cast<UActorChannel * (*)(UNetConnection*, FName*, unsigned int, int)>(BaseAddress + 0x35FB330)(Connection, &name, 1 << 1, -1);

                    if (ActorChannel) {
                        reinterpret_cast<void(*)(UActorChannel*, AActor*, unsigned int)>(BaseAddress + 0x3434820)(ActorChannel, Actor, 0);
                    }
                }

                if (ActorChannel && ActorChannel->Actor) {
                    if (!(*(int*)((uintptr_t)ActorChannel + 0x90) & 2u)) {
                        *(int*)((uintptr_t)ActorChannel + 0x90) |= 2u;
                    }
                    if (reinterpret_cast<bool(*)(UActorChannel*)>(BaseAddress + 0x342FC30)(ActorChannel)) {
                        //std::cout << ActorChannel->Actor->GetFullName() << std::endl;
                    }
                }
            }
        }
    }
}