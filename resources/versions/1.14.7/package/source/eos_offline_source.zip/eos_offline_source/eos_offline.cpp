// eos_offline - a local stand-in for Epic's EOS SDK DLL (EOSSDK-Win64-Shipping.dll), SDK 1.16.0 ABI.
//
// Purpose: let the Dauntless 2.1.1 client complete its "signed in to Epic" step with no network,
// for single-player preservation on a private local backend. It answers every call locally:
//   - sign-in, account ids, display name            -> succeed with one fixed local player
//   - friends, presence, store, achievements, stats  -> succeed with empty results
//   - lobbies, sessions, voice, peer-to-peer, overlay -> report "not available"
// It makes no network connections of any kind and starts no other programs.
//
// Every call is written to eos_offline.log; behaviour can be adjusted in eos_offline.ini.
// Both live in the folder named by the EOS_OFFLINE_DIR environment variable, else next to this DLL.
//
// Build: see build.sh. Function prototypes come from the public EOS SDK 1.16.0 headers, so a
// mismatch with the real interface is a compile error.

#define EOS_BUILDING_SDK 1
#include "eos_sdk.h"
#include "eos_logging.h"
#include "eos_auth.h"
#include "eos_connect.h"
#include "eos_userinfo.h"
#include "eos_friends.h"
#include "eos_presence.h"
#include "eos_ecom.h"
#include "eos_achievements.h"
#include "eos_stats.h"
#include "eos_leaderboards.h"
#include "eos_lobby.h"
#include "eos_sessions.h"
#include "eos_p2p.h"
#include "eos_rtc.h"
#include "eos_rtc_audio.h"
#include "eos_ui.h"
#include "eos_metrics.h"
#include "eos_playerdatastorage.h"
#include "eos_titlestorage.h"
#include "eos_anticheatclient.h"

// The SDK headers declare scoped enums when compiled as C++; bring the names used here into scope.
using enum EOS_EResult;
using enum EOS_ELoginStatus;
using enum EOS_EApplicationStatus;
using enum EOS_ENetworkStatus;
using enum EOS_EDesktopCrossplayStatus;
using enum EOS_EAuthTokenType;
using enum EOS_EExternalAccountType;

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
typedef CRITICAL_SECTION Lock;
static void lock_init(Lock* l) { InitializeCriticalSection(l); }
static void lock_on(Lock* l) { EnterCriticalSection(l); }
static void lock_off(Lock* l) { LeaveCriticalSection(l); }
#else
#include <pthread.h>
typedef pthread_mutex_t Lock;
static void lock_init(Lock* l) { pthread_mutexattr_t a; pthread_mutexattr_init(&a); pthread_mutexattr_settype(&a, PTHREAD_MUTEX_RECURSIVE); pthread_mutex_init(l, &a); }
static void lock_on(Lock* l) { pthread_mutex_lock(l); }
static void lock_off(Lock* l) { pthread_mutex_unlock(l); }
#endif

// ------------------------------------------------------------------ setup, log, config
static Lock g_lock;
static int g_ready = 0;
static char g_dir[1024] = ".";
static FILE* g_log = 0;

struct Override { char name[96]; int value; };
static Override g_over[128];
static int g_nover = 0;

static char g_displayName[64] = "Slayer";
static char g_epicId[40] = "d211000000000000000000000000e91c";   // local player's Epic account id (made up)
static char g_productId[40] = "d2110000000000000000000000009d1d"; // local player's product user id (made up)
static int g_loggedIn = 0;
static int g_connected = 0;

// Optional one-time helper: if a file named load_once.txt exists in the settings folder, the DLL whose
// path it contains is loaded once, a little after sign-in, and the file is renamed so it does not repeat.
// Used to run a diagnostic tool (an SDK dumper) inside the game without a separate injector program.
static char g_loadOnce[1024] = "";
static int g_loadDelay = 20;
static int g_loadDone = 0;
static time_t g_signedInAt = 0;

static void ensure_ready(void);

static void logf_(const char* fmt, ...) {
    if (!g_log) return;
    lock_on(&g_lock);
    time_t t = time(0); struct tm* tmv = localtime(&t);
    fprintf(g_log, "%02d:%02d:%02d ", tmv ? tmv->tm_hour : 0, tmv ? tmv->tm_min : 0, tmv ? tmv->tm_sec : 0);
    va_list ap; va_start(ap, fmt); vfprintf(g_log, fmt, ap); va_end(ap);
    fputc('\n', g_log); fflush(g_log);
    lock_off(&g_lock);
}

// First few calls of each function are logged, then every 2000th, so per-frame calls do not flood the log.
#define CALL(name) do { ensure_ready(); static long n_ = 0; long c_ = ++n_; if (c_ <= 3) logf_("call %s", name); else if (c_ % 2000 == 0) logf_("call %s (x%ld)", name, c_); } while (0)

static int result_from_text(const char* v) {
    static const struct { const char* n; int v; } known[] = {
        {"EOS_Success", 0}, {"EOS_NoConnection", 1}, {"EOS_InvalidCredentials", 2}, {"EOS_InvalidUser", 3}, {"EOS_InvalidAuth", 4},
        {"EOS_AccessDenied", 5}, {"EOS_InvalidParameters", 10}, {"EOS_NotConfigured", 14}, {"EOS_NotImplemented", 16},
        {"EOS_Canceled", 17}, {"EOS_NotFound", 18}, {"EOS_LimitExceeded", 22}, {"EOS_Disabled", 23},
    };
    for (unsigned i = 0; i < sizeof(known) / sizeof(known[0]); i++) if (!strcmp(v, known[i].n)) return known[i].v;
    return atoi(v);
}

static EOS_EResult result_for(const char* fn, EOS_EResult def) {
    for (int i = 0; i < g_nover; i++) if (!strcmp(g_over[i].name, fn)) return (EOS_EResult)g_over[i].value;
    return def;
}

static void trim(char* s) {
    size_t n = strlen(s);
    while (n && (s[n - 1] == '\r' || s[n - 1] == '\n' || s[n - 1] == ' ' || s[n - 1] == '\t')) s[--n] = 0;
}

static int is_hex32(const char* s) {
    if (strlen(s) != 32) return 0;
    for (int i = 0; i < 32; i++) { char c = s[i]; if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return 0; }
    return 1;
}

static void load_config(void) {
    char path[1200];
    snprintf(path, sizeof(path), "%s/eos_offline.ini", g_dir);
    FILE* f = fopen(path, "r");
    if (!f) {
        f = fopen(path, "w");
        if (f) {
            fprintf(f, "; eos_offline settings. Lines starting with ; are comments.\n"
                       "DisplayName=%s\n"
                       "; To change what one function reports, add a line such as:\n"
                       ";   EOS_Lobby_CreateLobby=EOS_Success\n", g_displayName);
            fclose(f);
        }
        return;
    }
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        trim(line);
        if (!line[0] || line[0] == ';' || line[0] == '#') continue;
        char* eq = strchr(line, '=');
        if (!eq) continue;
        *eq = 0; char* key = line; char* val = eq + 1; trim(key);
        while (*val == ' ') val++;
        if (!strcmp(key, "DisplayName")) { if (val[0]) snprintf(g_displayName, sizeof(g_displayName), "%s", val); }
        else if (!strcmp(key, "LoadOnceDelaySeconds")) { int v = atoi(val); if (v >= 0 && v <= 600) g_loadDelay = v; }
        else if (!strcmp(key, "EpicAccountId")) { if (is_hex32(val)) strcpy(g_epicId, val); }
        else if (!strcmp(key, "ProductUserId")) { if (is_hex32(val)) strcpy(g_productId, val); }
        else if (!strncmp(key, "EOS_", 4) && g_nover < (int)(sizeof(g_over) / sizeof(g_over[0])) && strlen(key) < sizeof(g_over[0].name)) {
            strcpy(g_over[g_nover].name, key); g_over[g_nover].value = result_from_text(val); g_nover++;
        }
    }
    fclose(f);
}

static void ensure_ready(void) {
    if (g_ready) return;
    lock_init(&g_lock);
    g_ready = 1;
    const char* env = getenv("EOS_OFFLINE_DIR");
    if (env && env[0] && strlen(env) < sizeof(g_dir) - 1) strcpy(g_dir, env);
#ifdef _WIN32
    else {
        HMODULE mod = 0; char p[1024];
        if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCSTR)&ensure_ready, &mod) && mod) {
            DWORD n = GetModuleFileNameA(mod, p, sizeof(p));
            if (n > 0 && n < sizeof(p)) { char* s = strrchr(p, '\\'); if (s) { *s = 0; strcpy(g_dir, p); } }
        }
    }
#endif
    char path[1200];
    snprintf(path, sizeof(path), "%s/eos_offline.log", g_dir);
    g_log = fopen(path, "a");
    load_config();
    {
        char trig[1200], done[1200];
        snprintf(trig, sizeof(trig), "%s/load_once.txt", g_dir);
        snprintf(done, sizeof(done), "%s/load_once.done.txt", g_dir);
        FILE* tf = fopen(trig, "r");
        if (tf) {
            if (fgets(g_loadOnce, sizeof(g_loadOnce), tf)) trim(g_loadOnce); else g_loadOnce[0] = 0;
            fclose(tf);
            remove(done); rename(trig, done);
        }
    }
    logf_("==== eos_offline started. player \"%s\", settings folder %s, %d override(s) ====", g_displayName, g_dir, g_nover);
}

// ------------------------------------------------------------------ handles and ids
// Interface handles are opaque to the game; any distinct non-null pointers will do.
static char g_handles[64];
#define HANDLE_OF(type, n) ((type)(void*)&g_handles[n])

// Account ids are opaque pointers too. Ours point at small records holding the id text.
struct IdRec { char kind; char text[40]; };
static IdRec g_ids[256];
static int g_nids = 0;

static IdRec* id_intern(char kind, const char* text) {
    if (!text || !text[0] || strlen(text) >= sizeof(g_ids[0].text)) return 0;
    lock_on(&g_lock);
    IdRec* r = 0;
    for (int i = 0; i < g_nids; i++) if (g_ids[i].kind == kind && !strcmp(g_ids[i].text, text)) { r = &g_ids[i]; break; }
    if (!r && g_nids < (int)(sizeof(g_ids) / sizeof(g_ids[0]))) { r = &g_ids[g_nids++]; r->kind = kind; strcpy(r->text, text); }
    lock_off(&g_lock);
    return r;
}
static int id_ours(const void* p) { return p >= (const void*)&g_ids[0] && p < (const void*)&g_ids[sizeof(g_ids) / sizeof(g_ids[0])]; }
static EOS_EpicAccountId self_epic(void) { return (EOS_EpicAccountId)id_intern('E', g_epicId); }
static EOS_ProductUserId self_product(void) { return (EOS_ProductUserId)id_intern('P', g_productId); }

static EOS_EResult id_to_string(const void* id, char* out, int32_t* inoutLen) {
    if (!id || !out || !inoutLen || !id_ours(id)) return EOS_InvalidParameters;
    const IdRec* r = (const IdRec*)id;
    int32_t need = (int32_t)strlen(r->text) + 1;
    if (*inoutLen < need) { *inoutLen = need; return EOS_LimitExceeded; }
    memcpy(out, r->text, need); *inoutLen = need;
    return EOS_Success;
}

static EOS_NotificationId next_notification(void) { static uint64_t n = 1000; return (EOS_NotificationId)(++n); }

// ------------------------------------------------------------------ completion queue
// Like the real SDK, results are delivered later, from inside EOS_Platform_Tick, on the caller's thread.
struct Pending { void (*fn)(const void*); void* info; const char* name; EOS_EResult result; Pending* next; };
static Pending* g_head = 0;
static Pending* g_tail = 0;

static void push_pending(const char* name, void (*fn)(const void*), void* info, EOS_EResult result) {
    Pending* p = (Pending*)calloc(1, sizeof(Pending));
    p->fn = fn; p->info = info; p->name = name; p->result = result;
    lock_on(&g_lock);
    if (g_tail) g_tail->next = p; else g_head = p;
    g_tail = p;
    lock_off(&g_lock);
}

static void maybe_load_once(void) {
    if (!g_loadOnce[0] || g_loadDone || !g_signedInAt || time(0) - g_signedInAt < g_loadDelay) return;
    g_loadDone = 1;
    logf_("one-time load: %s", g_loadOnce);
#ifdef _WIN32
    HMODULE h = LoadLibraryA(g_loadOnce);
    if (h) logf_("one-time load: loaded"); else logf_("one-time load: FAILED, Windows error %lu", (unsigned long)GetLastError());
#else
    logf_("one-time load: (not on Windows, skipped)");
#endif
}

static void fill_local_user(EOS_EpicAccountId* p) { if (!*p) *p = self_epic(); }
static void fill_local_user(EOS_ProductUserId* p) { if (!*p) *p = self_product(); }
static void fill_local_user(...) {}

template <class Info, class Cb, class Opt>
static void complete(const char* name, Cb cb, void* clientData, EOS_EResult def, const Opt* opt) {
    EOS_EResult r = result_for(name, def);
    if (!cb) { logf_("  %s: no callback given", name); return; }
    Info* info = (Info*)calloc(1, sizeof(Info));
    if constexpr (requires { info->ResultCode; }) info->ResultCode = r;
    if constexpr (requires { info->ClientData; }) info->ClientData = clientData;
    if constexpr (requires { info->LocalUserId = opt->LocalUserId; }) { if (opt) info->LocalUserId = opt->LocalUserId; }
    if constexpr (requires { info->TargetUserId = opt->TargetUserId; }) { if (opt) info->TargetUserId = opt->TargetUserId; }
    if constexpr (requires { info->LocalUserId; }) fill_local_user(&info->LocalUserId);
    push_pending(name, (void (*)(const void*))cb, info, r);
}

#include "overrides.inc"
#include "generated.inc"
