// Test harness: walks the engine's sign-in sequence against the stand-in, then calls every function
// the game uses with empty arguments (and a callback where one is expected) to check nothing crashes.
#define EOS_BUILDING_SDK 0
#include "eos_sdk.h"
#include "eos_auth.h"
#include "eos_connect.h"
#include "eos_userinfo.h"
#include "eos_friends.h"
#include "eos_presence.h"
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
using enum EOS_EResult; using enum EOS_ELoginStatus;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static EOS_EpicAccountId gEpic; static EOS_ProductUserId gProd; static int gAuthCb, gConnCb, gInfoCb, gFriendsCb, gPresCb;
static void onAuth(const EOS_Auth_LoginCallbackInfo* d) { gAuthCb++; CHECK(d->ResultCode == EOS_Success); CHECK(d->ClientData == (void*)0x1234); gEpic = d->LocalUserId; CHECK(d->SelectedAccountId == d->LocalUserId); }
static void onConn(const EOS_Connect_LoginCallbackInfo* d) { gConnCb++; CHECK(d->ResultCode == EOS_Success); gProd = d->LocalUserId; }
static void onInfo(const EOS_UserInfo_QueryUserInfoCallbackInfo* d) { gInfoCb++; CHECK(d->ResultCode == EOS_Success); CHECK(d->LocalUserId == gEpic); CHECK(d->TargetUserId == gEpic); }
static void onFriends(const EOS_Friends_QueryFriendsCallbackInfo* d) { gFriendsCb++; CHECK(d->ResultCode == EOS_Success); CHECK(d->LocalUserId == gEpic); }
static void onPres(const EOS_Presence_QueryPresenceCallbackInfo* d) { gPresCb++; CHECK(d->ResultCode == EOS_Success); }

static int gSweepCb = 0;
static void sweepCb(const void* info) { gSweepCb++; (void)*(const int*)info; }
struct Sweep { const char* name; int cb; int notify; };
static const Sweep sweeps[] = {
#include "sweep.inc"
};

int main(int argc, char** argv) {
    // --- 1. the sign-in sequence, with real types
    EOS_InitializeOptions io = {}; io.ApiVersion = EOS_INITIALIZE_API_LATEST; io.ProductName = "Dauntless"; io.ProductVersion = "test";
    CHECK(EOS_Initialize(&io) == EOS_Success);
    EOS_Platform_Options po = {}; EOS_HPlatform plat = EOS_Platform_Create(&po); CHECK(plat != 0);
    EOS_HAuth auth = EOS_Platform_GetAuthInterface(plat); EOS_HConnect conn = EOS_Platform_GetConnectInterface(plat);
    EOS_HUserInfo ui = EOS_Platform_GetUserInfoInterface(plat); EOS_HFriends fr = EOS_Platform_GetFriendsInterface(plat); EOS_HPresence pr = EOS_Platform_GetPresenceInterface(plat);
    CHECK(auth && conn && ui && fr && pr && (void*)auth != (void*)conn);
    CHECK(EOS_Auth_GetLoginStatus(auth, 0) == EOS_LS_NotLoggedIn); CHECK(EOS_Auth_GetLoggedInAccountsCount(auth) == 0);

    EOS_Auth_Credentials cr = {}; cr.ApiVersion = EOS_AUTH_CREDENTIALS_API_LATEST; cr.Type = EOS_ELoginCredentialType::EOS_LCT_AccountPortal;
    EOS_Auth_LoginOptions lo = {}; lo.ApiVersion = EOS_AUTH_LOGIN_API_LATEST; lo.Credentials = &cr;
    EOS_Auth_Login(auth, &lo, (void*)0x1234, onAuth);
    CHECK(gAuthCb == 0);                      // not before the next tick
    EOS_Platform_Tick(plat); CHECK(gAuthCb == 1); CHECK(gEpic != 0);
    CHECK(EOS_EpicAccountId_IsValid(gEpic)); CHECK(EOS_Auth_GetLoginStatus(auth, gEpic) == EOS_LS_LoggedIn);
    CHECK(EOS_Auth_GetLoggedInAccountsCount(auth) == 1); CHECK(EOS_Auth_GetLoggedInAccountByIndex(auth, 0) == gEpic);
    char buf[64]; int32_t len = sizeof(buf); CHECK(EOS_EpicAccountId_ToString(gEpic, buf, &len) == EOS_Success); CHECK(strlen(buf) == 32); CHECK(len == 33);
    CHECK(EOS_EpicAccountId_FromString(buf) == gEpic);
    int32_t small = 5; CHECK(EOS_EpicAccountId_ToString(gEpic, buf, &small) == EOS_LimitExceeded); CHECK(small == 33);

    EOS_Auth_CopyUserAuthTokenOptions to = {}; to.ApiVersion = EOS_AUTH_COPYUSERAUTHTOKEN_API_LATEST; EOS_Auth_Token* tok = 0;
    CHECK(EOS_Auth_CopyUserAuthToken(auth, &to, gEpic, &tok) == EOS_Success); CHECK(tok && tok->AccessToken && tok->AccountId == gEpic);
    printf("access token: %.40s... (%zu chars)\n", tok->AccessToken, strlen(tok->AccessToken));
    CHECK(strncmp(tok->AccessToken, "eyJ", 3) == 0);
    FILE* tf = fopen("token.txt", "w"); fputs(tok->AccessToken, tf); fclose(tf);

    EOS_Connect_Credentials cc = {}; cc.ApiVersion = EOS_CONNECT_CREDENTIALS_API_LATEST; cc.Token = tok->AccessToken; cc.Type = EOS_EExternalCredentialType::EOS_ECT_EPIC;
    EOS_Connect_LoginOptions clo = {}; clo.ApiVersion = EOS_CONNECT_LOGIN_API_LATEST; clo.Credentials = &cc;
    EOS_Connect_Login(conn, &clo, 0, onConn); EOS_Auth_Token_Release(tok);
    EOS_Platform_Tick(plat); CHECK(gConnCb == 1); CHECK(gProd != 0); CHECK(EOS_ProductUserId_IsValid(gProd)); CHECK(!EOS_EpicAccountId_IsValid((EOS_EpicAccountId)gProd));
    CHECK(EOS_Connect_GetLoginStatus(conn, gProd) == EOS_LS_LoggedIn); CHECK(EOS_Connect_GetLoggedInUserByIndex(conn, 0) == gProd);

    EOS_Connect_GetProductUserIdMappingOptions mo = {}; mo.LocalUserId = gProd; mo.TargetProductUserId = gProd; mo.AccountIdType = EOS_EExternalAccountType::EOS_EAT_EPIC;
    len = sizeof(buf); char epicText[64]; int32_t l2 = sizeof(epicText); EOS_EpicAccountId_ToString(gEpic, epicText, &l2);
    CHECK(EOS_Connect_GetProductUserIdMapping(conn, &mo, buf, &len) == EOS_Success); CHECK(!strcmp(buf, epicText));
    EOS_Connect_GetExternalAccountMappingsOptions eo = {}; eo.LocalUserId = gProd; eo.TargetExternalUserId = epicText; CHECK(EOS_Connect_GetExternalAccountMapping(conn, &eo) == gProd);
    EOS_Connect_GetProductUserExternalAccountCountOptions co = {}; co.TargetUserId = gProd; CHECK(EOS_Connect_GetProductUserExternalAccountCount(conn, &co) == 1);
    EOS_Connect_CopyProductUserExternalAccountByIndexOptions xo = {}; xo.TargetUserId = gProd; EOS_Connect_ExternalAccountInfo* xi = 0;
    CHECK(EOS_Connect_CopyProductUserExternalAccountByIndex(conn, &xo, &xi) == EOS_Success); CHECK(xi && !strcmp(xi->AccountId, epicText)); EOS_Connect_ExternalAccountInfo_Release(xi);

    EOS_UserInfo_QueryUserInfoOptions qo = {}; qo.LocalUserId = gEpic; qo.TargetUserId = gEpic; EOS_UserInfo_QueryUserInfo(ui, &qo, 0, onInfo);
    EOS_Friends_QueryFriendsOptions fo = {}; fo.LocalUserId = gEpic; EOS_Friends_QueryFriends(fr, &fo, 0, onFriends);
    EOS_Presence_QueryPresenceOptions pqo = {}; pqo.LocalUserId = gEpic; pqo.TargetUserId = gEpic; EOS_Presence_QueryPresence(pr, &pqo, 0, onPres);
    EOS_Platform_Tick(plat); CHECK(gInfoCb == 1 && gFriendsCb == 1 && gPresCb == 1);
    EOS_UserInfo_CopyUserInfoOptions cuo = {}; cuo.LocalUserId = gEpic; cuo.TargetUserId = gEpic; EOS_UserInfo* info = 0;
    CHECK(EOS_UserInfo_CopyUserInfo(ui, &cuo, &info) == EOS_Success); CHECK(info && info->DisplayName && info->Country && info->PreferredLanguage);
    printf("display name: %s\n", info->DisplayName); EOS_UserInfo_Release(info);
    EOS_Friends_GetFriendsCountOptions gco = {}; gco.LocalUserId = gEpic; CHECK(EOS_Friends_GetFriendsCount(fr, &gco) == 0);
    CHECK(!strcmp(EOS_EResult_ToString(EOS_NotFound), "EOS_NotFound")); CHECK(EOS_EResult_IsOperationComplete(EOS_Success));
    printf("sign-in sequence: %s\n", fails ? "FAILED" : "ok");

    // --- 2. every function the game uses, with empty arguments
    void* lib = dlopen(argv[1], RTLD_NOW); CHECK(lib != 0);
    typedef intptr_t (*Fn6)(intptr_t, intptr_t, intptr_t, intptr_t, intptr_t, intptr_t);
    int called = 0, missing = 0, expectCb = 0;
    for (unsigned i = 0; i < sizeof(sweeps) / sizeof(sweeps[0]); i++) {
        const Sweep& s = sweeps[i];
        if (!strcmp(s.name, "EOS_Shutdown") || !strcmp(s.name, "EOS_Platform_Release")) continue;
        Fn6 f = (Fn6)dlsym(lib, s.name);
        if (!f) { printf("MISSING export %s\n", s.name); missing++; continue; }
        intptr_t a[6] = {0, 0, 0, 0, 0, 0};
        if (s.cb >= 0 && s.cb < 6) { a[s.cb] = (intptr_t)&sweepCb; if (!s.notify) expectCb++; }
        f(a[0], a[1], a[2], a[3], a[4], a[5]); called++;
    }
    EOS_Platform_Tick(plat);
    printf("sweep: %d functions called, %d missing, %d completions fired of %d expected\n", called, missing, gSweepCb, expectCb);
    CHECK(missing == 0); CHECK(gSweepCb == expectCb);
    printf("%s\n", fails ? "RESULT: FAILED" : "RESULT: all checks passed");
    return fails ? 1 : 0;
}
