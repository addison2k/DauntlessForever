eos_offline - source for the offline stand-in for EOSSDK-Win64-Shipping.dll (EOS SDK 1.16.0 interface)

What it is
  A replacement for Epic's sign-in component, for running the Dauntless 2.1.1 client alone and offline
  against a private local backend after the official servers shut down. It answers every call locally,
  makes no network connections and starts no programs. It imports only the Windows C runtime and
  eleven kernel32 functions (locks, module path, memory queries).

Files
  eos_offline.cpp   set-up, log, settings, ids, the queue that delivers results on EOS_Platform_Tick
  overrides.inc     hand-written functions: start-up, the local player's ids and name, sign-in
  gen.py            writes generated.inc: default answers for the other functions, from the SDK headers
  generated.inc     output of gen.py (233 functions)
  names.txt         the 272 EOS function names found in the game executable
  harness.cpp       test: walks the engine's sign-in sequence, then calls all 272 functions
  sweep.inc         table used by the harness

Not included
  Epic's EOS SDK 1.16.0 header files (Epic's licence). They are needed only to build. Put the SDK's
  Include folder somewhere and pass it as INC below.

Build (zig 0.17 as the compiler; any clang with C++20 works)
  python3 gen.py $INC names.txt overrides.inc > generated.inc
  zig cc -x c++ -target x86_64-windows-gnu -std=c++20 -O2 -fno-exceptions -fno-rtti -shared -s \
      -I$INC eos_offline.cpp -o EOSSDK-Win64-Shipping.dll

Test (Linux)
  zig c++ -std=c++20 -fno-exceptions -fno-rtti -fPIC -shared -I$INC eos_offline.cpp -o libeos_offline.so
  zig c++ -std=c++20 -I$INC harness.cpp -L. -leos_offline -Wl,-rpath,'$ORIGIN' -ldl -o harness
  EOS_OFFLINE_DIR=$PWD ./harness ./libeos_offline.so

Runtime files (in the folder named by EOS_OFFLINE_DIR, else next to the DLL)
  eos_offline.log   every call, first three times each, then every 2000th
  eos_offline.ini   DisplayName=..., and per-function result overrides such as EOS_Lobby_CreateLobby=EOS_Success
