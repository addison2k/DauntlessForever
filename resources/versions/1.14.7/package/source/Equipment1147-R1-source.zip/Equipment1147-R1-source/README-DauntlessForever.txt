Equipment Fix 1.14.7 R1 by KombatKing (AGPL-3.0-only), as shipped in the Dauntless Forever 1.14.7 package.
- bin\dxgi.dll is built from d1147.cpp + equipment_bridge.h here (Addison2k's 1.14.7 loader fix5 plus KombatKing's
  ability-activation bridge). Build line in BUILD.md (Zig 0.17.0). Checked: rebuilding gives the same code section.
- bin\zzzzzzzz_Equipment1147_P.pak is made by build_catalog.py (Recruit's Repeaters: inventory kind Sword -> Repeater).
Left out on purpose: the original game files build_catalog.py reads (Source/Inputs in KombatKing's release) and the
debug symbols. Take the inputs from your own 1.14.7 game. Game content keeps its original rights.
