# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import struct,json

def fs(b,o):
 n=struct.unpack_from('<i',b,o)[0];o+=4;sz=-n*2 if n<0 else n
 assert 0<=sz<=len(b)-o,(o,n)
 return (b[o:o+sz-(2 if n<0 else 1)].decode('utf-16le'if n<0 else'utf-8')if n else''),o+sz
class Asset:
 def __init__(self,p):
  self.path=Path(p);self.ua=self.path.read_bytes();self.b=self.path.with_suffix('.uexp').read_bytes();u=self.ua;assert u[:4]==bytes.fromhex('c1832a9e');assert struct.unpack_from('<i',u,4)[0]==-7;assert struct.unpack_from('<I',u,20)[0]==0
  _,o=fs(u,28);o+=4;n,at=struct.unpack_from('<II',u,o);self.names=[]
  for _ in range(n):s,at=fs(u,at);self.names.append(s);at+=4
  count,offset=struct.unpack_from('<II',u,65);self.imports=[]
  def uname(at):
   ix,num=struct.unpack_from('<II',u,at);return self.names[ix]+('_'+str(num-1)if num else'')
  for i in range(count):
   pos=offset+i*28;self.imports.append({'class':uname(pos+8),'outer':struct.unpack_from('<i',u,pos+16)[0],'name':uname(pos+20)})
  n,at=struct.unpack_from('<II',u,57);self.exports=[]
  for i in range(n):
   pos=at+i*104;namei,num=struct.unpack_from('<II',u,pos+16);size,off=struct.unpack_from('<qq',u,pos+28);start=off-len(u);assert 0<=start<=start+size<=len(self.b)-4
   self.exports.append({'index':i+1,'name':self.names[namei]+('_'+str(num-1)if num else''),'start':start,'size':size,'class_index':struct.unpack_from('<i',u,pos)[0],'outer_index':struct.unpack_from('<i',u,pos+12)[0]})
 def object(self,index):
  if index==0:return None
  if index>0:return self.exports[index-1]['name']
  item=self.imports[-index-1];outer=self.object(item['outer'])
  return (outer+'.'+item['name'])if outer else item['name']
 def name(self,o):
  i,n=struct.unpack_from('<II',self.b,o);assert i<len(self.names),(o,i);return self.names[i]+('_'+str(n-1)if n else''),o+8
 def tag(self,o):
  name,o=self.name(o)
  if name=='None':return {'name':name,'end':o}
  typ,o=self.name(o);size,index=struct.unpack_from('<II',self.b,o);o+=8;t={'name':name,'type':typ,'size':size}
  if typ=='StructProperty':t['struct'],o=self.name(o);o+=16
  elif typ in ['ArrayProperty','SetProperty','ByteProperty','EnumProperty']:t['inner'],o=self.name(o)
  elif typ=='MapProperty':t['key'],o=self.name(o);t['value'],o=self.name(o)
  elif typ=='BoolProperty':t['bool']=bool(self.b[o]);o+=1
  guid=self.b[o];o+=1
  if guid:o+=16
  t.update(start=o,end=o+size);assert t['end']<=len(self.b);return t
 def properties(self,o,prefix='',flat=None):
  if flat is None:flat=[]
  while True:
   t=self.tag(o)
   if t['name']=='None':return t['end'],flat
   key=prefix+'/'+t['name'];pos=t['start'];typ=t['type'];v=None
   if typ in ['NameProperty','EnumProperty']:v=self.name(pos)[0]
   elif typ=='ByteProperty':v=self.name(pos)[0]if t['size']==8 else self.b[pos]
   elif typ=='StrProperty':v=fs(self.b,pos)[0]
   elif typ in ['IntProperty','ObjectProperty']:v=struct.unpack_from('<i',self.b,pos)[0]
   elif typ=='FloatProperty':v=struct.unpack_from('<f',self.b,pos)[0]
   elif typ=='Int64Property':v=struct.unpack_from('<q',self.b,pos)[0]
   elif typ=='BoolProperty':v=t['bool']
   elif typ=='TextProperty':
    hist=struct.unpack_from('<b',self.b,pos+4)[0]
    if hist==11:
     table,p=self.name(pos+5);k,p=fs(self.b,p);v={'table':table,'key':k}
    elif hist==0:
     ns,p=fs(self.b,pos+5);k,p=fs(self.b,p);source,p=fs(self.b,p);v={'namespace':ns,'key':k,'source':source}
    else:v={'history':hist}
   elif typ=='StructProperty':
    try:
     if t['struct'] in ['SoftClassPath','SoftObjectPath']:
      asset,q=self.name(pos);sub,q=fs(self.b,q);assert q==t['end'];flat.append({'path':key,'type':t['struct'],'value':asset+(':'+sub if sub else'')})
     else:self.properties(pos,key,flat)
    except (AssertionError,struct.error,UnicodeError):flat.append({'path':key,'type':'raw-struct','struct':t['struct']})
   elif typ=='ArrayProperty':
    n=struct.unpack_from('<I',self.b,pos)[0];pos+=4
    if t['inner']=='StructProperty':
     inner=self.tag(pos);pos=inner['start']
     for i in range(n):pos,_=self.properties(pos,key+f'[{i}]',flat)
     assert pos==t['end'],(key,pos,t['end'])
    elif t['inner']=='ObjectProperty':v=list(struct.unpack_from('<'+'i'*n,self.b,pos))
   if v is not None:flat.append({'path':key,'type':typ,'value':v})
   o=t['end']
 def decode(self):
  result=[]
  for e in self.exports:
   try:end,fields=self.properties(e['start']);result.append({**e,'fields':fields})
   except Exception as err:result.append({**e,'error':str(err)})
  return result
if __name__=='__main__':
 import sys
 a=Asset(sys.argv[1]);result=a.decode();print('exports',len(result),'errors',sum('error'in x for x in result));Path(sys.argv[1]+'.decoded.json').write_text(json.dumps(result,indent=2,ensure_ascii=False));print(json.dumps(result[:3],indent=2))
