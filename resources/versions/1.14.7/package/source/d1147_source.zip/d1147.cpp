// Dauntless Forever - Dauntless 1.14.7 server loader (dxgi.dll)
// Copyright (C) 2026 Addison2k. https://github.com/addison2k/DauntlessForever
// Licence: AGPL-3.0-only. Keep this notice: the licence requires it.
// d1147 server loader for Dauntless 1.14.7 (CL 647472, UE 4.26.2) - milestone 1: boot in server mode, open a port,
// send the world to the player.
//
// This file builds a DLL named dxgi.dll. The game loads dxgi.dll at start, so placing this one beside the exe gets
// our code in before the engine initialises. It forwards every dxgi call to the real system DLL.
//
//   - Without the environment variable D1147_SERVER=1 it does nothing else (the normal game is unaffected).
//   - With it, it switches this copy of the game into server mode and, once a world is loaded, opens a UDP
//     listening port (D1147_PORT, default 8780) and sends the world to each connected player.
//
// The approach (run the retail client as a server by driving the networking code that is still in the exe) is the
// one used by the Undaunted project (gwog and contributors, AGPL-3.0); this file is a new implementation for the
// 1.14.7 build, carrying over the fixes of the Undaunted 1.6.2 port and of the 2.1.1 loader. All addresses are
// specific to this one exe; the exe is identified before anything is changed, and each patch checks its bytes.
#include <windows.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdint.h>
#include <string.h>
#include "minhook/MinHook.h"

// ---------------------------------------------------------------------------- dxgi forwarding
// Each export forwards to the same function in the system dxgi.dll. Version 2c-fix2 (Oct 13, 2026). 2c-fix followed a
// crash at address 0 on Windows 11 25H2 (build 26200); 2c-fix2 follows its first report from that PC: the system DLL
// failed to load on the first call (error 1168, made during process start-up) and 2c-fix never tried again, so every
// graphics call answered "not available" and the game never showed. Now a failed load is retried on later calls (the
// game's own calls come long after start-up), with two fallbacks: LoadLibraryEx from System32, then a copy of the
// system DLL under another name in %TEMP% (in case Windows refuses a second module called dxgi.dll).
//   - the system DLL is loaded on the first call, not inside DllMain (LoadLibrary under the loader lock);
//   - a function the system DLL does not have (Windows changes its private exports) answers a safe "no" instead of
//     jumping to address 0: 0 for the compatibility/void ones, E_NOTIMPL (0x80004001) for the HRESULT ones;
//   - anything missing is written once to %LOCALAPPDATA%\d1147_dxgi.log so the next report names it.
// X(name, value returned when the system DLL lacks the function)
#define DXGI_EXPORTS(X) \
    X(ApplyCompatResolutionQuirking, 0) X(CompatString, 0) X(CompatValue, 0) \
    X(CreateDXGIFactory, 0x80004001) X(CreateDXGIFactory1, 0x80004001) X(CreateDXGIFactory2, 0x80004001) \
    X(DXGID3D10CreateDevice, 0x80004001) X(DXGID3D10CreateLayeredDevice, 0x80004001) X(DXGID3D10GetLayeredDeviceSize, 0) \
    X(DXGID3D10RegisterLayers, 0x80004001) X(DXGIDeclareAdapterRemovalSupport, 0x80004001) \
    X(DXGIDisableVBlankVirtualization, 0x80004001) X(DXGIDumpJournal, 0x80004001) X(DXGIGetDebugInterface1, 0x80004001) \
    X(DXGIReportAdapterConfiguration, 0x80004001) X(PIXBeginCapture, 0x80004001) X(PIXEndCapture, 0x80004001) \
    X(PIXGetCaptureState, 0) X(SetAppCompatStringPointer, 0) X(UpdateHMDEmulationStatus, 0)

static void dxgi_note(const char* text) {          // plain Win32 only: may run under the loader lock
    wchar_t path[MAX_PATH + 32];
    DWORD n = GetEnvironmentVariableW(L"LOCALAPPDATA", path, MAX_PATH);
    if (!n || n >= MAX_PATH) return;
    wcscat(path, L"\\d1147_dxgi.log");
    HANDLE f = CreateFileW(path, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE, 0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
    if (f == INVALID_HANDLE_VALUE) return;
    SYSTEMTIME t; GetLocalTime(&t);
    char line[256];
    int len = snprintf(line, sizeof(line), "%04d-%02d-%02d %02d:%02d:%02d pid %lu: %s\r\n", t.wYear, t.wMonth, t.wDay, t.wHour,
                        t.wMinute, t.wSecond, (unsigned long)GetCurrentProcessId(), text);
    if (len < 0) return; if (len > (int)sizeof(line) - 1) len = (int)sizeof(line) - 1;
    DWORD w; WriteFile(f, line, (DWORD)len, &w, 0);
    CloseHandle(f);
}

extern "C" {
#define X(name, fallback) void* d1147_real_##name = 0;
DXGI_EXPORTS(X)
#undef X

static SRWLOCK g_dxgiLock = SRWLOCK_INIT;
static volatile LONG g_dxgiLoaded = 0;    // 1 once the system DLL is loaded and the pointers are filled
static LONG g_dxgiTries = 0;              // failed attempts so far (each later call retries)

static HMODULE own_module(void) {
    HMODULE m = 0;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                       (LPCWSTR)(void*)&own_module, &m);
    return m;
}
// A loaded module is only usable if it is not this DLL itself (asking Windows for "dxgi.dll" can hand back ours).
static HMODULE usable(HMODULE m, HMODULE self) {
    if (m && m == self) { FreeLibrary(m); return 0; }
    return m;
}
static HMODULE try_load_system_dxgi(char* how, size_t howLen, DWORD* errs) {
    HMODULE self = own_module();
    wchar_t sys[MAX_PATH + 16];
    UINT n = GetSystemDirectoryW(sys, MAX_PATH);
    if (!n || n >= MAX_PATH) { errs[0] = errs[1] = errs[2] = GetLastError(); return 0; }
    wcscat(sys, L"\\dxgi.dll");
    // 1. the system DLL by its full path
    SetLastError(0);
    HMODULE m = usable(LoadLibraryExW(sys, 0, 0), self);
    if (m) { snprintf(how, howLen, "System32 path"); return m; }
    errs[0] = GetLastError();
    // 2. by name, searching System32 only
    SetLastError(0);
    m = usable(LoadLibraryExW(L"dxgi.dll", 0, LOAD_LIBRARY_SEARCH_SYSTEM32), self);
    if (m) { snprintf(how, howLen, "System32 search"); return m; }
    errs[1] = GetLastError();
    // 3. a copy under another name, so no "dxgi.dll is already loaded" rule applies
    wchar_t copy[MAX_PATH + 64];
    DWORD t = GetTempPathW(MAX_PATH, copy);
    if (!t || t >= MAX_PATH) { errs[2] = GetLastError(); return 0; }
    wcscat(copy, L"d1147_system_dxgi.dll");
    WIN32_FILE_ATTRIBUTE_DATA a, b;
    BOOL same = GetFileAttributesExW(sys, GetFileExInfoStandard, &a) && GetFileAttributesExW(copy, GetFileExInfoStandard, &b) &&
                a.nFileSizeLow == b.nFileSizeLow && a.nFileSizeHigh == b.nFileSizeHigh &&
                CompareFileTime(&a.ftLastWriteTime, &b.ftLastWriteTime) == 0;
    if (!same) CopyFileW(sys, copy, FALSE);
    SetLastError(0);
    m = usable(LoadLibraryExW(copy, 0, LOAD_WITH_ALTERED_SEARCH_PATH), self);
    if (m) { snprintf(how, howLen, "copy in TEMP"); return m; }
    errs[2] = GetLastError();
    return 0;
}

void d1147_resolve_dxgi(void) {
    if (g_dxgiLoaded) return;
    AcquireSRWLockExclusive(&g_dxgiLock);
    if (!g_dxgiLoaded) {
        char how[32] = "", msg[200];
        DWORD errs[3] = {0, 0, 0};
        HMODULE real = try_load_system_dxgi(how, sizeof(how), errs);
        if (!real) {
            LONG k = ++g_dxgiTries;
            if (k <= 5 || k == 20 || k == 100 || k % 1000 == 0) {
                snprintf(msg, sizeof(msg), "dxgi forwarding: attempt %ld, system dxgi.dll did not load (errors %lu / %lu / %lu); will retry on the next call",
                         (long)k, (unsigned long)errs[0], (unsigned long)errs[1], (unsigned long)errs[2]);
                dxgi_note(msg);
            }
        } else {
            if (g_dxgiTries || strcmp(how, "System32 path") != 0) {
                snprintf(msg, sizeof(msg), "dxgi forwarding: system dxgi.dll loaded on attempt %ld (%s)", (long)g_dxgiTries + 1, how);
                dxgi_note(msg);
            }
#define X(name, fallback) \
            d1147_real_##name = (void*)GetProcAddress(real, #name); \
            if (!d1147_real_##name) { snprintf(msg, sizeof(msg), "dxgi forwarding: system dxgi.dll has no %s, answering %s", #name, \
                                                (fallback) ? "E_NOTIMPL" : "0"); dxgi_note(msg); }
            DXGI_EXPORTS(X)
#undef X
            InterlockedExchange(&g_dxgiLoaded, 1);
        }
    }
    ReleaseSRWLockExclusive(&g_dxgiLock);
}

// Fast path: jump straight to the system function. Until the system DLL is loaded: save the four argument registers,
// try to load it, restore them and jump. Still not loaded, or the function is missing: return the fallback value
// (the next call tries again).
#define X(name, fallback) \
    __declspec(dllexport) __attribute__((naked)) void name(void) { __asm__( \
        "movq d1147_real_" #name "(%rip), %rax\n\t" \
        "testq %rax, %rax\n\t" \
        "jnz 2f\n\t" \
        "pushq %rcx\n\t pushq %rdx\n\t pushq %r8\n\t pushq %r9\n\t" \
        "subq $40, %rsp\n\t" \
        "call d1147_resolve_dxgi\n\t" \
        "addq $40, %rsp\n\t" \
        "popq %r9\n\t popq %r8\n\t popq %rdx\n\t popq %rcx\n\t" \
        "movq d1147_real_" #name "(%rip), %rax\n\t" \
        "testq %rax, %rax\n\t" \
        "jz 3f\n" \
        "2:\n\t jmpq *%rax\n" \
        "3:\n\t movl $" #fallback ", %eax\n\t ret\n"); }
DXGI_EXPORTS(X)
#undef X
}

// ---------------------------------------------------------------------------- log
static FILE* g_log = 0;
static void logf_(const char* fmt, ...) {
    if (!g_log) return;
    SYSTEMTIME t; GetLocalTime(&t);
    fprintf(g_log, "%02d:%02d:%02d.%03d ", t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
    va_list ap; va_start(ap, fmt); vfprintf(g_log, fmt, ap); va_end(ap);
    fputc('\n', g_log); fflush(g_log);
}

// ---------------------------------------------------------------------------- 1.14.7 addresses (offsets from the exe base)
// How each one was found is in the project doc "Dauntless 1.14.7 - server DLL port map".
namespace A {
    // patches
    const uintptr_t LoadMapListenCall   = 0x4272A80;  // call UWorld::Listen (stub that returns false) inside UEngine::LoadMap
    const uintptr_t PreInitA_Client     = 0x9F4F12;   // GIsClient = (target bits >> 1) & 1   (13 bytes)
    const uintptr_t PreInitA_Server     = 0x9F4F1F;   // GIsServer = target bits & 1          (12 bytes)
    const uintptr_t PreInitB_ClientImm  = 0x9F9439;   // immediate of "mov byte [GIsClient], 1"
    const uintptr_t PreInitC_ServerImm  = 0x9F95F8;   // immediate of "mov byte [GIsServer], 0"
    const uintptr_t PreInitC_Client     = 0x9F95FE;   // mov [GIsClient], r12b (r12b = 1)
    // globals
    const uintptr_t GIsClient           = 0x6E1EAD9;
    const uintptr_t GIsServer           = 0x6E1EADA;
    const uintptr_t GEngine             = 0x6FC3CE8;
    const uintptr_t GWorld              = 0x6FC7F58;
    // engine functions
    const uintptr_t GetNetMode          = 0x42CC560;  // UWorld::InternalGetNetMode: NM_Client whenever a net driver exists
    const uintptr_t ActorGetNetMode     = 0x3B61DE0;  // AActor::InternalGetNetMode: "standalone" whenever it cannot find its net driver
    const uintptr_t ActorGetNetDriver   = 0x3B5DA40;  // AActor::GetNetDriver (Undaunted: GetNetDriver_Internal)
    const uintptr_t GameEngineTick      = 0x3E10AB0;  // UGameEngine::Tick(float, bool)
    const uintptr_t FNameFromEName      = 0x2658800;  // FName::FName(EName)
    const uintptr_t CreateNamedNetDriver= 0x425FD30;  // UEngine::CreateNamedNetDriver(UWorld*, FName, FName)
    const uintptr_t NetDriverSetWorld   = 0x3FAD0B0;  // UNetDriver::SetWorld(UWorld*)
    const uintptr_t SetReplicationDriver= 0x3FACF60;  // UNetDriver::SetReplicationDriver(UReplicationDriver*)
    const uintptr_t IsLevelInitForActor = 0x3F980D0;  // UNetDriver::IsLevelInitializedForActor(const AActor*, const UNetConnection*)
    const uintptr_t IpNetDriverVTable   = 0x504E580;
    const uint32_t  EName_GameNetDriver = 0x11A;
    const uint32_t  EName_Actor         = 0x66;
    const uintptr_t AppendString        = 0x2656410;  // FName::AppendString(FString&)
    const uintptr_t ProcessEvent        = 0x2861880;  // UObject::ProcessEvent(UFunction*, void* Parms)
    const uintptr_t Struct_Super        = 0x40;       // UStruct::SuperStruct
    const uintptr_t Struct_Children     = 0x48;       // UStruct::Children (UField list)
    const uintptr_t Field_Next          = 0x28;       // UField::Next
    // replication (the engine's own "send the world to each player" loop is not in a client build)
    const uintptr_t CallPreReplication  = 0x3B510D0;  // AActor::CallPreReplication(UNetDriver*)
    const uintptr_t SendClientAdjustment= 0x40B8500;  // APlayerController::SendClientAdjustment()
    const uintptr_t CreateChannelByName = 0x3F62E90;  // UNetConnection::CreateChannelByName(const FName&, EChannelCreateFlags, int32)
    const uintptr_t SetChannelActor     = 0x3D8FB20;  // UActorChannel::SetChannelActor(AActor*, ESetChannelActorFlags)
    const uintptr_t ReplicateActor      = 0x3D8A2D0;  // UActorChannel::ReplicateActor() -> int64
    const uintptr_t WeakPtrAssign       = 0x2870E90;  // FWeakObjectPtr::operator=(const UObject*)
    const uintptr_t IsNetReady          = 0x3F71130;  // UNetConnection::IsNetReady(bool)
    // Dauntless functions
    const uintptr_t HasFinishedLoading  = 0x1CB1360;  // ArchonPlayerController::NativeHasFinishedLoading (interface this)
    const uintptr_t SetupPlayerInput    = 0x18DFEA0;  // AArchonCharacter::SetupPlayerInputComponent
    const uintptr_t BountySeasonDates   = 0x19B2970;  // UBountyComponent::GetSeasonDates(FDateTime Now, FDateTime&, FDateTime&)
    const uintptr_t WeeklySeasonDates   = 0x1A0BF90;  // UBountyComponent_Weekly::GetSeasonDates
    const uintptr_t QueryHuntPassSeason = 0x19120D0;
    const uintptr_t SwitchGameWindow    = 0x3E103F0;  // UGameEngine::SwitchGameWindowToUseGameViewport (needs a viewport a server does not have)
    const uintptr_t MessageDialogOpen   = 0x2615D20;  // FMessageDialog::Open(EAppMsgType, const FText&, const FText*)  // UArchonGameInstance::QueryCurrentHuntPassSeasonData(const FScriptDelegate&)
    // object layout (UObject)
    const uintptr_t Object_Flags        = 0x08;
    const uintptr_t Object_Class        = 0x10;
    const uintptr_t Object_Name         = 0x18;
    const uintptr_t Object_Outer        = 0x20;
    const uintptr_t Class_CastFlags     = 0xD0;
    const uint64_t  CastFlag_PlayerController = 0x2000000000ull;
    // AActor
    const uintptr_t Actor_Bits58        = 0x58;       // bit 1 bNetStartup, bit 5 bHidden
    const uintptr_t Actor_Bits5C        = 0x5C;       // bit 3: bActorIsBeingDestroyed
    const uintptr_t Actor_RemoteRole    = 0x5F;
    const uintptr_t Actor_NetDriverName = 0xE8;
    const uintptr_t Actor_NetDormancy   = 0xF1;       // 4 = DORM_Initial
    const uintptr_t VT_SetActorHiddenInGame = 0x308;
    // UWorld / ULevel / FWorldContext / UEngine
    const uintptr_t World_NetworkNotify = 0x28;       // FNetworkNotify sub-object of UWorld
    const uintptr_t World_NetDriver     = 0x38;
    const uintptr_t World_AuthorityGameMode = 0x118;
    const uintptr_t World_Levels        = 0x138;      // TArray<ULevel*>
    const uintptr_t World_GameInstance  = 0x180;
    const uintptr_t Level_Actors        = 0x98;       // TArray<AActor*>
    const uintptr_t Level_Bits1F4       = 0x1F4;      // bit 5: bIsVisible
    const uintptr_t Engine_WorldList    = 0xC38;      // TArray<FWorldContext*>
    const uintptr_t Context_World       = 0x280;
    const uintptr_t Context_ActiveNetDrivers = 0x220; // TArray<FNamedNetDriver> (0x10 each, driver pointer first)
    // UNetDriver / UNetConnection / UChannel
    const uintptr_t Driver_ClientConnections = 0x90;
    const uintptr_t Driver_World        = 0x140;
    const uintptr_t Driver_NetDriverName= 0x190;
    const uintptr_t Driver_Notify       = 0x208;
    const uintptr_t Driver_ReplicationFrame  = 0x2AC;
    const uintptr_t Driver_ReplicationDriver = 0x6E8;
    const uintptr_t VT_InitListen       = 0x290;      // UNetDriver::InitListen(FNetworkNotify*, FURL&, bool, FString&)
    const uintptr_t Conn_ViewTarget     = 0x90;
    const uintptr_t Conn_OwningActor    = 0x98;
    const uintptr_t Conn_State          = 0x134;      // 3 = open
    const uintptr_t Conn_ActorChannels  = 0x1378;     // TMap<TWeakObjectPtr<AActor>, UActorChannel*>
    const uintptr_t Channel_Bits        = 0x30;       // bit 1: Closing
    const uintptr_t Channel_Actor       = 0x70;
    const uintptr_t ActorChannel_Bits   = 0x90;       // bit 1: bForceCompareProperties
    // APlayerController
    const uintptr_t PC_Pawn             = 0x250;
    const uintptr_t PC_PlayerCameraManager = 0x2B8;
    const uintptr_t PC_IsLocalFlag      = 0x57C;      // bIsLocalPlayerController
    const uintptr_t PCM_ViewTargetActor = 0xE70;
}

static uintptr_t g_base = 0;
static int g_port = 8780;
template <class T> static T& at(uintptr_t addr) { return *(T*)addr; }

struct FString { wchar_t* Data; int32_t Num; int32_t Max; };
struct TArrayRaw { void** Data; int32_t Num; int32_t Max; };

// Name of an engine object as text (the small string it allocates is left to the engine).
static const char* name_of(void* obj, char* out, int n) {
    out[0] = 0;
    if (!obj) { snprintf(out, n, "(none)"); return out; }
    FString s = { 0, 0, 0 };
    ((void (*)(void*, FString*))(g_base + A::AppendString))((void*)((uintptr_t)obj + A::Object_Name), &s);
    if (s.Data && s.Num > 0) WideCharToMultiByte(CP_UTF8, 0, s.Data, -1, out, n, 0, 0);
    out[n - 1] = 0;
    return out;
}

// ---------------------------------------------------------------------------- crash notes
static volatile LONG g_inHandler = 0;
static int g_crashNotes = 0;
static DWORD g_gameThread = 0;
static void where(uintptr_t addr, char* out, int n) {
    HMODULE m = 0;
    if (GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)addr, &m) && m) {
        if ((uintptr_t)m == g_base) { snprintf(out, n, "exe+0x%llX", (unsigned long long)(addr - g_base)); return; }
        char path[MAX_PATH]; path[0] = 0;
        GetModuleFileNameA(m, path, sizeof(path));
        const char* b = strrchr(path, '\\');
        snprintf(out, n, "%s+0x%llX", b ? b + 1 : path, (unsigned long long)(addr - (uintptr_t)m));
        return;
    }
    snprintf(out, n, "0x%llX", (unsigned long long)addr);
}
static bool readable(uintptr_t p, size_t n) {
    if (p < 0x10000) return false;
    MEMORY_BASIC_INFORMATION mbi;
    if (!VirtualQuery((void*)p, &mbi, sizeof(mbi)) || mbi.State != MEM_COMMIT) return false;
    if (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) return false;
    return p + n <= (uintptr_t)mbi.BaseAddress + mbi.RegionSize;
}

// A direct call into the game made by this loader can be fenced: if it hits a bad pointer, the handler puts the
// thread back where the fence was set up and the call reports failure.
static CONTEXT g_guardCtx;
static volatile LONG g_guardOn = 0, g_guardHit = 0;
__attribute__((noinline)) static bool guarded(void (*fn)(void*), void* arg) {
    g_guardHit = 0;
    RtlCaptureContext(&g_guardCtx);
    if (g_guardHit) { g_guardOn = 0; return false; }   // arrived here from the exception handler
    g_guardOn = 1; fn(arg); g_guardOn = 0;
    return true;
}

// Writes where a crash happened into our log, then lets the game's own crash handling carry on.
static LONG CALLBACK on_exception(EXCEPTION_POINTERS* ep) {
    DWORD code = ep->ExceptionRecord->ExceptionCode;
    bool interesting = code == 0xC0000005 || code == 0xC000001D || code == 0xC0000094 || code == 0xC0000096 ||
                       code == 0x80000003 || code == 0xC06D007E || code == 0xC06D007F;
    if (!interesting) return EXCEPTION_CONTINUE_SEARCH;
    if (InterlockedCompareExchange(&g_inHandler, 1, 0) != 0) return EXCEPTION_CONTINUE_SEARCH;

    uintptr_t faultAt = (uintptr_t)ep->ExceptionRecord->ExceptionAddress;
    bool av = code == 0xC0000005 && ep->ExceptionRecord->NumberParameters >= 2;
    uintptr_t badAddr = av ? (uintptr_t)ep->ExceptionRecord->ExceptionInformation[1] : 0;

    uintptr_t frames[64]; int nframes = 0;
    CONTEXT c = *ep->ContextRecord;
    for (int i = 0; i < 64; i++) {
        DWORD64 imageBase = 0;
        PRUNTIME_FUNCTION rf = RtlLookupFunctionEntry(c.Rip, &imageBase, 0);
        if (rf) {
            void* handlerData = 0; DWORD64 establisher = 0;
            RtlVirtualUnwind(0, imageBase, c.Rip, rf, &c, &handlerData, &establisher, 0);
        } else {
            if (!readable((uintptr_t)c.Rsp, 8)) break;
            c.Rip = *(DWORD64*)c.Rsp; c.Rsp += 8;
        }
        if (!c.Rip) break;
        frames[nframes++] = (uintptr_t)c.Rip;
    }

    char w[320];
    bool fenced = g_guardOn && av && GetCurrentThreadId() == g_gameThread;
    if (g_crashNotes < 4 || fenced) {
        g_crashNotes++;
        where(faultAt, w, sizeof(w));
        if (av)
            logf_("EXCEPTION 0x%08lX at %s (%s address 0x%llX) thread %lu%s", code, w,
                  ep->ExceptionRecord->ExceptionInformation[0] == 1 ? "writing" : ep->ExceptionRecord->ExceptionInformation[0] == 8 ? "executing" : "reading",
                  (unsigned long long)badAddr, GetCurrentThreadId(), GetCurrentThreadId() == g_gameThread ? " (game thread)" : "");
        else
            logf_("EXCEPTION 0x%08lX at %s thread %lu", code, w, GetCurrentThreadId());
        for (int i = 0; i < nframes && i < 40; i++) { where(frames[i], w, sizeof(w)); logf_("   called from %s", w); }
    }
    if (fenced) {
        logf_("   ... inside a fenced call made by this loader: the call is abandoned and the server carries on");
        g_guardOn = 0; g_guardHit = 1;
        *ep->ContextRecord = g_guardCtx;
        InterlockedExchange(&g_inHandler, 0);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    InterlockedExchange(&g_inHandler, 0);
    return EXCEPTION_CONTINUE_SEARCH;
}

static bool patch(uintptr_t rva, const uint8_t* expect, const uint8_t* repl, size_t n, const char* what) {
    uint8_t* p = (uint8_t*)(g_base + rva);
    if (memcmp(p, repl, n) == 0) { logf_("patch %-34s already applied", what); return true; }
    if (memcmp(p, expect, n) != 0) { logf_("patch %-34s SKIPPED: bytes at +0x%llX do not match this build", what, (unsigned long long)rva); return false; }
    DWORD old = 0;
    if (!VirtualProtect(p, n, PAGE_EXECUTE_READWRITE, &old)) { logf_("patch %-34s FAILED: VirtualProtect error %lu", what, GetLastError()); return false; }
    memcpy(p, repl, n);
    VirtualProtect(p, n, old, &old);
    FlushInstructionCache(GetCurrentProcess(), p, n);
    logf_("patch %-34s ok", what);
    return true;
}

static bool hook(uintptr_t rva, const uint8_t* expect, size_t n, void* detour, void** orig, const char* what) {
    if (expect && memcmp((void*)(g_base + rva), expect, n) != 0) { logf_("hook  %-34s SKIPPED: bytes at +0x%llX do not match", what, (unsigned long long)rva); return false; }
    MH_STATUS s = MH_CreateHook((void*)(g_base + rva), detour, orig);
    if (s == MH_OK) s = MH_EnableHook((void*)(g_base + rva));
    logf_("hook  %-34s %s", what, s == MH_OK ? "ok" : "FAILED");
    return s == MH_OK;
}

// ---------------------------------------------------------------------------- net mode
// Every question "what kind of game is this" answers "dedicated server" (1). The actor-level version answers
// "standalone" when the actor cannot find its net driver, and a player's controller that hears that once marks
// itself as the LOCAL player's for good, after which the server runs the player's client-side logic itself
// (2.1.1: a 120-second "did I finish loading" timer that dropped the player, conversations that never opened).
static int (*orig_GetNetMode)(void*) = 0;
static int hook_GetNetMode(void*) { return 1; }
static int (*orig_ActorGetNetMode)(void*) = 0;
static int hook_ActorGetNetMode(void*) { return 1; }

// ---------------------------------------------------------------------------- Undaunted 1.6.2 fixes
static void* g_driver = 0;
static void* (*orig_ActorGetNetDriver)(void*) = 0;
static void* hook_ActorGetNetDriver(void* actor) {          // an actor that cannot find its driver gets ours
    void* d = orig_ActorGetNetDriver(actor);
    return d ? d : g_driver;
}
static void (*orig_SetReplicationDriver)(void*, void*) = 0;
static void hook_SetReplicationDriver(void* driver, void*) { orig_SetReplicationDriver(driver, 0); }   // this loader replicates itself
static bool (*orig_IsLevelInitForActor)(void*, void*, void*) = 0;
static bool hook_IsLevelInitForActor(void*, void*, void*) { return true; }
static int hook_IsNetReady(void*, bool) { return 1; }       // never throttle: everything is on this PC
static void* orig_IsNetReady = 0;

static long g_forceReady = 0;
static bool (*orig_HasFinishedLoading)(void*) = 0;
static bool hook_HasFinishedLoading(void* self) {
    bool r = orig_HasFinishedLoading(self);
    if (!r && ++g_forceReady <= 5) logf_("player controller still loading on the server side: answered 'finished' (%ld)", g_forceReady);
    return true;
}
static void* orig_SetupPlayerInput = 0;
static long g_inputSkips = 0;
static void hook_SetupPlayerInput(void*, void*) {          // input bindings exist only on the player's own PC
    if (++g_inputSkips <= 3) logf_("skipped SetupPlayerInputComponent on the server");
}

// Bounty season dates. With no live season the server cannot place the bounty and challenge windows and sends the
// player back to the main menu ("ServerInitializeBounties() - failed to get season dates"). The game's own answer is
// kept whenever it has one. Base component: wide window, as in the 1.6.2 port. Weekly component: a short window around
// today, because an endless season made the weekly-challenge draft loop forever on 2.1.1.
static int64_t ue_now_ticks() {
    FILETIME ft; GetSystemTimeAsFileTime(&ft);
    uint64_t t = ((uint64_t)ft.dwHighDateTime << 32) | ft.dwLowDateTime;   // 100 ns since 1601-01-01
    return (int64_t)(t + 504911232000000000ull);                          // 100 ns since 0001-01-01 (FDateTime ticks)
}
static bool (*orig_BountySeasonDates)(void*, void*, int64_t*, int64_t*) = 0;
static bool hook_BountySeasonDates(void* c, void* now, int64_t* s, int64_t* e) {
    if (orig_BountySeasonDates(c, now, s, e)) return true;
    *s = 637450560000000000LL;   // 2021-01-01
    *e = 657647424000000000LL;   // 2085-01-01
    static long n = 0; if (++n <= 3) logf_("bounty season dates: no current season, using 2021-2085");
    return true;
}
static bool (*orig_WeeklySeasonDates)(void*, void*, int64_t*, int64_t*) = 0;
static bool hook_WeeklySeasonDates(void* c, void* now, int64_t* s, int64_t* e) {
    if (orig_WeeklySeasonDates(c, now, s, e)) return true;
    const int64_t day = 864000000000LL;
    int64_t t = ue_now_ticks();
    *s = t - 7 * day; *e = t + 12 * 7 * day;
    static long n = 0; if (++n <= 3) logf_("weekly bounty season dates: no current season, using last week to 12 weeks ahead");
    return true;
}

// The game window is switched over to show the game's view once the first map is up. A server copy has no view
// (no viewport client), and the switch then writes through a null pointer (crash of Oct 11, 21:49).
static void* orig_SwitchGameWindow = 0;
static void hook_SwitchGameWindow(void*) { static long n = 0; if (++n <= 2) logf_("skipped switching the game window to the game view (no view on a server)"); }

// Message boxes would wait for someone to click them (the font warnings at start-up did). On the server each one is
// written to this log and answered the way the engine answers in unattended mode.
static int (*orig_MessageDialogOpen)(int, void*, void*) = 0;
static int hook_MessageDialogOpen(int type, void*, void*) {
    static const int answer[7] = { 5 /*Ok*/, 0 /*No*/, 4 /*Cancel*/, 4, 4, 0 /*No*/, 1 /*Yes*/ };
    int a = (type >= 0 && type <= 6) ? answer[type] : 1;
    char w[96]; where((uintptr_t)__builtin_return_address(0), w, sizeof(w));
    static long n = 0; if (++n <= 20) logf_("message box (type %d) suppressed, answered %d; asked from %s", type, a, w);
    return a;
}

// ---------------------------------------------------------------------------- replication
// The same job Undaunted's Networking.cpp does for 1.4.4 / 1.6.2: every tick, for every connected player, make sure
// each networked actor has a channel and let the engine send what changed.
static void** g_consider = 0; static int g_considerCap = 0;
static uint64_t g_actorChannelName = 0;
static long g_repOpened = 0, g_repSentTick = 0, g_repFailed = 0, g_repTicks = 0;
static double g_repMsTotal = 0;
static bool g_replicate = true;

// UNetConnection::FindActorChannelRef is inlined everywhere in this build: the same lookup, written out.
static void* find_actor_channel(void* conn, uint64_t weak) {
    uintptr_t m = (uintptr_t)conn + A::Conn_ActorChannels;
    if (at<int32_t>(m + 0x08) == at<int32_t>(m + 0x34)) return 0;          // no elements (all slots free)
    int32_t hashSize = at<int32_t>(m + 0x48);
    if (hashSize <= 0) return 0;
    int32_t* buckets = at<int32_t*>(m + 0x40) ? at<int32_t*>(m + 0x40) : (int32_t*)(m + 0x38);
    int64_t h = ((int64_t)(int32_t)(weak & 0xFFFFFFFF) ^ (int64_t)(int32_t)(weak >> 32)) & (hashSize - 1);
    uint8_t* data = at<uint8_t*>(m);
    int32_t idx = buckets[h];
    for (int guard = 0; idx != -1 && guard < 100000; guard++) {
        uint8_t* el = data + (int64_t)idx * 0x18;
        if (*(uint64_t*)el == weak) return *(void**)(el + 8);
        idx = *(int32_t*)(el + 0x10);
    }
    return 0;
}

static void replicate_one(void* conn, void* actor) {
    uint64_t weak = 0;
    ((void (*)(void*, void*))(g_base + A::WeakPtrAssign))(&weak, actor);
    void* ch = find_actor_channel(conn, weak);
    if (!ch) {
        uint64_t name = g_actorChannelName;
        ch = ((void* (*)(void*, uint64_t*, uint32_t, int32_t))(g_base + A::CreateChannelByName))(conn, &name, 2 /*opened locally*/, -1);
        if (!ch) { g_repFailed++; return; }
        ((void (*)(void*, void*, uint32_t))(g_base + A::SetChannelActor))(ch, actor, 0);
        g_repOpened++;
    }
    if (at<uint32_t>((uintptr_t)ch + A::Channel_Bits) & 2) return;        // closing
    if (!at<void*>((uintptr_t)ch + A::Channel_Actor)) return;
    at<uint32_t>((uintptr_t)ch + A::ActorChannel_Bits) |= 2;              // compare every property
    int64_t bits = ((int64_t (*)(void*))(g_base + A::ReplicateActor))(ch);
    if (bits > 0) g_repSentTick++;
}

static void replicate_tick(void* world, void* driver) {
    TArrayRaw& conns = at<TArrayRaw>((uintptr_t)driver + A::Driver_ClientConnections);
    if (conns.Num <= 0 || !conns.Data) return;
    void* ready[8]; int nready = 0;
    for (int i = 0; i < conns.Num && nready < 8; i++) {
        void* c = conns.Data[i];
        if (!c) continue;
        if (at<uint32_t>((uintptr_t)c + A::Conn_State) != 3) continue;
        if (!at<void*>((uintptr_t)c + A::Conn_OwningActor)) continue;
        ready[nready++] = c;
    }
    if (!nready) return;

    LARGE_INTEGER t0, t1, freq; QueryPerformanceCounter(&t0);
    if (!g_actorChannelName) {
        ((void* (*)(void*, uint32_t))(g_base + A::FNameFromEName))(&g_actorChannelName, A::EName_Actor);
        g_actorChannelName &= 0xFFFFFFFFull;
    }
    at<uint32_t>((uintptr_t)driver + A::Driver_ReplicationFrame)++;
    uint64_t driverName = at<uint64_t>((uintptr_t)driver + A::Driver_NetDriverName);

    // 1. which actors are networked at all
    int n = 0;
    TArrayRaw& levels = at<TArrayRaw>((uintptr_t)world + A::World_Levels);
    for (int li = 0; li < levels.Num; li++) {
        void* level = levels.Data[li];
        if (!level) continue;
        if (!(at<uint8_t>((uintptr_t)level + A::Level_Bits1F4) & 0x20)) continue;      // level not visible yet
        TArrayRaw& actors = at<TArrayRaw>((uintptr_t)level + A::Level_Actors);
        for (int ai = 0; ai < actors.Num; ai++) {
            void* a = actors.Data[ai];
            if (!a) continue;
            if (at<uint32_t>((uintptr_t)a + A::Object_Flags) & 0x60000000) continue;  // being garbage collected
            if (at<uint8_t>((uintptr_t)a + A::Actor_Bits5C) & 0x08) continue;          // being destroyed
            if (at<uint8_t>((uintptr_t)a + A::Actor_RemoteRole) == 0) continue;        // not networked
            if (at<uint64_t>((uintptr_t)a + A::Actor_NetDriverName) != driverName) continue;
            if ((at<uint8_t>((uintptr_t)a + A::Actor_Bits58) & 0x02) && at<uint8_t>((uintptr_t)a + A::Actor_NetDormancy) == 4) continue; // unchanged map actor: the game already has it
            ((void (*)(void*, void*))(g_base + A::CallPreReplication))(a, driver);
            if (n >= g_considerCap) {
                int cap = g_considerCap ? g_considerCap * 2 : 4096;
                void** bigger = (void**)HeapAlloc(GetProcessHeap(), 0, sizeof(void*) * cap);
                if (!bigger) break;
                if (g_consider) { memcpy(bigger, g_consider, sizeof(void*) * n); HeapFree(GetProcessHeap(), 0, g_consider); }
                g_consider = bigger; g_considerCap = cap;
            }
            g_consider[n++] = a;
        }
    }
    g_repSentTick = 0;

    // 2. each player
    for (int ci = 0; ci < nready; ci++) {
        void* conn = ready[ci];
        void* pc = at<void*>((uintptr_t)conn + A::Conn_OwningActor);
        void* view = pc;
        void* cam = at<void*>((uintptr_t)pc + A::PC_PlayerCameraManager);
        void* pawn = at<void*>((uintptr_t)pc + A::PC_Pawn);
        if (cam && at<void*>((uintptr_t)cam + A::PCM_ViewTargetActor)) view = at<void*>((uintptr_t)cam + A::PCM_ViewTargetActor);
        else if (pawn) view = pawn;
        at<void*>((uintptr_t)conn + A::Conn_ViewTarget) = view;
        ((void (*)(void*))(g_base + A::SendClientAdjustment))(pc);
        replicate_one(conn, pc);                                             // the player's own controller first
        for (int i = 0; i < n; i++) {
            void* a = g_consider[i];
            if (a == pc) continue;
            void* cls = at<void*>((uintptr_t)a + A::Object_Class);
            if (cls && (at<uint64_t>((uintptr_t)cls + A::Class_CastFlags) & A::CastFlag_PlayerController)) continue; // other players' controllers
            replicate_one(conn, a);
        }
    }
    QueryPerformanceCounter(&t1); QueryPerformanceFrequency(&freq);
    double ms = (double)(t1.QuadPart - t0.QuadPart) * 1000.0 / (double)freq.QuadPart;
    g_repMsTotal += ms; g_repTicks++;
    if (g_repTicks == 1 || g_repTicks == 10 || g_repTicks == 100 || g_repTicks % 600 == 0) {
        logf_("replication: %d player(s), %d networked actors, %ld sent this tick, %ld channels opened so far, %ld failed, this tick %.1f ms, average %.1f ms",
              nready, n, g_repSentTick, g_repOpened, g_repFailed, ms, g_repMsTotal / (double)g_repTicks);
    }
}

// ---------------------------------------------------------------------------- stamina (Undaunted 1.6.2: TickStamina)
// The player character's stamina is advanced by its blueprint function TickStamina(Where, Whom); nothing calls it on a
// server copy, so stamina never refills and the player cannot sprint. Called here every tick for each player's
// character, with Where = Both (2), Whom = All (5), as Undaunted does.
static bool name_is(void* obj, const wchar_t* want) {
    FString s = { 0, 0, 0 };
    ((void (*)(void*, FString*))(g_base + A::AppendString))((void*)((uintptr_t)obj + A::Object_Name), &s);
    return s.Data && s.Num > 0 && wcscmp(s.Data, want) == 0;
}
static void* find_function(void* cls, const wchar_t* name) {
    for (int depth = 0; cls && depth < 32; depth++, cls = at<void*>((uintptr_t)cls + A::Struct_Super)) {
        for (void* f = at<void*>((uintptr_t)cls + A::Struct_Children); f; f = at<void*>((uintptr_t)f + A::Field_Next))
            if (name_is(f, name)) return f;
    }
    return 0;
}
static void* g_staminaClass = 0; static void* g_staminaFn = 0; static long g_staminaCalls = 0;
static bool g_stamina = true;
static void stamina_tick(void* driver) {
    TArrayRaw& conns = at<TArrayRaw>((uintptr_t)driver + A::Driver_ClientConnections);
    for (int i = 0; conns.Data && i < conns.Num && i < 8; i++) {
        void* c = conns.Data[i]; if (!c) continue;
        if (at<uint32_t>((uintptr_t)c + A::Conn_State) != 3) continue;
        void* pc = at<void*>((uintptr_t)c + A::Conn_OwningActor); if (!pc) continue;
        void* pawn = at<void*>((uintptr_t)pc + A::PC_Pawn); if (!pawn) continue;
        if (at<uint32_t>((uintptr_t)pawn + A::Object_Flags) & 0x60000000) continue;
        void* cls = at<void*>((uintptr_t)pawn + A::Object_Class);
        if (cls != g_staminaClass) {
            g_staminaClass = cls; g_staminaFn = find_function(cls, L"TickStamina");
            char a[128]; logf_("stamina: character class %s %s", name_of(cls, a, sizeof(a)), g_staminaFn ? "has TickStamina; the server ticks it" : "has NO TickStamina");
        }
        if (!g_staminaFn) continue;
        uint8_t parms[2] = { 2 /*Both*/, 5 /*All*/ };
        ((void (*)(void*, void*, void*))(g_base + A::ProcessEvent))(pawn, g_staminaFn, parms);
        g_staminaCalls++;
    }
}

// ---------------------------------------------------------------------------- listening
struct FURL { FString Protocol; FString Host; int32_t Port; int32_t Valid; FString Map; FString RedirectUrl; void* OpData; int32_t OpNum; int32_t OpMax; FString Portal; };

static int g_state = 0;            // 0 waiting for a world, 1 world seen, 2 listening, 3 failed
static ULONGLONG g_worldSeenAt = 0;
static void* g_worldSeen = 0;
static int32_t g_lastConns = 0;

static void* context_of(void* engine, void* world) {
    TArrayRaw& list = at<TArrayRaw>((uintptr_t)engine + A::Engine_WorldList);
    for (int i = 0; list.Data && i < list.Num && i < 32; i++) {
        void* ctx = list.Data[i];
        if (ctx && at<void*>((uintptr_t)ctx + A::Context_World) == world) return ctx;
    }
    return 0;
}

static void do_listen(void* world) {
    void* engine = at<void*>(g_base + A::GEngine);
    logf_("listen: engine %p world %p", engine, world);
    if (!engine) { logf_("listen: no engine object"); g_state = 3; return; }

    uint64_t name = 0;
    ((void* (*)(void*, uint32_t))(g_base + A::FNameFromEName))(&name, A::EName_GameNetDriver);
    name &= 0xFFFFFFFFull;   // comparison index, number 0
    uint8_t created = ((uint8_t (*)(void*, void*, uint64_t, uint64_t))(g_base + A::CreateNamedNetDriver))(engine, world, name, name);
    logf_("listen: net driver create = %d", (int)created);

    void* ctx = context_of(engine, world);
    void* driver = 0;
    if (ctx) {
        void** arr = at<void**>((uintptr_t)ctx + A::Context_ActiveNetDrivers);
        int32_t n = at<int32_t>((uintptr_t)ctx + A::Context_ActiveNetDrivers + 8);
        logf_("listen: world context %p has %d active net driver(s)", ctx, n);
        for (int i = 0; i < n && i < 16; i++) {
            void* d = arr[i * 2];
            if (!d) continue;
            uintptr_t vt = at<uintptr_t>((uintptr_t)d) - g_base;
            char cn[128];
            logf_("listen:   driver %p class %s vtable +0x%llX%s name-id 0x%X", d, name_of(at<void*>((uintptr_t)d + A::Object_Class), cn, sizeof(cn)),
                  (unsigned long long)vt, vt == A::IpNetDriverVTable ? " (IpNetDriver)" : "", at<uint32_t>((uintptr_t)d + A::Driver_NetDriverName));
            if (at<uint32_t>((uintptr_t)d + A::Driver_NetDriverName) == (uint32_t)name) driver = d;
        }
    } else logf_("listen: no world context found for this world");
    if (!driver) { logf_("listen: no game net driver was created; stopping here"); g_state = 3; return; }

    ((void (*)(void*, void*))(g_base + A::NetDriverSetWorld))(driver, world);

    FURL url; memset(&url, 0, sizeof(url));
    url.Port = g_port; url.Valid = 1;
    FString err = { 0, 0, 0 };
    void** vt = at<void**>((uintptr_t)driver);
    bool ok = ((bool (*)(void*, void*, FURL*, bool, FString*))vt[A::VT_InitListen / 8])(driver, (void*)((uintptr_t)world + A::World_NetworkNotify), &url, false, &err);
    logf_("listen: InitListen on port %d = %d", g_port, (int)ok);
    if (err.Data && err.Num > 0) { char m[512]; WideCharToMultiByte(CP_UTF8, 0, err.Data, -1, m, sizeof(m), 0, 0); logf_("listen: engine says: %s", m); }
    if (!ok) { g_state = 3; return; }

    ((void (*)(void*, void*))(g_base + A::NetDriverSetWorld))(driver, world);
    at<void*>((uintptr_t)world + A::World_NetDriver) = driver;
    g_driver = driver;
    g_state = 2;
    logf_("replication driver object on the net driver: %p (expected: none)", at<void*>((uintptr_t)driver + A::Driver_ReplicationDriver));
    logf_("LISTENING on UDP port %d", g_port);
}

// ---------------------------------------------------------------------------- hidden players (2.1.1 lesson)
// If the server marks a connected player's character hidden (the game does that on the player's own screen while
// talking to a townsperson), the mark is sent to the player and nothing takes it back. Such requests are logged
// and not carried out; a character that ends up hidden anyway is shown again after a few seconds.
static void (*orig_SetHidden)(void*, bool) = 0;
static bool g_hideHooked = false;
static long g_hideNotes = 0, g_localFlagNotes = 0;
static bool is_player_pawn(void* actor) {
    if (!g_driver || !actor) return false;
    TArrayRaw& conns = at<TArrayRaw>((uintptr_t)g_driver + A::Driver_ClientConnections);
    for (int i = 0; conns.Data && i < conns.Num && i < 64; i++) {
        void* c = conns.Data[i]; if (!c) continue;
        void* pc = at<void*>((uintptr_t)c + A::Conn_OwningActor); if (!pc) continue;
        if (at<void*>((uintptr_t)pc + A::PC_Pawn) == actor) return true;
    }
    return false;
}
static void hook_SetHidden(void* actor, bool hide) {
    if (hide && GetCurrentThreadId() == g_gameThread && is_player_pawn(actor)) {
        char nm[128];
        if (++g_hideNotes <= 20) logf_("hide: the server was asked to HIDE the player's character '%s' - not done", name_of(actor, nm, sizeof(nm)));
        return;
    }
    orig_SetHidden(actor, hide);
}
struct HideSlot { void* pawn; bool hidden; ULONGLONG since; };
static HideSlot g_hideSlots[8];
static void player_watch(void* driver) {
    TArrayRaw& conns = at<TArrayRaw>((uintptr_t)driver + A::Driver_ClientConnections);
    ULONGLONG now = GetTickCount64();
    for (int i = 0; conns.Data && i < conns.Num && i < 8; i++) {
        void* c = conns.Data[i]; if (!c) continue;
        void* pc = at<void*>((uintptr_t)c + A::Conn_OwningActor); if (!pc) continue;
        if (at<uint8_t>((uintptr_t)pc + A::PC_IsLocalFlag)) {
            char nm[128];
            if (++g_localFlagNotes <= 10) logf_("net mode: controller '%s' had marked itself as a LOCAL player's controller; mark removed", name_of(pc, nm, sizeof(nm)));
            at<uint8_t>((uintptr_t)pc + A::PC_IsLocalFlag) = 0;
        }
        void* pawn = at<void*>((uintptr_t)pc + A::PC_Pawn);
        HideSlot& s = g_hideSlots[i];
        if (!pawn) { s.pawn = 0; continue; }
        if (at<uint32_t>((uintptr_t)pawn + A::Object_Flags) & 0x60000000) continue;
        if (!g_hideHooked) {
            g_hideHooked = true;
            uintptr_t fn = (uintptr_t)at<void**>((uintptr_t)pawn)[A::VT_SetActorHiddenInGame / 8];
            if (fn > g_base && fn < g_base + 0x5000000) {
                MH_STATUS st = MH_CreateHook((void*)fn, (void*)hook_SetHidden, (void**)&orig_SetHidden);
                if (st == MH_OK) st = MH_EnableHook((void*)fn);
                logf_("hide: watching requests to hide a player's character (function at exe+0x%llX, hook %d)", (unsigned long long)(fn - g_base), (int)st);
                if (st != MH_OK) orig_SetHidden = 0;
            }
        }
        bool hidden = (at<uint8_t>((uintptr_t)pawn + A::Actor_Bits58) & 0x20) != 0;
        char nm[128];
        if (pawn != s.pawn) { s.pawn = pawn; s.hidden = hidden; s.since = now; logf_("player's character '%s' is %s on the server", name_of(pawn, nm, sizeof(nm)), hidden ? "HIDDEN" : "visible"); continue; }
        if (hidden != s.hidden) { s.hidden = hidden; s.since = now; logf_("player's character '%s' became %s on the server", name_of(pawn, nm, sizeof(nm)), hidden ? "HIDDEN" : "visible"); }
        if (hidden && orig_SetHidden && now - s.since > 4000) { logf_("hide: still hidden after 4 seconds; showing the character again"); orig_SetHidden(pawn, false); s.since = now; }
    }
}

// ---------------------------------------------------------------------------- progression configuration (2.1.1 lesson)
// A player's progression data waits for the game-wide progression configuration, which the game asks the backend
// for from its menus; a server has no menus, so it is asked for here (twice: at listen and 20 seconds later).
static bool g_progOk = true;
static int g_progAsks = 0;
static ULONGLONG g_progAskAt = 0;
static void prog_ask(void* gi) {
    uint64_t noDelegate[2] = { 0, 0 };   // "tell nobody in particular": the game instance announces the result itself
    ((void (*)(void*, void*))(g_base + A::QueryHuntPassSeason))(gi, noDelegate);
}
static void progression_tick(void* world) {
    if (!g_progOk || g_progAsks >= 2) return;
    ULONGLONG now = GetTickCount64();
    if (g_progAsks == 1 && now - g_progAskAt < 20000) return;
    void* gi = at<void*>((uintptr_t)world + A::World_GameInstance);
    if (!gi) return;
    char a[128], b[128];
    g_progAsks++; g_progAskAt = now;
    logf_("progression: asking the backend for the progression configuration (request %d, game instance '%s' of class %s)", g_progAsks,
          name_of(gi, a, sizeof(a)), name_of(at<void*>((uintptr_t)gi + A::Object_Class), b, sizeof(b)));
    if (!guarded(prog_ask, gi)) { logf_("progression: the request could not be made; leaving progression alone"); g_progOk = false; }
}

// ---------------------------------------------------------------------------- the engine tick
static long g_ticks = 0;
static void (*orig_Tick)(void*, float, bool) = 0;
static void hook_Tick(void* engine, float dt, bool idle) {
    orig_Tick(engine, dt, idle);
    g_ticks++;
    void* world = at<void*>(g_base + A::GWorld);
    if (g_ticks == 1) logf_("first engine tick; world %p", world);
    if (!world) return;
    if (world != g_worldSeen) {
        g_worldSeen = world; g_worldSeenAt = GetTickCount64();
        char a[256], b[256], c[256];
        void* gm = at<void*>((uintptr_t)world + A::World_AuthorityGameMode);
        logf_("world is live: %p (tick %ld)  world '%s' in package '%s'", world, g_ticks, name_of(world, a, sizeof(a)), name_of(at<void*>((uintptr_t)world + A::Object_Outer), b, sizeof(b)));
        logf_("   game mode: %s   flags: client %d server %d", gm ? name_of(at<void*>((uintptr_t)gm + A::Object_Class), c, sizeof(c)) : "(none)", (int)at<uint8_t>(g_base + A::GIsClient), (int)at<uint8_t>(g_base + A::GIsServer));
        if (g_state == 2 || g_state == 3) { logf_("the world was replaced (the engine dropped the old net driver); listening again in 3 seconds"); g_driver = 0; g_lastConns = 0; g_repTicks = 0; g_repMsTotal = 0; }
        g_state = 1;
    }
    if (g_state == 1 && GetTickCount64() - g_worldSeenAt > 3000) do_listen(world);
    if (g_state == 2 && g_driver) {
        bool registered = false;
        void* ctx = context_of(at<void*>(g_base + A::GEngine), world);
        if (ctx) {
            void** arr = at<void**>((uintptr_t)ctx + A::Context_ActiveNetDrivers);
            int32_t n = at<int32_t>((uintptr_t)ctx + A::Context_ActiveNetDrivers + 8);
            for (int i = 0; arr && i < n && i < 16; i++) if (arr[i * 2] == g_driver) registered = true;
        }
        if (!registered) {
            logf_("the engine removed the net driver; listening again in 3 seconds");
            g_driver = 0; g_lastConns = 0; g_repTicks = 0; g_repMsTotal = 0; g_state = 1; g_worldSeenAt = GetTickCount64();
            return;
        }
        at<void*>((uintptr_t)g_driver + A::Driver_Notify) = (void*)((uintptr_t)world + A::World_NetworkNotify);
        at<void*>((uintptr_t)world + A::World_NetDriver) = g_driver;
        int32_t conns = at<int32_t>((uintptr_t)g_driver + A::Driver_ClientConnections + 8);
        if (conns != g_lastConns) { logf_("client connections: %d -> %d (tick %ld)", g_lastConns, conns, g_ticks); g_lastConns = conns; if (conns == 0) { g_repTicks = 0; g_repMsTotal = 0; } }
        player_watch(g_driver);
        if (g_replicate) replicate_tick(world, g_driver);
        if (g_stamina) stamina_tick(g_driver);
        progression_tick(world);
        if (g_ticks % 3600 == 0) logf_("alive: tick %ld, %d client connection(s)", g_ticks, conns);
    }
}

// ---------------------------------------------------------------------------- stay out of sight
// A client build always creates its game window, even with -nullrhi. On a server copy that window would appear,
// take the keyboard focus from the game the player is using and block clicks until alt-tab. Every request to show
// or bring forward a window of this process is turned into "keep hidden".
static BOOL (WINAPI* orig_ShowWindow)(HWND, int) = 0;
static BOOL WINAPI hook_ShowWindow(HWND h, int) { return orig_ShowWindow(h, SW_HIDE); }
static BOOL (WINAPI* orig_SetForegroundWindow)(HWND) = 0;
static BOOL WINAPI hook_SetForegroundWindow(HWND) { return TRUE; }
static BOOL (WINAPI* orig_SetWindowPos)(HWND, HWND, int, int, int, int, UINT) = 0;
static BOOL WINAPI hook_SetWindowPos(HWND h, HWND after, int x, int y, int cx, int cy, UINT f) {
    f &= ~SWP_SHOWWINDOW; f |= SWP_NOACTIVATE;
    if (after == HWND_TOP || after == HWND_TOPMOST) f |= SWP_NOZORDER;
    return orig_SetWindowPos(h, after, x, y, cx, cy, f);
}
static HWND (WINAPI* orig_CreateWindowExW)(DWORD, LPCWSTR, LPCWSTR, DWORD, int, int, int, int, HWND, HMENU, HINSTANCE, LPVOID) = 0;
static HWND WINAPI hook_CreateWindowExW(DWORD ex, LPCWSTR cls, LPCWSTR name, DWORD style, int x, int y, int w, int h, HWND parent, HMENU menu, HINSTANCE inst, LPVOID param) {
    if (!parent) { style &= ~WS_VISIBLE; ex |= WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW; ex &= ~WS_EX_APPWINDOW; }
    return orig_CreateWindowExW(ex, cls, name, style, x, y, w, h, parent, menu, inst, param);
}
static void hide_windows(void) {
    HMODULE u = LoadLibraryA("user32.dll");
    struct { const char* n; void* d; void** o; } hs[] = {
        { "ShowWindow", (void*)hook_ShowWindow, (void**)&orig_ShowWindow },
        { "SetForegroundWindow", (void*)hook_SetForegroundWindow, (void**)&orig_SetForegroundWindow },
        { "SetWindowPos", (void*)hook_SetWindowPos, (void**)&orig_SetWindowPos },
        { "CreateWindowExW", (void*)hook_CreateWindowExW, (void**)&orig_CreateWindowExW } };
    int ok = 0;
    for (auto& x : hs) {
        void* f = u ? (void*)GetProcAddress(u, x.n) : 0;
        if (f && MH_CreateHook(f, x.d, x.o) == MH_OK && MH_EnableHook(f) == MH_OK) ok++;
        else logf_("hide window: could not hook %s", x.n);
    }
    logf_("server window kept hidden and in the background (%d of 4 window functions)", ok);
}

// ---------------------------------------------------------------------------- server set-up
static void server_init(void) {
    // The work folder can be anywhere (any drive, spaces, non-English letters): wide-character path for the log.
    wchar_t dir[MAX_PATH] = L"."; char v[64];
    DWORD dn = GetEnvironmentVariableW(L"D1147_DIR", dir, MAX_PATH);
    if (dn == 0 || dn >= MAX_PATH) { dir[0] = L'.'; dir[1] = 0; }
    if (GetEnvironmentVariableA("D1147_PORT", v, sizeof(v))) { int p = atoi(v); if (p > 0 && p < 65536) g_port = p; }
    wchar_t path[MAX_PATH + 64];
    swprintf(path, MAX_PATH + 64, L"%ls\\logs\\server_%d.log", dir, g_port);
    g_log = _wfopen(path, L"w");
    g_base = (uintptr_t)GetModuleHandleA(0);
    g_gameThread = GetCurrentThreadId();
    if (GetEnvironmentVariableA("D1147_REPLICATE", v, sizeof(v)) && v[0] == '0') g_replicate = false;
    if (GetEnvironmentVariableA("D1147_PROGRESSION", v, sizeof(v)) && v[0] == '0') g_progOk = false;
    if (GetEnvironmentVariableA("D1147_STAMINA", v, sizeof(v)) && v[0] == '0') g_stamina = false;
    logf_("==== d1147 server loader, milestone 2c-fix2 (any work folder, dxgi forwarding retries). exe base %p, port %d ====", (void*)g_base, g_port);

    // Only this exact build: the LoadMap call to the stripped Listen stub.
    static const uint8_t listenCall[5] = { 0xE8, 0x0B, 0x79, 0x77, 0xFC };
    if (memcmp((void*)(g_base + A::LoadMapListenCall), listenCall, 5) != 0) {
        logf_("this is not the Dauntless 1.14.7 (CL 647472) exe; server mode not applied");
        return;
    }

    bool ok = true;
    { static const uint8_t r[5] = { 0xB0, 0x01, 0x90, 0x90, 0x90 };
      ok &= patch(A::LoadMapListenCall, listenCall, r, 5, "LoadMap listen -> true"); }
    { static const uint8_t e[13] = { 0x8B, 0x41, 0x78, 0xD1, 0xE8, 0x24, 0x01, 0x88, 0x05, 0xBA, 0x9B, 0x42, 0x06 };
      static const uint8_t r[13] = { 0xC6, 0x05, 0xC0, 0x9B, 0x42, 0x06, 0x00, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90 };
      ok &= patch(A::PreInitA_Client, e, r, 13, "PreInit A: GIsClient = 0"); }
    { static const uint8_t e[12] = { 0x0F, 0xB6, 0x41, 0x78, 0x24, 0x01, 0x88, 0x05, 0xAF, 0x9B, 0x42, 0x06 };
      static const uint8_t r[12] = { 0xC6, 0x05, 0xB4, 0x9B, 0x42, 0x06, 0x01, 0x90, 0x90, 0x90, 0x90, 0x90 };
      ok &= patch(A::PreInitA_Server, e, r, 12, "PreInit A: GIsServer = 1"); }
    { static const uint8_t e[1] = { 0x01 }, r[1] = { 0x00 };
      ok &= patch(A::PreInitB_ClientImm, e, r, 1, "PreInit B: GIsClient = 0"); }
    { static const uint8_t e[1] = { 0x00 }, r[1] = { 0x01 };
      ok &= patch(A::PreInitC_ServerImm, e, r, 1, "PreInit C: GIsServer = 1"); }
    { static const uint8_t e[7] = { 0x44, 0x88, 0x25, 0xD4, 0x54, 0x42, 0x06 }, r[7] = { 0xC6, 0x05, 0xD4, 0x54, 0x42, 0x06, 0x00 };
      ok &= patch(A::PreInitC_Client, e, r, 7, "PreInit C: GIsClient = 0"); }
    at<uint8_t>(g_base + A::GIsServer) = 1;
    at<uint8_t>(g_base + A::GIsClient) = 0;

    AddVectoredExceptionHandler(1, on_exception);

    MH_STATUS s = MH_Initialize();
    logf_("MinHook init: %d", (int)s);
    hide_windows();
    { static const uint8_t e[5] = { 0x40, 0x53, 0x48, 0x81, 0xEC }; ok &= hook(A::GetNetMode, e, 5, (void*)hook_GetNetMode, (void**)&orig_GetNetMode, "UWorld net mode -> dedicated"); }
    { static const uint8_t e[5] = { 0x48, 0x89, 0x5C, 0x24, 0x08 }; ok &= hook(A::ActorGetNetMode, e, 5, (void*)hook_ActorGetNetMode, (void**)&orig_ActorGetNetMode, "actor net mode -> dedicated"); }
    { static const uint8_t e[5] = { 0x48, 0x89, 0x5C, 0x24, 0x08 }; ok &= hook(A::ActorGetNetDriver, e, 5, (void*)hook_ActorGetNetDriver, (void**)&orig_ActorGetNetDriver, "actor net driver fallback"); }
    { static const uint8_t e[4] = { 0x48, 0x8B, 0xC4, 0x48 }; ok &= hook(A::GameEngineTick, e, 4, (void*)hook_Tick, (void**)&orig_Tick, "engine tick"); }
    { static const uint8_t e[4] = { 0x40, 0x56, 0x41, 0x56 }; ok &= hook(A::SetReplicationDriver, e, 4, (void*)hook_SetReplicationDriver, (void**)&orig_SetReplicationDriver, "no replication driver"); }
    { static const uint8_t e[5] = { 0x48, 0x89, 0x5C, 0x24, 0x08 }; ok &= hook(A::IsLevelInitForActor, e, 5, (void*)hook_IsLevelInitForActor, (void**)&orig_IsLevelInitForActor, "level ready for every actor"); }
    { static const uint8_t e[4] = { 0x4C, 0x8B, 0xC1, 0x84 }; ok &= hook(A::IsNetReady, e, 4, (void*)hook_IsNetReady, (void**)&orig_IsNetReady, "net-ready (no throttling)"); }
    { static const uint8_t e[5] = { 0x48, 0x89, 0x5C, 0x24, 0x08 }; ok &= hook(A::HasFinishedLoading, e, 5, (void*)hook_HasFinishedLoading, (void**)&orig_HasFinishedLoading, "player finished loading"); }
    { static const uint8_t e[5] = { 0x48, 0x89, 0x54, 0x24, 0x10 }; ok &= hook(A::SetupPlayerInput, e, 5, (void*)hook_SetupPlayerInput, (void**)&orig_SetupPlayerInput, "skip input setup"); }
    { static const uint8_t e[5] = { 0x48, 0x89, 0x5C, 0x24, 0x08 }; ok &= hook(A::BountySeasonDates, e, 5, (void*)hook_BountySeasonDates, (void**)&orig_BountySeasonDates, "bounty season dates"); }
    { static const uint8_t e[5] = { 0x48, 0x89, 0x5C, 0x24, 0x20 }; ok &= hook(A::SwitchGameWindow, e, 5, (void*)hook_SwitchGameWindow, (void**)&orig_SwitchGameWindow, "no game-window view switch"); }
    { static const uint8_t e[5] = { 0x48, 0x89, 0x5C, 0x24, 0x10 }; ok &= hook(A::MessageDialogOpen, e, 5, (void*)hook_MessageDialogOpen, (void**)&orig_MessageDialogOpen, "message boxes answered silently"); }
    { static const uint8_t e[5] = { 0x48, 0x89, 0x5C, 0x24, 0x18 }; ok &= hook(A::WeeklySeasonDates, e, 5, (void*)hook_WeeklySeasonDates, (void**)&orig_WeeklySeasonDates, "weekly bounty season dates"); }

    // the functions the replication loop calls must look as expected, or it stays off
    { struct { uintptr_t a; uint8_t b[4]; const char* n; } chk[] = {
          { A::CallPreReplication, { 0x48, 0x85, 0xD2, 0x0F }, "CallPreReplication" }, { A::SendClientAdjustment, { 0x48, 0x89, 0x5C, 0x24 }, "SendClientAdjustment" },
          { A::CreateChannelByName, { 0x40, 0x53, 0x55, 0x56 }, "CreateChannelByName" }, { A::SetChannelActor, { 0x48, 0x89, 0x5C, 0x24 }, "SetChannelActor" },
          { A::ReplicateActor, { 0x4C, 0x8B, 0xDC, 0x55 }, "ReplicateActor" }, { A::WeakPtrAssign, { 0x40, 0x53, 0x48, 0x83 }, "WeakPtrAssign" } };
      for (auto& c : chk) if (memcmp((void*)(g_base + c.a), c.b, 4) != 0) { logf_("replication OFF: %s is not where expected", c.n); g_replicate = false; } }
    logf_("replication loop: %s", g_replicate ? "on" : "OFF");
    { static const uint8_t e[5] = { 0x48, 0x89, 0x5C, 0x24, 0x08 };
      if (memcmp((void*)(g_base + A::QueryHuntPassSeason), e, 5) != 0) { logf_("progression request OFF: function not where expected"); g_progOk = false; } }
    logf_("progression configuration request: %s", g_progOk ? "on" : "OFF");
    logf_(ok ? "server mode applied; waiting for the engine to start" : "server mode only PARTLY applied; see lines above");
    logf_("command line: %s", GetCommandLineA());
}

extern "C" BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(inst);
        char v[8];
        if (GetEnvironmentVariableA("D1147_SERVER", v, sizeof(v)) && v[0] == '1') server_init();
    }
    return TRUE;
}
