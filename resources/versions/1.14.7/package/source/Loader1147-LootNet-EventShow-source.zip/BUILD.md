# Loader 1.14.7 - Modded mode build (Oct 19, 2026)

Source of `bin/dxgi.dll` in the Dauntless Forever 1.14.7 server files. AGPL-3.0-only (LICENSE-AGPL-3.0.txt).
MinHook by Tsuda Kageyu (BSD-2-Clause, minhook/LICENSE.txt).

Nov 2 (effects clear at once, DF-VFXREMOVE-1147): the engine refused any remote call from an actor already marked for
destruction, and the game ends effects by calling "remove" and destroying the actor in the same frame, so the Chain Blades
blast, enrage flames and cell effects stayed on players' screens until the channel closed seconds later (report 544: 45
such refusals in two hunts). The je after the bActorIsBeingDestroyed test in UNetDriver::ProcessRemoteFunction
(exe+0x3FA02BB) is made unconditional. Server copies only. D1147_VFXREMOVE=0 turns it off.
Nov 1 (frame timer, DF-TIMERRES-1147): a hunt server asks Windows for a 1 ms timer at start. Windows 10 granted it
system-wide as soon as any program asked, Windows 11 makes it per-process, so server copies slept on the 15.6 ms default
and ticked about 46 a second instead of 60 (46.7 before, 58.9 after on the same PC). Everyone in the hunt felt that as
rubberband. D1147_TIMERRES=0 turns it off. Log line: "frame timer: ...".
Oct 26 (no more patch scripts): the loader makes two fixed byte changes itself, which tools\ammo-fix-1147.ps1 and
tools\party-stay-1147.ps1 used to write into the running game (antivirus programs blocked those scripts). Server copies and
the player's game: ServerAdjustAmmo's broken warning is skipped (exe+0x220C8EF, DF-AMMO-LOG-1147). Player's game: the party
is not left and members are not kicked for looking offline (exe+0x1C7B447, exe+0x1C7B47E, DF-PARTY-STAY-1147;
D1147_PARTY_STAY=0 turns it off). Each change only when the original bytes are there; lines in d1147_dxgi.log / server log.
Oct 24 (null RHI): server copies always take the null RHI (some made a D3D11 device despite -nullrhi and died with
"Failed to choose a D3D11 Adapter" or DXGI_ERROR_DEVICE_REMOVED).
Oct 24 (SigGuard 3): the significance guard also checks that the object is still in the engine's object list and not being
destroyed, vtables must be in .rdata and the called slot in .text, and the per-object work runs fenced: a crash inside it
returns to the guard (decided by the thread's fence depth and stack, not the crash address) and that entry is skipped for 10 s,
then tried again (crashes 10-30 min into hunts and during island events).
Oct 21 (boss bar safe): the boss bar only reads a part actor through MonsterPartComponents; reading every component at 0x520 could run past a smaller one and crash the game (dxgi+0x8F12).
Oct 20 (chat): the game's XMPP domain is fixed when ChatEndpoint is a ws:// address, and an empty GetGeneralChatChannel becomes the host room GeneralDF (D1147_CHATROOM=0 turns that off).
Oct 20 (dxgi_chain): a dxgi_chain.dll next to the game exe is used as the real DXGI before System32 (DXVK for Intel Arc, issue #4).
Oct 19 (badge): D1147_CLIENT_BADGE=<text> shows small white text bottom-right of the game window (TR for Trials Quick Retry), its own layered window.
Oct 19 (SigGuard 2): the significance guard also checks the vtable slot and the class pointer, and guards the second site (PostSignificance thunk exe+0x1D815E0) with an assembly hook that keeps every argument register.

Base: Loader1147-SigGuard-source (released loader BAA60615: fix5 + KombatKing's equipment fix R1 + owner-only
replication; client: significance guard and startup messages). Its rebuild has an identical .text section.

Added (client: player's game only):
- Boss Health Bar (from loader 2c-fix5 + 4c by Addison2k): with D1147_CLIENT_BOSSBAR=1 a click-through overlay shows
  the nearest behemoth's health and its parts' health (windowed or borderless window mode). Log: <D1147_DIR>\logs\client.log
- Boss bar position: Ctrl+Alt+arrow keys move it while it shows, Ctrl+Alt+Home resets; saved in <D1147_DIR>\data\bossbar_pos.txt.
- UE4SS: with -dfmods on the game's command line it loads <exe folder>\ue4ss\UE4SS.dll (no dwmapi.dll proxy).
Added (server copies): with D1147_SERVER_MODS=1 they load UE4SS the same way.
All of it is off unless the start scripts ask for it (launcher Mods page, data\mods.txt).

Build (Zig 0.17.0):

    zig c++ -target x86_64-windows-gnu -shared -O2 -fno-math-errno -o dxgi.dll d1147.cpp minhook/hook.c minhook/buffer.c minhook/trampoline.c minhook/hde/hde64.c -luser32 -lkernel32 -lgdi32

## Nov 3: effects that froze or stayed on screen (report 544)
DF-AOEFX-1147: in the player's game, a particle or Niagara part of an AoE actor that gets a late "not active" right after it started (OnRep_IsActive) now keeps playing, so effects such as Reaper's Dance and behemoth ground stomps animate and end as they should instead of freezing on their first frame. D1147_AOEFX=0 turns it off. Also in this build: a life-span backstop for the Reaper's Dance actor (DF-LINGERFIX, D1147_LINGERFIX=0 off), message box text in the log (DF-BOXLOG), the 1 ms frame timer for hunt servers (DF-TIMERRES, D1147_TIMERRES=0 off) and the hidden-actor rule (DF-HIDDENREL, D1147_HIDDEN=0 off). Measuring code is off unless asked: D1147_CUEWATCH=log, D1147_LINGERVFX=log, D1147_DOMEPROBE=1, D1147_DESTROYWATCH=1.
-fno-math-errno keeps one square root inline so the import list stays the same.

## Nov 9: DF-REPCAP-1147 (every player gets replicated; half the cost per tick)
The replication pass kept its ready connections in a fixed array of 8, so in a town the 9th player onward never received
an actor and sat on the loading screen until someone ahead of them left (EU town, Nov 9: every replication line said
8 players while 12 to 15 were connected). The array now holds 64 (town cap 48). To keep the per-tick cost where it was,
each player's actors are sent every 2nd tick, interleaved (half the players on even ticks, half on odd): 30 updates a
second each at 60 ticks, the engine's default net rate. Moves, corrections and the player's own controller still go every
tick. D1147_REPDIV=1 is the old every-tick behaviour. The replication log line now reads "N player(s) served of M
connection(s), every K tick(s) each". Start-up line: "replication serves up to 64 connections (was 8); ...".
Build 631AFC00 on 2CB0F740's source; same imports and exports.

## Nov 9: DF-TUNING-1147 (server copies fetch the event schedule)
The game fetches huntpass_xp_config, seasonal_event_schedule and island_content_config through
UTuningDataProvider::RequestTuningData (exe+0x1E0CC50), called only from the sign-in-complete handler (exe+0x190C960):
provider = UArchonGameInstance::TuningDataProvider (+0x7F0), world = GameInstance::GetWorld, third argument a zeroed
16-byte slot. A server never signs in, so the town never had the schedule and every quest with an EventId stayed
Unavailable on the server (game_server_loaded_quest_status Nov 9). Server copies now make the call at listen and 20 s
later, inside the crash fence, after a 10-byte prologue check. D1147_TUNING=0 turns it off. Log: "tuning data request
(event schedule): on" at start, "tuning: asking the backend for the tuning data ..." per request.
Build B81CA8A3 on 631AFC00's source (DF-REPCAP-1147).

## Nov 12: DF-LOOTWEDGE-1147 (the loot screen that stuck after a kill; reports 715, 699, 745)
After a kill on an island the drops popup shows for 6.5 s. Pressing its key in that time opened the full loot screen
(UMatchLootPanelWidget::DisplaySummaryScreen, exe+0x1F12900), which in this build comes up with nothing that can take
focus: no key reaches it and the game had to be closed. In the player's game the full loot screen is no longer opened
(the popup closes by itself as before); D1147_LOOTSUMMARY=1 lets it open again. Safety net: a loot screen whose tick asks
for the focus repair on every frame for 2 s (the call at exe+0x1E506A0 into exe+0x1E3A6F0) is closed with the game's own
close call, then with ScreenHideEnd if it is still there 2 s later; any other screen in that state is only written to
the log. D1147_LOOTNET=0 turns the net off. Log lines start "loot screen:" in d1147_dxgi.log. Server copies: no change.
Build C1FBA106 on 03F72460's source (DF-LOREWAIT-1147 v2); same imports and exports.

## Nov 12: DF-EVENTSHOW-1147 (rate events: the loot screens show the event amounts) - TEST build
Rate events are applied by the backend when it stores a grant, so the hunt's loot screens still showed the amounts the
hunt server rolled. In the player's game the loot list (UPlayerLootComponent::ClientHandleLootGranted) and the break-part
pop-up (NotifyOwningClientAboutConditionalLoot) are logged as they arrive through ProcessEvent, and with
D1147_EVENTSHOW=1 their amounts are multiplied by the backend's own table, data\event-display.txt ("ends=<UTC>" then
"ITEM_ID=factor" lines; read again every 30 s; rounding max(1, round(n * factor))). Not set = log only, 0 = off.
Display only. Log lines start "event show:" in d1147_dxgi.log. Server copies: no change.
Build 63A5C5F6 on C1FBA106's source (DF-LOOTWEDGE-1147); same imports and exports.

## Nov 12: release build of DF-LOOTWEDGE-1147 + DF-EVENTSHOW-1147
After the test runs on Nov 12 (the full loot screen opened and closed normally on the test PC; the amounts showed doubled):
the full loot screen opens as normal again and only the safety net guards the stuck case (D1147_LOOTSUMMARY=0 blocks the
screen, D1147_LOOTNET=0 turns the net off); the loot amounts on screen follow data\event-display.txt whenever it holds a
live table (D1147_EVENTSHOW=0 off, =log writes every amount and changes nothing). No table = nothing changes.
Same imports and exports as 03F72460.
