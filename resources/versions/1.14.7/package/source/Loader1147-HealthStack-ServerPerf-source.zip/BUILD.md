# Loader 1.14.7 - Modded mode build (Oct 19, 2026)

Source of `bin/dxgi.dll` in the Dauntless Forever 1.14.7 server files. AGPL-3.0-only (LICENSE-AGPL-3.0.txt).
MinHook by Tsuda Kageyu (BSD-2-Clause, minhook/LICENSE.txt).

Nov 2 (effects clear at once, DF-VFXREMOVE-1147): the engine refused any remote call from an actor already marked for
destruction, and the game ends effects by calling "remove" and destroying the actor in the same frame, so the Chain Blades
blast, enrage flames and cell effects stayed on players' screens until the channel closed seconds later (report 544: 45
such refusals in two hunts). The je after the bActorIsBeingDestroyed test in UNetDriver::ProcessRemoteFunction
(exe+0x3FA02BB) is made unconditional. Server copies only. D1147_VFXREMOVE=0 turns it off.
Nov 1 (frame timer, DF-TIMERRES-1147): a hunt server asks Windows for a 1 ms timer at start. Windows 10 granted it
system-wide as soon as any program asked, Windows 11 makes it per-process, so server copies slept on the 15.6 ms default
and ticked about 46 a second instead of 60 (46.7 before, 58.9 after on the same PC). Everyone in the hunt felt that as
rubberband. D1147_TIMERRES=0 turns it off. Log line: "frame timer: ...".
Oct 26 (no more patch scripts): the loader makes two fixed byte changes itself, which tools\ammo-fix-1147.ps1 and
tools\party-stay-1147.ps1 used to write into the running game (antivirus programs blocked those scripts). Server copies and
the player's game: ServerAdjustAmmo's broken warning is skipped (exe+0x220C8EF, DF-AMMO-LOG-1147). Player's game: the party
is not left and members are not kicked for looking offline (exe+0x1C7B447, exe+0x1C7B47E, DF-PARTY-STAY-1147;
D1147_PARTY_STAY=0 turns it off). Each change only when the original bytes are there; lines in d1147_dxgi.log / server log.
Oct 24 (null RHI): server copies always take the null RHI (some made a D3D11 device despite -nullrhi and died with
"Failed to choose a D3D11 Adapter" or DXGI_ERROR_DEVICE_REMOVED).
Oct 24 (SigGuard 3): the significance guard also checks that the object is still in the engine's object list and not being
destroyed, vtables must be in .rdata and the called slot in .text, and the per-object work runs fenced: a crash inside it
returns to the guard (decided by the thread's fence depth and stack, not the crash address) and that entry is skipped for 10 s,
then tried again (crashes 10-30 min into hunts and during island events).
Oct 21 (boss bar safe): the boss bar only reads a part actor through MonsterPartComponents; reading every component at 0x520 could run past a smaller one and crash the game (dxgi+0x8F12).
Oct 20 (chat): the game's XMPP domain is fixed when ChatEndpoint is a ws:// address, and an empty GetGeneralChatChannel becomes the host room GeneralDF (D1147_CHATROOM=0 turns that off).
Oct 20 (dxgi_chain): a dxgi_chain.dll next to the game exe is used as the real DXGI before System32 (DXVK for Intel Arc, issue #4).
Oct 19 (badge): D1147_CLIENT_BADGE=<text> shows small white text bottom-right of the game window (TR for Trials Quick Retry), its own layered window.
Oct 19 (SigGuard 2): the significance guard also checks the vtable slot and the class pointer, and guards the second site (PostSignificance thunk exe+0x1D815E0) with an assembly hook that keeps every argument register.

Base: Loader1147-SigGuard-source (released loader BAA60615: fix5 + KombatKing's equipment fix R1 + owner-only
replication; client: significance guard and startup messages). Its rebuild has an identical .text section.

Added (client: player's game only):
- Boss Health Bar (from loader 2c-fix5 + 4c by Addison2k): with D1147_CLIENT_BOSSBAR=1 a click-through overlay shows
  the nearest behemoth's health and its parts' health (windowed or borderless window mode). Log: <D1147_DIR>\logs\client.log
- Boss bar position: Ctrl+Alt+arrow keys move it while it shows, Ctrl+Alt+Home resets; saved in <D1147_DIR>\data\bossbar_pos.txt.
- UE4SS: with -dfmods on the game's command line it loads <exe folder>\ue4ss\UE4SS.dll (no dwmapi.dll proxy).
Added (server copies): with D1147_SERVER_MODS=1 they load UE4SS the same way.
All of it is off unless the start scripts ask for it (launcher Mods page, data\mods.txt).

Build (Zig 0.17.0):

    zig c++ -target x86_64-windows-gnu -shared -O2 -fno-math-errno -o dxgi.dll d1147.cpp minhook/hook.c minhook/buffer.c minhook/trampoline.c minhook/hde/hde64.c -luser32 -lkernel32 -lgdi32

## Nov 3: effects that froze or stayed on screen (report 544)
DF-AOEFX-1147: in the player's game, a particle or Niagara part of an AoE actor that gets a late "not active" right after it started (OnRep_IsActive) now keeps playing, so effects such as Reaper's Dance and behemoth ground stomps animate and end as they should instead of freezing on their first frame. D1147_AOEFX=0 turns it off. Also in this build: a life-span backstop for the Reaper's Dance actor (DF-LINGERFIX, D1147_LINGERFIX=0 off), message box text in the log (DF-BOXLOG), the 1 ms frame timer for hunt servers (DF-TIMERRES, D1147_TIMERRES=0 off) and the hidden-actor rule (DF-HIDDENREL, D1147_HIDDEN=0 off). Measuring code is off unless asked: D1147_CUEWATCH=log, D1147_LINGERVFX=log, D1147_DOMEPROBE=1, D1147_DESTROYWATCH=1.
-fno-math-errno keeps one square root inline so the import list stays the same.

## Nov 9: DF-REPCAP-1147 (every player gets replicated; half the cost per tick)
The replication pass kept its ready connections in a fixed array of 8, so in a town the 9th player onward never received
an actor and sat on the loading screen until someone ahead of them left (EU town, Nov 9: every replication line said
8 players while 12 to 15 were connected). The array now holds 64 (town cap 48). To keep the per-tick cost where it was,
each player's actors are sent every 2nd tick, interleaved (half the players on even ticks, half on odd): 30 updates a
second each at 60 ticks, the engine's default net rate. Moves, corrections and the player's own controller still go every
tick. D1147_REPDIV=1 is the old every-tick behaviour. The replication log line now reads "N player(s) served of M
connection(s), every K tick(s) each". Start-up line: "replication serves up to 64 connections (was 8); ...".
Build 631AFC00 on 2CB0F740's source; same imports and exports.

## Nov 9: DF-TUNING-1147 (server copies fetch the event schedule)
The game fetches huntpass_xp_config, seasonal_event_schedule and island_content_config through
UTuningDataProvider::RequestTuningData (exe+0x1E0CC50), called only from the sign-in-complete handler (exe+0x190C960):
provider = UArchonGameInstance::TuningDataProvider (+0x7F0), world = GameInstance::GetWorld, third argument a zeroed
16-byte slot. A server never signs in, so the town never had the schedule and every quest with an EventId stayed
Unavailable on the server (game_server_loaded_quest_status Nov 9). Server copies now make the call at listen and 20 s
later, inside the crash fence, after a 10-byte prologue check. D1147_TUNING=0 turns it off. Log: "tuning data request
(event schedule): on" at start, "tuning: asking the backend for the tuning data ..." per request.
Build B81CA8A3 on 631AFC00's source (DF-REPCAP-1147).

## Nov 12: DF-LOOTWEDGE-1147 (the loot screen that stuck after a kill; reports 715, 699, 745)
After a kill on an island the drops popup shows for 6.5 s. Pressing its key in that time opened the full loot screen
(UMatchLootPanelWidget::DisplaySummaryScreen, exe+0x1F12900), which in this build comes up with nothing that can take
focus: no key reaches it and the game had to be closed. In the player's game the full loot screen is no longer opened
(the popup closes by itself as before); D1147_LOOTSUMMARY=1 lets it open again. Safety net: a loot screen whose tick asks
for the focus repair on every frame for 2 s (the call at exe+0x1E506A0 into exe+0x1E3A6F0) is closed with the game's own
close call, then with ScreenHideEnd if it is still there 2 s later; any other screen in that state is only written to
the log. D1147_LOOTNET=0 turns the net off. Log lines start "loot screen:" in d1147_dxgi.log. Server copies: no change.
Build C1FBA106 on 03F72460's source (DF-LOREWAIT-1147 v2); same imports and exports.

## Nov 12: DF-EVENTSHOW-1147 (rate events: the loot screens show the event amounts) - TEST build
Rate events are applied by the backend when it stores a grant, so the hunt's loot screens still showed the amounts the
hunt server rolled. In the player's game the loot list (UPlayerLootComponent::ClientHandleLootGranted) and the break-part
pop-up (NotifyOwningClientAboutConditionalLoot) are logged as they arrive through ProcessEvent, and with
D1147_EVENTSHOW=1 their amounts are multiplied by the backend's own table, data\event-display.txt ("ends=<UTC>" then
"ITEM_ID=factor" lines; read again every 30 s; rounding max(1, round(n * factor))). Not set = log only, 0 = off.
Display only. Log lines start "event show:" in d1147_dxgi.log. Server copies: no change.
Build 63A5C5F6 on C1FBA106's source (DF-LOOTWEDGE-1147); same imports and exports.

## Nov 12: release build of DF-LOOTWEDGE-1147 + DF-EVENTSHOW-1147
After the test runs on Nov 12 (the full loot screen opened and closed normally on the test PC; the amounts showed doubled):
the full loot screen opens as normal again and only the safety net guards the stuck case (D1147_LOOTSUMMARY=0 blocks the
screen, D1147_LOOTNET=0 turns the net off); the loot amounts on screen follow data\event-display.txt whenever it holds a
live table (D1147_EVENTSHOW=0 off, =log writes every amount and changes nothing). No table = nothing changes.
Same imports and exports as 03F72460.

## Nov 12: DF-ACTWATCH-1147 (report 760, Tempest that never runs out after a refused activation) - TEST build, log only
A player used Tempest as its charges ran out; his hunt server refused the activation and he reported that Tempest never
ran out afterwards. Nothing in the game is changed by this build. Each side writes what it holds around an activation:
the ability's class, how many copies of it are running, and every Tempest effect on the player (stack count, prediction
key, length). Server copies: every refused activation and every Omnicell one, in server_<port>.log. Player's game: the
request it sends, the server's answer, and 1 s and 5 s after a refusal, in d1147_dxgi.log. Lines start "ability watch:".
D1147_ACTWATCH=0 turns it off. Also: one log line when the full loot screen is asked for and opened (first 5).
Built on the Nov 12 release source (6843550B); same imports and exports.

## Nov 12: DF-PREDKEY-1147 (report 760: a refused activation named the wrong prediction key)
Found with the ability watch above: the key numbers in the server log were not counting up, they were the low half of a
pointer. In this build FPredictionKey holds the connection pointer first and the key number at +8; the equipment bridge
read the number from +0. Starting an ability was not affected (the key is handed on as a whole), but when the hunt
server REFUSED an activation it told the player's game that the wrong key had failed, so the game never rolled back the
activation it had started ahead of the server's answer. equipment_bridge.h now reads the number from +8. Server copies
only. The ability watch stays on in this build to confirm it: the key in "asked the server" (player's game) and in
"started"/"REFUSED" (hunt server) must be the same small number.

## Nov 12: DF-CHARR-CLIENT + DF-CRITTEXT-1147 (Oops All Charrogg in the player's game; comic crit numbers)
Player's game only; server copies run none of it.
DF-CHARR-CLIENT: on Oops All Charrogg (zzzzzzzzzzzzzzzz_OopsAllCharrogg1147_P.pak; recognised by its atmosphere actor,
class atmospheres_chrgg_00_snow_bp_C) each Firebrand Charrogg (Heroic) glows, drifting between light blue and purple
over 9 s, and the game's snow effects play the pak's red ash instead. D1147_CLIENT_CHARR=0 turns it off. Log lines
start "charrogg".
DF-CRITTEXT-1147: crit damage numbers are bigger, yellow, held up longer, with a black outline, a drop shadow, a tilt and
a pop-and-twist animation (SetCombatTextAndFont / SetCombatTextColorAndOpacity through ProcessEvent, tags 10 and 11).
D1147_CRITTEXT=0 turns it off, =all shows every number as a crit. Log lines start "crit text:".
Both run from the engine tick hook, which is now installed in every player's game (it was installed only with the
boss bar), together with the loader's crash note handler; client.log is written for everyone. Off the Charrogg hunt the
tick does one actor walk a second with class lookups in a small table. Crash rule: a new ProcessEvent tag must not
fall inside a range another feature claims (the ability watch takes 7 to 9 only).
Release cleanup on the tested C90A5771 source: the unused smoke code, two unused colour constants and the template
offset probe are removed; the class lookups use a table instead of a list.

## Nov 13: DF-SERVERPERF-1147 (idle server copies stop costing a core; the game's own replication graph)
Server copies only; the player's game is unchanged. All three switches are off unless the start scripts set them,
and with none set the loader behaves as 2F25D949.
DF-IDLE-1147, D1147_IDLEFPS=10: a listening server copy with no connection for 10 s runs at that many frames a second
(5..30) and is at full speed again on the tick a connection appears. The town copy behind a hunt and the hunt copy
left behind in town each ran at 60 frames a second for nobody. Measured Nov 13: an empty town copy 17 % of a core ->
about 1 %; a town asleep for 361 s took a returning player 1.3 s after he left the hunt server. Log lines "idle
throttle: on / off". The "alive: tick" line counts ticks, so a sleeping copy writes it about every 6 minutes.
DF-REPGRAPH-1147, D1147_REPGRAPH=1: the game ships its own replication system (UArchonReplicationGraph). Its game mode
installs it when the feature flag /Script/Archon.ReplicationGraphFeature is on for the map
(?OverridenFeaturesOn=/Script/Archon.ReplicationGraphFeature in the map options) and the start line does not say
-RepDriverDisable. With the switch set the loader changes that word to -RepDriverEnable in its own process before the
engine reads it, no longer replaces the engine's replication driver with none, and, when the graph is on the net
driver, calls its ServerReplicateActors (vtable +0x2F8, exe+0x1C034C0) once per tick inside the crash fence instead
of running its own pass. Kept per player every tick: the view target and SendClientAdjustment. Not used while the
graph sends: DF-REPCAP, the owner-only and hidden-actor filters, the destroy watch (the graph has its own routing).
No graph on a net driver, an unexpected vtable slot or a fault in the call: the loader's own pass sends; the log
says which ("repgraph: ..." lines). Measured Nov 13 in the test environment, replication per tick: town 0.37-0.45 ms
(own pass, 1 player), 0.18-0.27 ms (graph, 1 player), 0.21-0.26 ms (graph, 2 players); hunt 0.51-0.72 ms (own pass,
1 player), 0.58-0.60 ms (graph, 1 player), 0.76-0.80 ms (graph, 2 players). Seen with two players in a town and a
hunt; not with more.
Tried and NOT kept: leaving out the forced "compare every property" in the own pass (the town never finished
loading, twice), and keeping the networked-actor list between ticks (works, saves about 0.05 ms).
DF-PERFLOG-1147, D1147_PERFLOG=1: "perf: pass split" beside each "replication:" line and "perf: last 60 s" once a
minute (ticks a second, game thread and process cpu). Log only.
In every mode the first calls to SetReplicationDriver are logged.
Imports: the 143 of 2F25D949 plus GetCurrentThread, GetThreadTimes, GetProcessTimes (kernel32). Exports unchanged.
MinHook v1.3.4 (the unchanged 2F25D949 source rebuilds with every section but the build id identical).

## Nov 13: DF-CRITOPTS-1147 (crit number settings on the game's Options > Gameplay page) - TEST build
Player's game only. The comic crit numbers get settings: seven rows the loader adds under Content Notifications on
Options > Gameplay, made from the game's own row widgets (Crit Numbers, Crit Style with six looks, Crit Size, Crit Pop
and Twist, Crit Tilt, Crit Hang Time, Crit Test Mode). Saved to data\crittext.txt 0.8 s after a change and read at
start. The page is seen at its Construct event (ProcessEvent tag 12); rows are built and read from the engine tick.
Nothing is kept between visits to the page: the row classes are unloaded when Options closes, so every kept pointer is
checked against the engine's object list before use. A pooled damage number that was a crit gets the game's own
outline, shadow, tilt and scale put back before it is used again. D1147_CRITTEXT=0 forces it all off (no rows either),
=all starts in test mode. Log lines start "crit options:" and "crit text:".
Crit Numbers is OFF by default: a player with no data\crittext.txt sees the game's own numbers until they turn the row
on (2026-11-12.3 had the comic look on for everyone).
Merged onto the 2026-11-12.3 release source (2F25D949) from the tested EF6F3508 source; same imports and exports.

## Nov 13: DF-DOWNWATCH-1147 (report 800: knocked out, but still up and fighting at 0 health) - TEST build
Server copies only; the player's game runs the same code as 837BE656. Three parts, all on the character's
UArchonBleedoutComponent:
1. Watch: per connected player the health, bleed-out state, whether the no-health effect is on and the movement mode,
   written once a second while it matters (health at or under 30 %, downed, or 10 s after a change), and one
   "ALIVE AT 0 HP" line when a player has had 0 health for 2 s without being downed (6 s during the finishing hit),
   with the bleed-out replacement effects registered on the character. A character is judged only after it has been
   seen with health above 0.
2. Preload: the no-health effect class is loaded when a player's character is first seen (the engine's own
   FSoftObjectPtr::LoadSynchronous, exe+0xEFAA10, after a 25-byte check) and kept loaded, so the game no longer loads it
   in the middle of a knock-out.
3. Safety net: at the ALIVE AT 0 HP line the game's own knock-out runs again (ServerTryStartBleedout); if the player is
   still up 1.5 s later the bleed-out is put on directly (bleed-out time from the game mode,
   ApplyNoHealthGameplayEffectToSelf when the effect is off, AuthSetBleedoutState(Bleedout)).
D1147_DOWNWATCH=0 turns all of it off, D1147_DOWNNET=0 the safety net only, D1147_DOWNPRELOAD=0 the preload only.
Log lines start "down watch:" in server_<port>.log. Why the knock-out fails is NOT known yet; the watch is there to
show it. Built on the 2026-11-13 release source (837BE656); same imports and exports.

## Nov 17-18: crit settings fixed and finished, Behemoth Health Bar, crit share (Infinite)
Player's game only; server copies run none of it. Built on the 2026-11-13.2 release source (43ABA956).
DF-CWCACHE-1147: the ProcessEvent tag cache is keyed by function, name and outer and replaces entries round-robin, so the
crit rows no longer vanish from Options after some hunts (a freed function's slot was reused by another function).
DF-CRITUI-1147: Crit Style is a carousel like Frame Rate Limit with the style names (Normal, Comic, Inferno, Frost, Void,
Rainbow, Fel), filled with the game's own carousel item builder (exe+0x1E0A490) and select (exe+0x1E115C0); sliders show
their number (Camera Distance style). Drags arrive through RespondToSliderChange (tag 13); about a second after a drag the
slider jumped back to the value set when the page opened, so the dragged value is now set on the slider when the drag
stops and a jump of more than one step within 3 s is undone. Each style has its own game font. Styled crits get white on
the record colour (combat_text_widget_bpc tints the whole widget with it, which turned dark styles into blobs) and their
letter colour on the text block alone. New rows: Crit Opacity (0-100 %, Widget.SetRenderOpacity), Part / Stagger / Wound
Crit Colour (the number's type from its font material, record +0x48). A reused number widget gets its own font material
back (after a crit it kept the first one seen). Settings in data\crittext.txt: on, style, size, pop, tilt, hang, hbar,
alpha, stagger, wound, part. Crit Numbers is OFF by default; stagger Blue, wound Red, part = the style's own colour.
DF-HPBAR-1147: "Behemoth Health Bar" row (off by default): a bar with the behemoth's name; "Move Health Bar" unlocks it
to be dragged, unticking or closing Options locks and saves it.
DF-CRITSHARE-1147: each hunt has a chat room (Hunt-<id>); the loader posts one line "DFCRIT1 <on> <style> <name>" there
3 s after joining, every 30 s, when someone joins and when the setting changes, through the game's own SendRoomChat
(exe+0xBAFF20). Every loader reads these lines at the room message broadcast (exe+0xBC4A20) and drops them, so no chat
window shows them; if a player's own line does not come back hidden within 5 s, sharing stops for that session. A
number's dealer is ArchonCombatTextRecord.DamageInstigator (found by name, logged once): a pawn with a Controller is the
player, a pawn whose PlayerState name shared a style gets that style with the viewer's own colours, size and opacity,
any other dealer keeps the game's look. Log lines start "crit share:". Also a "crit perf:" line every 15 s with crit
numbers on screen (frame time with and without them).
DF-HPSTACK (Nov 18, second build): when more than one behemoth is in the fight, up to three more health bars stack
under the first, each with its own name (hurt ones within 200 m, untouched ones within 90 m; the first is the one being
fought or the nearest). The log says "health bar: N behemoth(s) shown" when the number changes.
