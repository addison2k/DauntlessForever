# Dauntless 1.14.7 - DF-BIGMOVE-1147 (Nov 7): log-only watch on player capsules moved over 50 m in one call.
# Applied to the E786646A source (Loader1147-AoeFx-MoveDisc-HeldCount-source.zip). Each edit must match once.
#   python3 patch-bigmove.py <d1147.cpp>
import sys

p = sys.argv[1]
t = open(p, encoding='utf-8', newline='').read()
nl = '\r\n' if '\r\n' in t else '\n'

def rep(old, new):
    global t
    old = old.replace('\n', nl); new = new.replace('\n', nl)
    c = t.count(old)
    assert c == 1, 'expected exactly one match, found %d for: %r' % (c, old[:80])
    t = t.replace(old, new)

# 1. the watch itself, placed in front of the DF-MOVEDISC block's comment
rep("// D1147_MOVEDISC=0 leaves the engine as it is.\n",
"""// D1147_MOVEDISC=0 leaves the engine as it is.
// ---------------------------------------------------------------------------- DF-BIGMOVE-1147 (Nov 7)
// The hunt server warning "UCapsuleComponent::MoveComponentImpl: Large movement was detected without the teleport flag
// set" (1000 of them in five fall reports, 657 in one) is printed by the exe's own override at +0x3CA1A60 when ONE move
// is over 5000 units (50 m, |delta|^2 > 25,000,000), has no teleport flag, and the capsule is not at the world origin;
// it then calls the normal move with the same arguments. So the warning is a symptom: something relocated a capsule
// 50 m in one step. This watch says WHO: for a player capsule moved over 50 m (teleport or not) it logs from, to,
// sweep, teleport, flags and the exe return addresses (the exe's own unwind data), so one test run names the game code
// that relocates players during a fall. Log only, nothing changed. D1147_BIGMOVE=0 off. 300 lines per server copy.
static int g_bigMove = 1;
static volatile LONG g_bigMoveN = 0, g_bigMoveAll = 0, g_bigMoveOther = 0;
static bool (*orig_CapMove)(void*, const float*, const void*, bool, void*, uint32_t, uint8_t) = 0;
static const char* name_of(void* obj, char* out, int n);
static void bigmove_note(void* comp, const float* d, bool sweep, uint32_t flags, uint8_t tp) {
    void* owner = at<void*>((uintptr_t)comp + 0x20);                     // A::Object_Outer: the actor that owns the capsule
    char on[128]; name_of(owner, on, sizeof(on));
    if (!strstr(on, "PlayerCharacter")) { InterlockedIncrement(&g_bigMoveOther); return; }
    const LONG all = InterlockedIncrement(&g_bigMoveAll);
    if (InterlockedIncrement(&g_bigMoveN) > 300) return;
    const float* from = (const float*)((uintptr_t)comp + 0x11C);          // USceneComponent::RelativeLocation (root: world)
    void* fr[12] = { 0 }; USHORT got = RtlCaptureStackBackTrace(0, 12, fr, 0);
    char stack[256]; int k = 0; stack[0] = 0;
    for (USHORT i = 0; i < got && k < (int)sizeof(stack) - 16; i++) {
        uintptr_t a = (uintptr_t)fr[i];
        if (a > g_base && a < g_base + 0x8000000) k += snprintf(stack + k, sizeof(stack) - k, " %llX", (unsigned long long)(a - g_base));
    }
    logf_("big move #%ld: %s  from %.0f %.0f %.0f  to %.0f %.0f %.0f  (%.0f m)  sweep %d  teleport %d  flags %u  callers%s",
          all, on, from[0], from[1], from[2], from[0] + d[0], from[1] + d[1], from[2] + d[2],
          sqrtf(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]) / 100.0f, (int)sweep, (int)tp, flags, stack);
}
static bool hook_CapMove(void* comp, const float* d, const void* rot, bool sweep, void* hit, uint32_t flags, uint8_t tp) {
    if (g_bigMove && d && comp && d[0] * d[0] + d[1] * d[1] + d[2] * d[2] > 25000000.0f) bigmove_note(comp, d, sweep, flags, tp);
    return orig_CapMove(comp, d, rot, sweep, hit, flags, tp);
}
""")

# 2. the switch, next to the others
rep("""    if (GetEnvironmentVariableA("D1147_MOVEDISC", v, sizeof(v)) && v[0] == '0') g_moveDisc = 0;   // DF-MOVEDISC-1147
""",
"""    if (GetEnvironmentVariableA("D1147_MOVEDISC", v, sizeof(v)) && v[0] == '0') g_moveDisc = 0;   // DF-MOVEDISC-1147
    if (GetEnvironmentVariableA("D1147_BIGMOVE", v, sizeof(v)) && v[0] == '0') g_bigMove = 0;     // DF-BIGMOVE-1147
""")

# 3. the hook, server copies only (this block runs only in server mode), first bytes checked
rep("""    ok &= install_equipment_bridge();
""",
"""    ok &= install_equipment_bridge();

    // DF-BIGMOVE-1147: push rbx / push rsi / push rdi / push r12 / push r14 / push r15 at the capsule move override
    if (g_bigMove) { static const uint8_t e[10] = { 0x40, 0x53, 0x56, 0x57, 0x41, 0x54, 0x41, 0x56, 0x41, 0x57 };
        if (!hook(0x3CA1A60, e, 10, (void*)hook_CapMove, (void**)&orig_CapMove, "big move watch (capsule)")) g_bigMove = 0; }
    logf_("big move watch (player capsule moved over 50 m in one step, log only): %s", g_bigMove ? "on" : "off");
""")

# 4. the milestone line, so a log says which build ran
rep("milestone 2c-fix5 (dxgi forwarding retries",
    "milestone 2c-fix5 + BigMove Nov 7 (dxgi forwarding retries")

if '#include <math.h>' not in t:
    rep('#include <string.h>\n', '#include <string.h>\n#include <math.h>\n')

open(p, 'w', encoding='utf-8', newline='').write(t)
print('patched', p)
