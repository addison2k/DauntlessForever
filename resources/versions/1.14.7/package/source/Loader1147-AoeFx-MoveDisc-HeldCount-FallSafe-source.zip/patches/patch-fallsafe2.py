# Dauntless 1.14.7 - DF-FALLSAFE-1147 (Nov 7): the endless fall in escalations. Applied AFTER patch-bigmove.py.
#   python3 patch-fallsafe.py <d1147.cpp>
import sys

p = sys.argv[1]
t = open(p, encoding='utf-8', newline='').read()
nl = '\r\n' if '\r\n' in t else '\n'

def rep(old, new):
    global t
    old = old.replace('\n', nl); new = new.replace('\n', nl)
    c = t.count(old)
    assert c == 1, 'expected exactly one match, found %d for: %r' % (c, old[:80])
    t = t.replace(old, new)

assert 'DF-BIGMOVE-1147' in t, 'apply patch-bigmove.py first'

# 1. the fall-safe code goes in front of the capsule hook, which calls it after every move
rep("""static bool hook_CapMove(void* comp, const float* d, const void* rot, bool sweep, void* hit, uint32_t flags, uint8_t tp) {
    if (g_bigMove && d && comp && d[0] * d[0] + d[1] * d[1] + d[2] * d[2] > 25000000.0f) bigmove_note(comp, d, sweep, flags, tp);
    return orig_CapMove(comp, d, rot, sweep, hit, flags, tp);
}
""",
"""// ---------------------------------------------------------------------------- DF-FALLSAFE-1147 (Nov 7, v2)
// The endless fall, caught by DF-BIGMOVE on Addison's PC (Nov 7 19:18, Radiant escalation, solo): the game's own fall
// rescue is a Blueprint on a timer (about every 4.3 s) that calls AActor::K2_TeleportTo with fixed points that have no
// floor on our servers, so the player drops 170 m and the rescue fires again, forever (25 rescues in 90 s). "I'm stuck"
// (AActor::K2_SetActorTransform) sent him to the first round's start, 745 m away, also over nothing.
// This keeps, per player, a SAFE place: where the server saw them standing (CharacterMovement MovementMode 1 Walking or
// 2 NavWalking) after 1.5 s of standing or walking without a break, taken from 1 s back, so it is never the very edge
// they stepped off and never the spot a teleport just dropped them on. When a Blueprint K2_TeleportTo or
// K2_SetActorTransform is called on a player who is more than 30 m below that place, or aimed at a point that already
// dropped a player 30 m, it goes to that place 1.5 m up instead and their fall speed is set to zero. v1 (BCBBADCB, Nov 7
// 19:32) took the last standing frame (the ledge edge) and kept the fall speed, so players slid off again.
// Players standing normally are never touched. Round changes, respawns and engine teleports do not use these two
// functions. Everything is dropped when the world changes. Every change is logged. D1147_FALLSAFE=0 turns it off.
static int g_fallSafe = 1;
struct FsSample { ULONGLONG t; float p[3]; };
struct FsPlayer { void* actor; void* cls; float safe[3]; bool has; float pend[3]; ULONGLONG pendAt; ULONGLONG walkSince; ULONGLONG quietUntil; FsSample ring[16]; int ringN; };
static FsPlayer g_fsP[32]; static int g_fsPN = 0;
struct FsKind { void* actor; void* cls; int8_t player; };
static FsKind g_fsKind[1024]; static int g_fsKindN = 0;
static float g_fsBad[16][3]; static int g_fsBadN = 0;
static void* g_fsWorld = 0;
static volatile LONG g_fsFixed = 0;
static void fs_world_check() {
    void* w = at<void*>(g_base + A::GWorld);
    if (w != g_fsWorld) { g_fsWorld = w; g_fsPN = 0; g_fsBadN = 0; memset(g_fsKind, 0, sizeof(g_fsKind)); g_fsKindN = 0; }
}
static bool fs_is_player(void* actor) {
    void* cls = at<void*>((uintptr_t)actor + A::Object_Class);
    uintptr_t h = (((uintptr_t)actor >> 4) ^ ((uintptr_t)actor >> 13)) & 1023;
    for (int i = 0; i < 1024; i++) {
        FsKind& k = g_fsKind[(h + i) & 1023];
        if (k.actor == actor && k.cls == cls) return k.player == 1;
        if (!k.actor) {
            if (g_fsKindN > 900) { memset(g_fsKind, 0, sizeof(g_fsKind)); g_fsKindN = 0; return fs_is_player(actor); }
            char nm[128]; name_of(actor, nm, sizeof(nm));
            k.actor = actor; k.cls = cls; k.player = strstr(nm, "PlayerCharacter") ? 1 : 0; g_fsKindN++;
            return k.player == 1;
        }
    }
    return false;
}
static FsPlayer* fs_player(void* actor, bool make) {
    void* cls = at<void*>((uintptr_t)actor + A::Object_Class);
    for (int i = 0; i < g_fsPN; i++) if (g_fsP[i].actor == actor && g_fsP[i].cls == cls) return &g_fsP[i];
    if (!make || g_fsPN >= 32) return 0;
    FsPlayer* q = &g_fsP[g_fsPN++]; memset(q, 0, sizeof(*q)); q->actor = actor; q->cls = cls; return q;
}
static float fs_dist2(const float* a, const float* b) { float x = a[0] - b[0], y = a[1] - b[1], z = a[2] - b[2]; return x * x + y * y + z * z; }
// after a capsule move: keep the safe place; learn teleport points that drop players
static void fs_after_move(void* comp) {
    void* actor = at<void*>((uintptr_t)comp + A::Object_Outer);
    if (!actor) return;
    fs_world_check();
    if (!fs_is_player(actor)) return;
    if (at<void*>((uintptr_t)actor + 0x290) != comp) return;              // ACharacter::CapsuleComponent: the character's own capsule
    FsPlayer* q = fs_player(actor, true); if (!q) return;
    const ULONGLONG now = GetTickCount64();
    const float* loc = (const float*)((uintptr_t)comp + 0x11C);           // USceneComponent::RelativeLocation (root: world)
    void* cmc = at<void*>((uintptr_t)actor + 0x288);                      // ACharacter::CharacterMovement
    const uint8_t mode = cmc ? at<uint8_t>((uintptr_t)cmc + 0x168) : 0;   // MovementMode: 1 Walking, 2 NavWalking, 3 Falling
    if ((mode == 1 || mode == 2) && now >= q->quietUntil) {
        if (!q->walkSince) { q->walkSince = now; q->ringN = 0; }
        if (!q->ringN || now - q->ring[(q->ringN - 1) & 15].t >= 200) { FsSample& s = q->ring[q->ringN & 15]; s.t = now; memcpy(s.p, loc, 12); q->ringN++; }
        if (now - q->walkSince >= 1500) {                                 // 1.5 s on the ground without a break: take where they were 1 s ago
            for (int i = q->ringN - 1; i >= 0 && i >= q->ringN - 16; i--) {
                const FsSample& s = q->ring[i & 15];
                if (s.t >= q->walkSince && now - s.t >= 1000) { memcpy(q->safe, s.p, 12); q->has = true; break; }
            }
        }
    } else { q->walkSince = 0; q->ringN = 0; }
    if (q->pendAt) {
        if (now - q->pendAt > 6000) q->pendAt = 0;
        else if (loc[2] < q->pend[2] - 3000.0f) {
            bool known = false; for (int i = 0; i < g_fsBadN; i++) if (fs_dist2(g_fsBad[i], q->pend) < 250000.0f) known = true;
            if (!known && g_fsBadN < 16) {
                memcpy(g_fsBad[g_fsBadN++], q->pend, 12);
                logf_("fall safe: the point %.0f %.0f %.0f has no floor on this server (a player dropped 30 m after a teleport there); teleports there now go to the player's safe place", q->pend[0], q->pend[1], q->pend[2]);
            }
            q->pendAt = 0;
        }
    }
}
// decides for one Blueprint relocation of a player: 0 = leave it, 1 = send to 'to', 2 = already there, skip it
static int fs_decide(void* actor, const float* dest, const char* how, float* to) {
    if (!g_fallSafe || !actor || !dest) return 0;
    fs_world_check();
    void* root = at<void*>((uintptr_t)actor + 0x130);                      // AActor::RootComponent
    FsPlayer* q = (root && fs_is_player(actor)) ? fs_player(actor, false) : 0;
    if (!q || !q->has) return 0;
    const float* cur = (const float*)((uintptr_t)root + 0x11C);
    if (fs_dist2(dest, cur) < 250000.0f) return 0;                        // a move under 5 m (abilities, small fixes) is never touched
    const bool fell = cur[2] < q->safe[2] - 3000.0f;
    bool bad = false; for (int i = 0; i < g_fsBadN; i++) if (fs_dist2(g_fsBad[i], dest) < 250000.0f) bad = true;
    const ULONGLONG now = GetTickCount64();
    q->quietUntil = now + 1000;                                            // the landing spot of any relocation is not a safe place by itself
    q->walkSince = 0; q->ringN = 0;
    if (!fell && !bad) { memcpy(q->pend, dest, 12); q->pendAt = now; return 0; }
    q->pendAt = 0;
    to[0] = q->safe[0]; to[1] = q->safe[1]; to[2] = q->safe[2] + 150.0f;
    char nm[128]; name_of(actor, nm, sizeof(nm));
    const LONG n = InterlockedIncrement(&g_fsFixed);
    void* cmc = at<void*>((uintptr_t)actor + 0x288);
    if (cmc) { float* v = (float*)((uintptr_t)cmc + 0xC4); v[0] = v[1] = v[2] = 0.0f; }   // UMovementComponent::Velocity: no fall speed carried over
    if (fs_dist2(to, cur) < 40000.0f) {
        if (n <= 200) logf_("fall safe #%ld: %s is already at its safe place; the %s to %.0f %.0f %.0f is skipped", n, nm, how, dest[0], dest[1], dest[2]);
        return 2;
    }
    if (n <= 200) logf_("fall safe #%ld: %s %s to %.0f %.0f %.0f goes to its safe place %.0f %.0f %.0f instead (%s; it was at %.0f %.0f %.0f)",
                        n, nm, how, dest[0], dest[1], dest[2], to[0], to[1], to[2], fell ? "it fell more than 30 m below that place" : "that point has no floor here", cur[0], cur[1], cur[2]);
    return 1;
}
static bool (*orig_K2Tele)(void*, float*, float*) = 0;
static bool hook_K2Tele(void* actor, float* dest, float* rot) {
    float to[3]; const int d = fs_decide(actor, dest, "rescue teleport", to);
    if (d == 2) return true;
    if (d == 1) { float mine[3] = { to[0], to[1], to[2] }; return orig_K2Tele(actor, mine, rot); }
    return orig_K2Tele(actor, dest, rot);
}
static bool (*orig_K2SetXform)(void*, const float*, bool, void*, bool) = 0;
static bool hook_K2SetXform(void* actor, const float* xf, bool sweep, void* hit, bool teleport) {
    float to[3]; const int d = fs_decide(actor, xf ? xf + 4 : 0, "\\"I'm stuck\\" move", to);   // FTransform: rotation 0x00, translation 0x10, scale 0x20
    if (d == 2) return true;
    if (d == 1) { alignas(16) float mine[12]; memcpy(mine, xf, 48); mine[4] = to[0]; mine[5] = to[1]; mine[6] = to[2]; return orig_K2SetXform(actor, mine, sweep, hit, teleport); }
    return orig_K2SetXform(actor, xf, sweep, hit, teleport);
}
static bool hook_CapMove(void* comp, const float* d, const void* rot, bool sweep, void* hit, uint32_t flags, uint8_t tp) {
    if (g_bigMove && d && comp && d[0] * d[0] + d[1] * d[1] + d[2] * d[2] > 25000000.0f) bigmove_note(comp, d, sweep, flags, tp);
    const bool r = orig_CapMove(comp, d, rot, sweep, hit, flags, tp);
    if (g_fallSafe && comp) fs_after_move(comp);
    return r;
}
""")

# 2. the switch
rep("""    if (GetEnvironmentVariableA("D1147_BIGMOVE", v, sizeof(v)) && v[0] == '0') g_bigMove = 0;     // DF-BIGMOVE-1147
""",
"""    if (GetEnvironmentVariableA("D1147_BIGMOVE", v, sizeof(v)) && v[0] == '0') g_bigMove = 0;     // DF-BIGMOVE-1147
    if (GetEnvironmentVariableA("D1147_FALLSAFE", v, sizeof(v)) && v[0] == '0') g_fallSafe = 0;   // DF-FALLSAFE-1147
""")

# 3. the hooks: the capsule hook now serves both (installed when either is on); K2_TeleportTo for the fall safe
rep("""    if (g_bigMove) { static const uint8_t e[10] = { 0x40, 0x53, 0x56, 0x57, 0x41, 0x54, 0x41, 0x56, 0x41, 0x57 };
        if (!hook(0x3CA1A60, e, 10, (void*)hook_CapMove, (void**)&orig_CapMove, "big move watch (capsule)")) g_bigMove = 0; }
    logf_("big move watch (player capsule moved over 50 m in one step, log only): %s", g_bigMove ? "on" : "off");
""",
"""    if (g_bigMove || g_fallSafe) { static const uint8_t e[10] = { 0x40, 0x53, 0x56, 0x57, 0x41, 0x54, 0x41, 0x56, 0x41, 0x57 };
        if (!hook(0x3CA1A60, e, 10, (void*)hook_CapMove, (void**)&orig_CapMove, "capsule moves (big move watch, fall safe)")) { g_bigMove = 0; g_fallSafe = 0; } }
    // DF-FALLSAFE-1147: sub rsp,38h / mov rax,[rcx] / xor r9d,r9d at AActor::K2_TeleportTo
    if (g_fallSafe) { static const uint8_t e[10] = { 0x48, 0x83, 0xEC, 0x38, 0x48, 0x8B, 0x01, 0x45, 0x33, 0xC9 };
        if (!hook(0x18E17F0, e, 10, (void*)hook_K2Tele, (void**)&orig_K2Tele, "Blueprint teleports (fall safe)")) g_fallSafe = 0; }
    // push rbp / lea rbp,[rsp-4Fh] / sub rsp,0D0h at AActor::K2_SetActorTransform ("I'm stuck")
    if (g_fallSafe) { static const uint8_t e[11] = { 0x40, 0x55, 0x48, 0x8D, 0x6C, 0x24, 0xB1, 0x48, 0x81, 0xEC, 0xD0 };
        if (!hook(0x3B63C90, e, 11, (void*)hook_K2SetXform, (void**)&orig_K2SetXform, "Blueprint set-transform (fall safe)")) g_fallSafe = 0; }
    logf_("big move watch (player capsule moved over 50 m in one step, log only): %s", g_bigMove ? "on" : "off");
    logf_("fall safe v2 (a rescue or I am stuck move on a falling player goes to where they last stood 1.5 s, fall speed zeroed): %s", g_fallSafe ? "on" : "off (D1147_FALLSAFE=0)");
""")

# 4. milestone
rep("milestone 2c-fix5 + BigMove Nov 7 (", "milestone 2c-fix5 + BigMove + FallSafe2 Nov 7 (")

open(p, 'w', encoding='utf-8', newline='').write(t)
print('patched', p)
