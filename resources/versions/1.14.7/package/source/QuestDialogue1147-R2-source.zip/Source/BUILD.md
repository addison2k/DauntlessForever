# Build and source — Quest Dialogue Fallback 1.14.7

Python 3.10+ and Node.js 18+ are sufficient to rebuild from the supplied original extracted inputs. Windows installation uses Windows PowerShell 5.1+ and Node.js. Run commands from this Source directory:

```
python3 tools/audit_quests.py
python3 tools/build_dialogue.py
python3 tools/build_report.py
node tools/test_release.cjs
```

`patch/Tools` contains the installer sources and is already present. The builder writes the PAK, manifest and intermediate localization resources under `patch`. Ship the PAK under Payload; `Payload/localization` is only an intermediate used by tests. Restore CMD wrappers and documentation are included in patch.

The independent JS test substitutes synthetic original-file hashes only in a temporary copy of the installer for mutation/rollback fixtures. It does not alter the shipping manifest or claim native Windows tests. Localization tests use the supplied original game data and the actual generated payload.

## Re-extract inputs from official manifest (optional)

The exact build manifest is included. To download only relevant archive chunks and reproduce extracted inputs, use a separate working copy, remove its assets and indexes directories, then:

```
python3 -m pip install --target tools/deps pyooz==0.0.8
python3 tools/inspect_paks.py Archon_25-WindowsClient.pak Archon_Intl_0-WindowsClient.pak
python3 tools/pak_entries.py /Gameplay/quests/ /Localization/Game/
```

This requires access to the original Epic CDN. Epic chunks and extracted PAK entries are checked against their original SHA1 hashes. Source assets are from 1.14.7 build 647472 only. No later or earlier game assets are imported.

## Provenance

Manifest: https://raw.githubusercontent.com/addison2k/DauntlessManifestArchive/main/manifests/Windows/Dauntless_1.14.7.647472.manifest
SHA256: c7380ac8f94cd700edb4af7a393721f064ae2cb9b9a668a6f7363bde16c5812a
Quest archive: Archon_25-WindowsClient.pak
Localization archive: Archon_Intl_0-WindowsClient.pak
Official server package reviewed as a reference, not changed: https://github.com/addison2k/DauntlessForever/releases/download/packages/1.14.7-2026-10-15.zip
SHA256: 9219bb60a7a5d212c80c055dfa87dbfb69b586113f5445a1123415fab25852e7

LOCRES serialization uses supported legacy Compact version 1. Original input uses version 3. The output PAK uses legacy version 8 (221-byte footer), not the rejected FrozenIndex version 9. Namespace/key strings, source hashes and localized values are preserved; only the serialization and added fallback keys differ.
Format references:
https://github.com/FabianFG/CUE4Parse/blob/master/CUE4Parse/UE4/Pak/Objects/FPakInfo.cs
https://github.com/FabianFG/CUE4Parse/blob/master/CUE4Parse/UE4/Localization/FTextLocalizationResource.cs
https://github.com/folgerwang/UnrealEngine/blob/release/Engine/Source/Runtime/Core/Private/Internationalization/TextLocalizationResource.cpp

Patch-specific tools and installer are AGPL-3.0-only. Original game assets retain their original rights and are not relicensed as AGPL. `tools/manifest.py` is derived from Legendary's manifest parser (https://github.com/derrod/legendary/blob/master/legendary/models/manifest.py); the only local adaptation makes the unused AES import optional for this unencrypted manifest. See Legendary-LICENSE.txt (GPL-3.0). Optional extraction dependency pyooz/ooz is separately licensed GPL-3.0-or-later: https://github.com/zao/pyooz. Platform binaries are not bundled here.
