// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),{entries}=require('./paks.cjs');
const HOME=path.dirname(__dirname),read=p=>JSON.parse(fs.readFileSync(p,'utf8')),hash=(p,kind='sha256')=>{if(!fs.existsSync(p))return null;return crypto.createHash(kind).update(fs.readFileSync(p)).digest('hex');};
function atomic(p,b){fs.mkdirSync(path.dirname(p),{recursive:true});const t=p+'.dialogue-'+crypto.randomBytes(6).toString('hex');try{fs.writeFileSync(t,b,{flag:'wx'});fs.renameSync(t,p);}finally{fs.rmSync(t,{force:true});}}
function setup(game){game=path.resolve(game);const m=read(path.join(HOME,'manifest.json'));return{game,m,target:path.join(game,'Archon/Content/Paks',m.pak),state:path.join(game,'PatchState/QuestDialogue1147'),record:path.join(game,'PatchState/QuestDialogue1147/installation.json')};}
function originals(p){for(const[rel,want]of Object.entries(p.m.original_sha1))if(hash(path.join(p.game,rel),'sha1')!==want)throw Error('Wrong or changed 1.14.7 CL647472 original: '+rel);}
function payload(p){if(hash(path.join(HOME,'Payload',p.m.pak))!==p.m.pak_sha256)throw Error('Damaged patch payload');const b=fs.readFileSync(path.join(HOME,'Payload',p.m.pak)),f=b.subarray(b.length-221);if(f.readUInt32LE(17)!==0x5a6f12e1||f.readUInt32LE(21)!==8||Number(f.readBigUInt64LE(25))+Number(f.readBigUInt64LE(33))!==b.length-221)throw Error('Unsupported PAK format: expected legacy version 8; version 9 is rejected by this game.');}
function conflicts(p){const dir=path.join(p.game,'Archon/Content/Paks'),known=new Set(p.m.original_paks.map(x=>x.toLowerCase())),targets=new Set(p.m.localization_paths.map(x=>x.toLowerCase()));for(const n of fs.readdirSync(dir)){if(!n.toLowerCase().endsWith('.pak')||n===p.m.pak||known.has(n.toLowerCase()))continue;let rows;try{rows=entries(path.join(dir,n));}catch(e){throw Error('Cannot check extra PAK '+n+': '+e.message);}if(rows.some(x=>targets.has(x)))throw Error('Conflicting localization overlay: '+n);}}
function validRecord(p,r){if(r.game!==p.game||r.target!==p.target||r.status!=='installed'||r.sha256!==p.m.pak_sha256)throw Error('Installation record differs');if(r.before!==null&&r.before!==p.m.pak_sha256)throw Error('Unexpected original overlay hash');if(r.backup&&(r.backup!=='previous.pak'||hash(path.join(p.state,r.backup))!==r.before))throw Error('Previous overlay backup missing or damaged');}
function check(game){const p=setup(game);originals(p);payload(p);if(!fs.existsSync(p.record))throw Error('Patch is not installed');const r=read(p.record);validRecord(p,r);if(hash(p.target)!==p.m.pak_sha256)throw Error('Installed overlay differs');conflicts(p);console.log(JSON.stringify({code:'matches',patch:p.m.patch,revision:p.m.revision,pak_format:8,game:'1.14.7 CL647472',cultures:p.m.cultures.map(c=>c.culture),quests_audited:807,dialogue_fallbacks_per_culture:2839,backend_changes:'none',native_game_test:'required: check NPC acceptance, dialogue pages and completion text'},null,2));return r;}
function install(game,opt={}){
 const p=setup(game);originals(p);payload(p);conflicts(p);
 const oldBytes=fs.existsSync(p.record)?fs.readFileSync(p.record):null,old=oldBytes?JSON.parse(oldBytes):null;
 const before=hash(p.target),legacy=(p.m.supersedes_sha256||[]).includes(before);
 if(old&&old.sha256===p.m.pak_sha256)return check(game);
 if(old){
  if(!legacy||old.sha256!==before||old.game!==p.game||old.target!==p.target||old.status!=='installed'||old.revision!==1||![null,before].includes(old.before))throw Error('Unrecognized or changed previous installation');
  if(old.backup&&(old.backup!=='previous.pak'||hash(path.join(p.state,old.backup))!==old.before))throw Error('Previous overlay backup missing or damaged');
 }
 if(before!==null&&before!==p.m.pak_sha256&&!legacy)throw Error('A different file already uses the patch filename');
 const saved=before===null?null:fs.readFileSync(p.target);
 // A verified R1 overlay is obsolete; restoring R2 removes it rather than reinstating a crashing PAK.
 const retain=saved&&!legacy;if(retain)atomic(path.join(p.state,'previous.pak'),saved);
 const r={status:'installed',game:p.game,target:p.target,sha256:p.m.pak_sha256,before:retain?before:null,backup:retain?'previous.pak':null,revision:p.m.revision,replaces_revision:legacy?1:null};
 try{
  if(before!==p.m.pak_sha256)atomic(p.target,fs.readFileSync(path.join(HOME,'Payload',p.m.pak)));
  if(opt.failAfterWrite)throw Error('Injected failure');
  if(hash(p.target)!==p.m.pak_sha256)throw Error('Overlay write verification failed');
  atomic(p.record,Buffer.from(JSON.stringify(r,null,2)+'\n'));return check(game);
 }catch(e){if(saved)atomic(p.target,saved);else fs.rmSync(p.target,{force:true});if(oldBytes)atomic(p.record,oldBytes);else fs.rmSync(p.record,{force:true});throw e;}
}
function restore(game){const p=setup(game);if(!fs.existsSync(p.record))throw Error('No installation record');const r=read(p.record);validRecord(p,r);const current=hash(p.target);if(current!==null&&current!==p.m.pak_sha256)throw Error('Overlay changed; refusing to delete a different file');if(r.before===null)fs.rmSync(p.target,{force:true});else atomic(p.target,fs.readFileSync(path.join(p.state,r.backup)));fs.renameSync(p.record,path.join(p.state,'restored-'+Date.now()+'.json'));console.log('Dialogue overlay removed; original game, launcher, backend and saves unchanged.');}
module.exports={install,check,restore,entries};
if(require.main===module)try{const[mode,game]=process.argv.slice(2);if(!game)throw Error('Installed game folder required');if(mode==='install')install(game);else if(mode==='check')check(game);else if(mode==='restore')restore(game);else throw Error('Use install/check/restore');}catch(e){console.error('Quest Dialogue patch stopped: '+e.message);process.exitCode=1;}
