QUEST DIALOGUE FALLBACK — DAUNTLESS 1.14.7 CL647472 — R2

INSTALL
1. Extract this entire folder. Close Dauntless, all hunt servers and the launcher.
2. Double-click Install.cmd. It can directly replace the verified R1 patch; no prior restore is required. It detects the configured 1.14.7 game folder; if not found, enter the folder containing Archon.
3. Launch 1.14.7 normally. Test Markus's Unlocked Potential / To the Training Grounds dialogue, then other NPC offers and turn-ins.
Check-Installed.cmd verifies the installed overlay. Restore.cmd removes this patch.
Open-Quest-Audit.cmd opens the searchable audit of every quest record found.
Keep this extracted folder until finished testing.

WHAT CHANGED
The client asks for dialogue addressed to an "Unspecified" player gender. Original localization contains Feminine, Masculine and Neutral addressee variants, but lacks the Unspecified variant shown in the reported errors.
The overlay adds 2,839 missing fallback entries to each of the eight original languages, copying each speaker's original Neutral wording and source hash. All 36,613 original entries per language are preserved.
The PAK now uses legacy version 8 with its matching 221-byte footer. R1 used version 9, which this engine rejects at mount time.
Only eight Game.locres localization resources are overlaid. Original PAKs and the disk executable remain untouched. Backend, launcher, saves, quest progression and rewards are not modified.

SCOPE AND LIMITS
Audit: 807 unique quest records in 103 series, including 767 Release, 33 Alpha and 7 Test records; 4,784 text references. Ten nested unlock assets contain no additional QuestID records. All referenced text keys exist; 3,198 gender-aware references lacked the Unspecified fallback.
This addresses the shared missing-text error across the audited quests. It does not establish that all quests are enabled or completable. Two unresolved AutoStartQuestID links are listed in Audit/Next-Quest-Warnings.json; neither is changed.
The audit covers quest assets under the original Gameplay/quests directory, not every possible ambient NPC line or externally generated server quest.

VALIDATION
Independent Python and JavaScript readers checked serialization, every original translation, all added fallbacks and all gender-aware quest references in all eight languages. PAK entries, index and payload hashes were checked. Installer fixtures passed install/check/reinstall, restore, known-overlay adoption, direct R1 upgrades with exact rollback, conflict rejection, changed-build rejection and failure rollback. PowerShell and JavaScript syntax checks passed.
Windows native gameplay was not executed. Verify actual NPC text in game, restart, and recheck offer, dialogue pages and completion text. Exact game EXE and original localization PAK are verified against the 1.14.7 manifest; 1.6.2 and 1.4.4 assets are not used.

RECOVERY
The overlay is installed under Archon/Content/Paks. Its receipt and any previous identical overlay backup are kept under <game>/PatchState/QuestDialogue1147, outside this extracted folder. Restore touches only this patch's overlay. If an unrelated localization mod conflicts, the installer stops before changing the game.

SOURCE / LICENSE
Source.zip contains the build, audit, installer and tests, original input assets and exact build manifest. Read Source/BUILD.md after extracting it. Patch code: AGPL-3.0-only; full license included. Original game content retains its original rights. The third-party Legendary manifest parser has its own GPL-3.0 license and attribution. No credentials or player saves are included.
