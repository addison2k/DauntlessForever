# SPDX-License-Identifier: AGPL-3.0-only
param([ValidateSet('install','check','restore')][string]$Mode='check')
$ErrorActionPreference='Stop'
try {
    if($Mode -ne 'check') {
        $running=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'Dauntless-Win64-Shipping.exe' -or $_.Name -eq 'Dauntless Forever.exe' })
        if($running.Count){throw 'Close the game, every hunt-server copy and the launcher first.'}
    }
    $game=$null;$node=$null;$launcher=$null;$configs=@()
    $dataRoots=@()
    if($env:DL_DATA_DIR){$dataRoots+=$env:DL_DATA_DIR}
    foreach($folder in @('DauntlessForever','DauntlessOffline')) { $dataRoots+=Join-Path $env:LOCALAPPDATA $folder }
    foreach($root in $dataRoots){$configs+=Join-Path $root 'versions\1.14.7\config.json'}
    $ancestor=[IO.DirectoryInfo]$PSScriptRoot
    while($null -ne $ancestor) {
        if(Test-Path -LiteralPath (Join-Path $ancestor.FullName 'resources\app.asar')) {
            $launcher=$ancestor.FullName
            $configs+=Join-Path $launcher 'resources\versions\1.14.7\package\config.json'
            break
        }
        $candidate=Join-Path $ancestor.FullName 'config.json'
        if((Test-Path -LiteralPath $candidate) -and (Test-Path -LiteralPath (Join-Path $ancestor.FullName 'tools\play-1147.ps1'))){$configs+=$candidate}
        $ancestor=$ancestor.Parent
    }
    foreach($file in $configs) {
        if(-not(Test-Path -LiteralPath $file)){continue}
        $cfg=Get-Content -LiteralPath $file -Raw | ConvertFrom-Json
        if($cfg.GameDir -and (Test-Path -LiteralPath (Join-Path $cfg.GameDir 'Archon\Binaries\Win64\Dauntless-Win64-Shipping.exe'))){$game=$cfg.GameDir;$node=$cfg.Node;break}
    }
    if(-not $game){$game=(Read-Host 'Enter the installed Dauntless 1.14.7 folder containing Archon').Trim().Trim('"')}
    $game=[IO.Path]::GetFullPath($game)
    if(-not(Test-Path -LiteralPath (Join-Path $game 'Archon\Binaries\Win64\Dauntless-Win64-Shipping.exe'))){throw 'That folder does not contain the game EXE.'}
    if($launcher -and (Test-Path -LiteralPath (Join-Path $launcher 'resources\runtime\node\node.exe'))){$node=Join-Path $launcher 'resources\runtime\node\node.exe'}
    if(-not $node -or -not(Test-Path -LiteralPath $node)){$node=(Get-Command node.exe -ErrorAction SilentlyContinue).Source}
    if(-not $node){$node=(Read-Host 'Enter the full path to the launcher Node.js executable').Trim().Trim('"')}
    if(-not(Test-Path -LiteralPath $node)){throw 'Node.js executable was not found.'}
    Write-Host "Detected game: $game"
    & $node (Join-Path $PSScriptRoot 'patch.cjs') $Mode $game
    if($LASTEXITCODE){throw 'Quest Dialogue operation failed. Read the detailed message above.'}
} catch {Write-Host "STOPPED: $($_.Exception.Message)" -ForegroundColor Red;exit 1}
