# Quest Dialogue Fallback 1.14.7 — R2

- Fixes the startup crash caused by R1's unsupported PAK version 9. Rebuilds the archive in legacy version 8 with the correct footer layout.
- Allows Install.cmd to replace a verified R1 overlay directly, including installations whose extracted folders moved. A failed upgrade restores the exact previous overlay and receipt.
- Restore removes the obsolete R1 overlay after a successful upgrade instead of putting the crashing file back.
- Adds an installer format check and regression tests for the PAK version, footer, direct upgrades and upgrade rollback.

The dialogue fallback still covers all eight languages. The searchable 807-quest audit, source and AGPL license are included. No backend files are changed. Native game testing is still required.
