# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import json,collections,html,csv
R=Path(__file__).resolve().parent.parent;O=R/'patch';A=O/'Audit';A.mkdir(exist_ok=True)
qs=json.loads((R/'audit/quests.json').read_text());refs=json.loads((R/'audit/text-references.json').read_text());series=json.loads((R/'audit/series.json').read_text());loc=__import__('locres').Locres((R/'assets/Archon/Content/Localization/Game/en/Game.locres').read_bytes()).entries;summary=json.loads((R/'audit/summary.json').read_text())
bykey=collections.defaultdict(list)
for x in loc:bykey[x['key']].append(x)
byquest=collections.defaultdict(list)
for ref in refs:
 if ref['quest']:byquest[ref['quest']].append(ref)
classification={s['asset'][:-7]:s['classification']for s in series}
names={'Speaker_Bosun':'Markus Boehr','speaker_weaponsmith':'Wils Bormen','Speaker_Kat':'Kat Sorrel','speaker_ozz_event_vendor':'Honest Ozz','Speaker_BehemothExpert':'Dr. Priyani','speaker_dyesmith':'Gregario Flynt','Speaker_Ostian_Admiral':'Admiral Zai','Speaker_Aethersmith':'Arkan Drew','Speaker_Farslayer':'Xelya','Speaker_Armoursmith':'Moyra','Speaker_Lady_Luck':'Lady Luck','speaker_middle_man':'The Middleman','speaker_linnea_ramsgate':'Linnea (Ramsgate)','speaker_linnea_boreal':'Linnea (Boreal)','speaker_linnea_coldrunner':'Linnea (Coldrunner)'}
def npc(path):
 if not path:return 'No explicit offer NPC'
 label=path.rsplit('.',1)[-1];return names.get(label,label)
full=[]
for q in qs:
 rows=[];seen=set()
 for ref in byquest[q['id']]:
  marker=(ref['key'],ref['kind'])
  if marker in seen:continue
  seen.add(marker);options=bykey[ref['key']]
  if ref['kind']=='gendered':options=[x for x in options if x['namespace'].endswith('Addressee: Neutral')and x['namespace'].startswith('Dauntless Dialog')]
  else:
   expected=str(ref.get('table')or'').removeprefix('Dialog_');matching=[x for x in options if x['namespace']==expected];options=matching or options
  texts=[];seen_text=set()
  for x in options:
   if x['text']in seen_text:continue
   seen_text.add(x['text']);texts.append({'namespace':x['namespace'],'text':x['text']})
  rows.append({'key':ref['key'],'kind':ref['kind'],'table':ref.get('table'),'property':ref['property'],'variants':texts})
 full.append({'npc':npc(q['offer_npc']),'turnin_npc':npc(q['turnin_npc']),'offer_asset':q['offer_npc'],'turnin_asset':q['turnin_npc'],'quest_id':q['id'],'title':q['title'],'series':q['series'],'classification':classification.get(q['series']),'auto_start':q['auto_start'],'texts':rows})
(A/'Quest-Dialogues.json').write_text(json.dumps(full,indent=2,ensure_ascii=False))
with(A/'Quest-List.csv').open('w',newline='')as f:
 w=csv.DictWriter(f,fieldnames=['npc','title','quest_id','series','classification','turnin_npc','auto_start']);w.writeheader();w.writerows({k:q.get(k)for k in w.fieldnames}for q in full)
ids={q['quest_id'].lower()for q in full};dangling=[{'quest':q['quest_id'],'series':q['series'],'classification':q['classification'],'next_quest':q['auto_start']}for q in full if q.get('auto_start')not in(None,'None')and q['auto_start'].lower()not in ids]
summary['quest_classifications']=dict(collections.Counter(q['classification']for q in full));summary['unresolved_auto_start_targets']=dangling;summary['limitation']='Static asset/reference audit; not a playthrough. Release classification does not prove currently enabled. No next-quest links changed.'
(A/'Summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False));(A/'Next-Quest-Warnings.json').write_text(json.dumps(dangling,indent=2))
esc=lambda s:html.escape(str(s or''))
options=''.join('<option>'+esc(x)+'</option>'for x in sorted(set(q['npc']for q in full)))
parts=[]
for q in sorted(full,key=lambda q:(q['npc'],q['series'],q['quest_id'])):
 text=''.join('<section><h4>'+esc(x['key'])+'</h4>'+''.join('<p class="text">'+esc(v['text'])+'</p>'for v in x['variants'])+'</section>'for x in q['texts'])
 parts.append('<details class="quest" data-npc="'+esc(q['npc'])+'" data-state="'+esc(q['classification'])+'"><summary><strong>'+esc(q['title']or q['quest_id'])+'</strong><span>'+esc(q['npc'])+' · '+esc(q['classification'])+'</span></summary><div class="body"><p><b>ID:</b> '+esc(q['quest_id'])+'<br><b>Series:</b> '+esc(q['series'])+'<br><b>Offer:</b> '+esc(q['npc'])+'<br><b>Turn-in:</b> '+esc(q['turnin_npc'])+'<br><b>Next quest:</b> '+esc(q['auto_start'])+'</p>'+text+'</div></details>')
page='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>1.14.7 Quest Dialogue Audit</title><style>
:root{color-scheme:dark}body{font:16px/1.55 system-ui,sans-serif;background:#111820;color:#e4ebef;margin:0}main{max-width:1100px;margin:auto;padding:30px 22px}h1{font-size:30px;margin-bottom:8px}.note{color:#aec1cd}header{padding-bottom:18px}.tools{position:sticky;top:0;background:#111820;padding:12px 0;display:flex;flex-wrap:wrap;gap:8px;z-index:2}input,select,button{font:inherit;padding:9px 12px;background:#202e3a;border:1px solid #445462;border-radius:6px;color:inherit}input{flex:1;min-width:240px}details{border:1px solid #354858;border-radius:8px;margin:10px 0;background:#18242e}summary{cursor:pointer;padding:14px 16px}summary span{display:block;color:#9fb7c7;margin-left:19px;font-size:14px}.body{padding:0 20px 20px}.text{white-space:pre-wrap;background:#101c25;padding:13px;border-left:3px solid #37c8c3}h4{font-size:13px;color:#9fc7d9;overflow-wrap:anywhere}section{margin:22px 0}#count{color:#75dcd5}a{color:#7adbd6}[hidden]{display:none}</style><main>
<header><h1>Every quest · Dauntless 1.14.7</h1><p class="note">807 quest records · 103 series · 4,784 text references · Original build 647472</p><p>This report includes release, legacy, alpha and test content. Presence in the files does not mean a quest is currently enabled. English gender-aware text below uses the original neutral-addressee wording. Rich-text and controller tokens are shown as stored.</p><p><a href="Audit/Quest-List.csv">Quest list CSV</a> · <a href="Audit/Quest-Dialogues.json">Complete dialogue JSON</a> · <a href="Audit/Next-Quest-Warnings.json">Two unresolved next-quest references</a></p></header>
<div class="tools"><input id="search" placeholder="Search NPC, quest title, ID or dialogue…" aria-label="Search quests"><select id="npc" aria-label="Filter NPC"><option value="">All NPCs / speakers</option>'''+options+'''</select><select id="state" aria-label="Filter classification"><option value="">All classifications</option><option>Release</option><option>Alpha</option><option>Test</option></select><button id="collapse">Collapse all</button></div><p id="count"></p>'''+''.join(parts)+'''
<script>const quests=[...document.querySelectorAll('.quest')],search=document.querySelector('#search'),npc=document.querySelector('#npc'),state=document.querySelector('#state'),count=document.querySelector('#count');const text=new Map(quests.map(q=>[q,q.textContent.toLowerCase()]));function filter(){const s=search.value.trim().toLowerCase();let n=0;for(const q of quests){q.hidden=Boolean((npc.value&&q.dataset.npc!==npc.value)||(state.value&&q.dataset.state!==state.value)||(s&&!text.get(q).includes(s)));if(!q.hidden)n++;}count.textContent=n+' / '+quests.length+' quests shown';}for(const el of [search,npc,state])el.addEventListener('input',filter);document.querySelector('#collapse').addEventListener('click',()=>quests.forEach(q=>q.open=false));filter();</script></main></html>'''
(O/'Quest-Dialogue-Audit.html').write_text(page)
print('Built searchable report:',len(full),'quests;',len(page.encode()),'bytes;',len(dangling),'next-quest warnings.')
