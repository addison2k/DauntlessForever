# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import sys,struct,json,hashlib,collections
sys.path.insert(0,str(Path(__file__).resolve().parent));from locres import Locres
R=Path(__file__).resolve().parent.parent;O=R/'patch';P=O/'Payload';P.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def string(s):
 if s.isascii():b=s.encode()+b'\0';return struct.pack('<i',len(b))+b
 b=s.encode('utf-16le')+bytes(2);return struct.pack('<i',-len(b)//2)+b
def compact(entries):
 groups=collections.OrderedDict();strings=[];indices={}
 for e in entries:
  groups.setdefault(e['namespace'],[]).append(e)
  if e['text']not in indices:indices[e['text']]=len(strings);strings.append(e['text'])
 body=bytearray(struct.pack('<I',len(groups)))
 for ns,items in groups.items():
  body+=string(ns)+struct.pack('<I',len(items))
  for e in items:body+=string(e['key'])+struct.pack('<Ii',e['hash'],indices[e['text']])
 string_offset=16+1+8+len(body);out=bytes.fromhex('0e147475674a03fc4a15909dc3377f1b')+bytes([1])+struct.pack('<q',string_offset)+body+struct.pack('<i',len(strings))
 return out+b''.join(string(s)for s in strings)
def pak(files):
 def entry(off,data):return struct.pack('<QQQI',off,len(data),len(data),0)+hashlib.sha1(data).digest()+struct.pack('<BI',0,0)
 b=bytearray();records=[]
 for n,data in sorted(files.items()):off=len(b);e=entry(off,data);b+=e+data;records.append((n,e))
 ix=string('../../../Archon/Content/')+struct.pack('<I',len(records))+b''.join(string(n)+e for n,e in records);off=len(b);b+=ix
 return bytes(b)+bytes(17)+struct.pack('<IIQQ',0x5a6f12e1,8,off,len(ix))+hashlib.sha1(ix).digest()+b'Zlib'.ljust(32,b'\0')+bytes(128)
files={};reports=[]
for p in sorted((R/'assets/Archon/Content/Localization/Game').glob('*/Game.locres')):
 original=Locres(p.read_bytes());old={(e['namespace'],e['key']):(e['hash'],e['text'])for e in original.entries};assert len(old)==len(original.entries)
 entries=list(original.entries);added=[]
 for e in original.entries:
  if not(e['namespace'].startswith('Dauntless Dialog * Speaker: ')and e['namespace'].endswith('& Addressee: Neutral')):continue
  ns=e['namespace'][:-len('Neutral')]+'Unspecified';key=(ns,e['key'])
  if key in old:continue
  added.append({**e,'namespace':ns})
 entries+=added;data=compact(entries);rebuilt=Locres(data);new={(e['namespace'],e['key']):(e['hash'],e['text'])for e in rebuilt.entries};assert len(new)==len(entries)
 for key,value in old.items():assert new[key]==value
 for e in added:assert new[(e['namespace'],e['key'])]==old[(e['namespace'][:-len('Unspecified')]+'Neutral',e['key'])]
 rel='Localization/Game/'+p.parent.name+'/Game.locres';files[rel]=data;dest=P/'localization'/p.parent.name/'Game.locres';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 reports.append({'culture':p.parent.name,'original_entries':len(original.entries),'added_fallback_entries':len(added),'patched_entries':len(new),'original_sha256':sha(p.read_bytes()),'patched_sha256':sha(data),'original_entries_unchanged':True})
name='zzzzzzzzzzzzzzzz_QuestDialogueFallback1147_P.pak';data=pak(files);(P/name).write_bytes(data)
manifest={'patch':'Quest Dialogue Fallback 1.14.7','revision':2,'pak_format':8,'supersedes_sha256':['ecb2d6960527073b8edc9932bd9562a3dc78e1c4ead8945a178aa85ac3c34a44'],'game_build':'647472','pak':name,'pak_sha256':sha(data),'localization_paths':sorted('Archon/Content/'+x for x in files),'cultures':reports,'native_game_test':'required; this build validates data lookup coverage and serialization, not a running Windows client'}
from manifest import Manifest
original_manifest=Manifest.read_all((R/'Dauntless_1.14.7.647472.manifest').read_bytes())
manifest['original_sha1']={f.filename:f.hash.hex() for f in original_manifest.file_manifest_list.elements if f.filename in ['Archon/Binaries/Win64/Dauntless-Win64-Shipping.exe','Archon/Content/Paks/Archon_Intl_0-WindowsClient.pak']}
manifest['original_paks']=[f.filename.rsplit('/',1)[-1] for f in original_manifest.file_manifest_list.elements if f.filename.startswith('Archon/Content/Paks/') and f.filename.endswith('.pak')]
(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'cultures':len(reports),'entries_added_per_culture':[x['added_fallback_entries']for x in reports],'pak_bytes':len(data)},indent=2))
