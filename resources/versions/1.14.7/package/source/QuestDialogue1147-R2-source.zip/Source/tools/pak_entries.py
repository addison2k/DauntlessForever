# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import sys,struct,hashlib,zlib,json,concurrent.futures
sys.path.insert(0,str(Path(__file__).resolve().parent/'deps'));import ooz
sys.path.insert(0,str(Path(__file__).resolve().parent));from fetch_ranges import read,getfile,ROOT

def entry(b,o=0):
 start=o;offset,size,raw,method=struct.unpack_from('<QQQI',b,o);o+=28;digest=b[o:o+20];o+=20;blocks=[]
 if method:
  count=struct.unpack_from('<I',b,o)[0];o+=4
  for _ in range(count):blocks.append(struct.unpack_from('<QQ',b,o));o+=16
 flags=b[o];blocksize=struct.unpack_from('<I',b,o+1)[0];o+=5
 return dict(offset=offset,size=size,raw=raw,method=method,digest=digest,blocks=blocks,flags=flags,blocksize=blocksize,header=o-start)

def extract(row):
 asset=row['asset'];out=ROOT/'assets'/asset.removeprefix('../../../')
 if out.exists():return out
 encoded=(ROOT/'indexes'/(row['pak']+'.encoded')).read_bytes();pos=row['encoded_offset'];assert pos>=0
 flags=struct.unpack_from('<I',encoded,pos)[0];pos+=4
 if flags&63==63:pos+=4
 off=struct.unpack_from('<I'if flags>>31 else'<Q',encoded,pos)[0]
 f=getfile(row['pak']);header=read(f,off,min(4096,f.file_size-off));e=entry(header);assert e['offset']in(0,off);assert not e['flags']&1
 data=read(f,off,e['header']+e['size']);assert hashlib.sha1(data[e['header']:]).digest()==e['digest']
 if e['method']==0:raw=data[e['header']:]
 else:
  assert e['method']in(1,2),e
  pieces=[];remaining=e['raw']
  for a,b in e['blocks']:
   n=min(remaining,e['blocksize'])
   pieces.append(ooz.decompress(data[a:b],n)if e['method']==1 else zlib.decompress(data[a:b]));remaining-=n
  assert remaining==0
  raw=b''.join(pieces)
 assert len(raw)==e['raw'];out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
 print(asset,len(raw),flush=True);return out

def rows():return [r for p in (ROOT/'indexes').glob('*.rows.json')for r in json.loads(p.read_text())]
if __name__=='__main__':
 needles=sys.argv[1:];selected=[r for r in rows()if any(n.lower()in r['asset'].lower()for n in needles)]
 with concurrent.futures.ThreadPoolExecutor(max_workers=5)as ex:list(ex.map(extract,selected))
