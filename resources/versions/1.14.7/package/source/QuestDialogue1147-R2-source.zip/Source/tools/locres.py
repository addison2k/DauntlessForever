# SPDX-License-Identifier: AGPL-3.0-only
import struct,json
from pathlib import Path
class Locres:
 def __init__(self,data):
  self.b=data;self.o=0
  assert data[:16]==bytes.fromhex('0e147475674a03fc4a15909dc3377f1b');self.o=16
  self.version=self.number('B');assert self.version in(1,3)
  string_offset=self.number('q');expected=self.number('I')if self.version==3 else None;count=self.number('I');self.entries=[]
  for _ in range(count):
   nshash=self.number('I')if self.version==3 else None;ns=self.string();num=self.number('I')
   for _ in range(num):
    keyhash=self.number('I')if self.version==3 else None;key=self.string();sourcehash=self.number('I');index=self.number('i');self.entries.append({'namespace':ns,'key':key,'hash':sourcehash,'index':index})
  assert expected is None or len(self.entries)==expected,(len(self.entries),expected)
  assert self.o==string_offset,(self.o,string_offset)
  count=self.number('i');self.strings=[]
  for _ in range(count):
   self.strings.append(self.string())
   if self.version==3:refs=self.number('i')
  assert self.o==len(data),(self.o,len(data))
  for x in self.entries:x['text']=self.strings[x['index']]
 def number(self,kind):v=struct.unpack_from('<'+kind,self.b,self.o)[0];self.o+=struct.calcsize('<'+kind);return v
 def string(self):
  n=self.number('i');size=-n*2 if n<0 else n
  b=self.b[self.o:self.o+size];self.o+=size
  return b[:-(2 if n<0 else 1)].decode('utf-16le'if n<0 else'utf-8')if n else''
if __name__=='__main__':
 p=Path(__file__).resolve().parent.parent/'assets/Archon/Content/Localization/Game/en/Game.locres';l=Locres(p.read_bytes());print(len(l.entries),'entries',len(l.strings),'texts');ns=sorted(set(x['namespace']for x in l.entries if 'Dialog'in x['namespace']));print('\n'.join(ns));print(json.dumps([x for x in l.entries if 'CR20_PJM_FTUE_01'in x['key']],indent=2,ensure_ascii=False))
 (p.parent/'Game.decoded.json').write_text(json.dumps(l.entries,indent=2,ensure_ascii=False))
