# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import sys,json,collections
sys.path.insert(0,str(Path(__file__).resolve().parent));from ue_asset import Asset
from locres import Locres
R=Path(__file__).resolve().parent.parent;out=R/'audit';out.mkdir(exist_ok=True)
l=Locres((R/'assets/Archon/Content/Localization/Game/en/Game.locres').read_bytes());bykey=collections.defaultdict(list)
for e in l.entries:bykey[e['key']].append(e)
quests=[];references=[];errors=[];series=[]
for p in sorted((R/'assets/Archon/Content/Gameplay/quests').glob('*.uasset')):
 try:a=Asset(p);exports=a.decode()
 except Exception as err:errors.append({'file':p.name,'error':str(err)});continue
 for e in exports:
  if 'error'in e:errors.append({'file':p.name,'export':e['name'],'error':e['error']});continue
  fields={f['path']:f.get('value')for f in e['fields']if 'value'in f}
  if '/QuestsObject'in fields:series.append({'asset':p.name,'classification':fields.get('/Classification'),'quest_exports':fields['/QuestsObject']})
  questid=fields.get('/QuestID');owner=e
  visited=set()
  while not questid and owner['outer_index']>0 and owner['index']not in visited:
   visited.add(owner['index']);owner=exports[owner['outer_index']-1];questid=next((f.get('value')for f in owner.get('fields',[])if f['path']=='/QuestID'),None)
  if '/QuestID'in fields:
   title=fields.get('/Title',{});ts=bykey.get(title.get('key',''),[])if isinstance(title,dict)else[]
   quests.append({'series':p.stem,'id':questid,'title':ts[0]['text']if ts else None,'offer_npc':a.object(fields.get('/OriginatorInEditor',0)),'turnin_npc':a.object(fields.get('/RedeemerInEditor',0)),'auto_start':fields.get('/AutoStartQuestID'),'fields':fields})
  for f in e['fields']:
   if f['type']=='TextProperty'and isinstance(f.get('value'),dict)and f['value'].get('key'):
    v=f['value'];references.append({'series':p.stem,'quest':questid,'export':e['name'],'property':f['path'],'kind':'standard','table':v.get('table',v.get('namespace')),'key':v['key'],'matches':len(bykey.get(v['key'],[])),'source':v.get('source')})
   if f['path'].endswith('/StringTableKey')and f.get('value'):
    key=f['value'];base=f['path'][:-len('StringTableKey')];table=fields.get(base+'StringTableId');hits=bykey.get(key,[]);neutral=[x for x in hits if x['namespace'].startswith('Dauntless Dialog')and x['namespace'].endswith('Addressee: Neutral')];missing=[x for x in hits if x['namespace'].startswith('Dauntless Dialog')and x['namespace'].endswith('Addressee: Unspecified')]
    references.append({'series':p.stem,'quest':questid,'export':e['name'],'property':base,'kind':'gendered','table':table,'key':key,'matches':len(hits),'neutral_variants':len(neutral),'unspecified_variants':len(missing)})
ids=collections.Counter(q['id']for q in quests)
summary={'game':'1.14.7 CL647472','files_examined':len(list((R/'assets/Archon/Content/Gameplay/quests').glob('*.uasset'))),'quest_series':len(series),'quest_records':len(quests),'unique_quest_ids':len(ids),'text_references':len(references),'gendered_references':sum(x['kind']=='gendered'for x in references),'gendered_refs_with_neutral_but_missing_unspecified':sum(x['kind']=='gendered'and x['neutral_variants']>0 and x['unspecified_variants']==0 for x in references),'unresolved_references':sum(x['matches']==0 for x in references),'unresolved_quest_references':sum(x['matches']==0 and x['quest']is not None for x in references),'decode_errors':errors,'duplicate_quest_ids':{k:v for k,v in ids.items()if v>1},'npc_counts':dict(collections.Counter(q['offer_npc']for q in quests))}
for name,data in [('summary',summary),('quests',quests),('text-references',references),('series',series)]: (out/(name+'.json')).write_text(json.dumps(data,indent=2,ensure_ascii=False))
print(json.dumps({k:v for k,v in summary.items()if k!='npc_counts'},indent=2));print('Missing sample',json.dumps([x for x in references if not x['matches']][:8],indent=2))
