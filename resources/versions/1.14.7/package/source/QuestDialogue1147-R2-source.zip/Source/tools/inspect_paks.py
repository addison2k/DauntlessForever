# SPDX-License-Identifier: AGPL-3.0-only
import sys,struct,json,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent));from fetch_ranges import read,getfile,ROOT
out=ROOT/'indexes';out.mkdir(exist_ok=True)
def fstring(b,o):
 n=struct.unpack_from('<i',b,o)[0];o+=4
 size=-n*2 if n<0 else n
 return b[o:o+size-(2 if n<0 else 1)].decode('utf-16le'if n<0 else'utf-8'),o+size

def inspect(name):
 f=getfile(name);tail=read(f,f.file_size-4096,4096);at=tail.rfind(struct.pack('<I',0x5a6f12e1));assert at>=0
 _,ver,off,size=struct.unpack_from('<IIQQ',tail,at)
 print(name,'version',ver,'index',size,flush=True)
 p=out/(name+'.index');ix=p.read_bytes()if p.exists()else read(f,off,size);assert hashlib.sha1(ix).digest()==tail[at+24:at+44];p.write_bytes(ix)
 mount,o=fstring(ix,0);n,seed=struct.unpack_from('<IQ',ix,o);o+=12;directory=None
 for typ in ['pathhash','directory']:
  present=struct.unpack_from('<I',ix,o)[0];o+=4
  if present:
   off,size=struct.unpack_from('<QQ',ix,o);o+=16;h=ix[o:o+20];o+=20
   if typ=='directory':
    p=out/(name+'.directory');directory=p.read_bytes()if p.exists()else read(f,off,size);assert hashlib.sha1(directory).digest()==h;p.write_bytes(directory)
 size=struct.unpack_from('<I',ix,o)[0];o+=4;(out/(name+'.encoded')).write_bytes(ix[o:o+size]);assert directory is not None
 count=struct.unpack_from('<I',directory)[0];pos=4;rows=[]
 for _ in range(count):
  d,pos=fstring(directory,pos);files=struct.unpack_from('<I',directory,pos)[0];pos+=4
  for j in range(files):
   leaf,pos=fstring(directory,pos);e=struct.unpack_from('<i',directory,pos)[0];pos+=4;rows.append({'pak':name,'asset':mount+d+leaf,'encoded_offset':e})
 assert pos==len(directory)
 (out/(name+'.rows.json')).write_text(json.dumps(rows,indent=2));print('entries',len(rows),flush=True)
 for r in rows:
  a=r['asset'].lower()
  if any(k in a for k in ['localization','locres','dialog_cr20_pjm','quests_table','quest_table','quest_definitions']):print(r['asset'],flush=True)
 return rows
if __name__=='__main__':
 for name in sys.argv[1:]:inspect(name)
