# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import sys,urllib.request,struct,zlib,hashlib,json,concurrent.futures,time,threading
from manifest import Manifest
ROOT=Path(__file__).resolve().parent.parent
M=Manifest.read_all((ROOT/'Dauntless_1.14.7.647472.manifest').read_bytes())
BASE='https://epicgames-download1.akamaized.net/Builds/Org/o-krlzxj88qrtb69fredeuaf887bl5az/Jackal/default/'
CACHE=ROOT/'chunks';CACHE.mkdir(exist_ok=True)
locks={};guard=threading.Lock()
def chunk(cp):
 ci=M.chunk_data_list.get_chunk_by_guid(cp.guid_str)
 with guard:lock=locks.setdefault(ci.guid_str,threading.Lock())
 with lock:
  dst=CACHE/(ci.guid_str+'.raw')
  if dst.exists():return dst.read_bytes()
  for attempt in range(3):
   try:
    b=urllib.request.urlopen(BASE+ci.path,timeout=30).read();magic,ver,hs,cs=struct.unpack_from('<IIII',b)
    assert magic==0xb1fe3aa2 and struct.unpack_from('<IIII',b,16)==ci.guid
    flags=b[40];assert not flags&2,'Encrypted chunk'
    raw=zlib.decompress(b[hs:])if flags&1 else b[hs:]
    assert len(raw)==ci.window_size and hashlib.sha1(raw).digest()==ci.sha_hash
    dst.write_bytes(raw);return raw
   except Exception:
    if attempt==2:raise

def getfile(name):return M.file_manifest_list.get_file_by_path('Archon/Content/Paks/'+name)
def read(f,start,length):
 end=start+length;out=[];pos=0
 for cp in f.chunk_parts:
  a=max(start,pos);b=min(end,pos+cp.size)
  if a<b:out.append((cp,a-pos,b-pos))
  pos+=cp.size
 with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:
  pieces=list(pool.map(lambda q:chunk(q[0])[q[0].offset+q[1]:q[0].offset+q[2]],out))
 data=b''.join(pieces);assert len(data)==length
 return data
if __name__=='__main__':
 for num in range(3):
  name=f'Archon_Maps_{num}-WindowsClient.pak';f=getfile(name);b=read(f,f.file_size-1024,1024)
  (ROOT/(name+'.footer')).write_bytes(b)
  at=b.rfind(struct.pack('<I',0x5a6f12e1));print(name,'size',f.file_size,'magic',at,'footer',b[at:at+64].hex(),flush=True)
  if at>=0:
   _,ver,off,size=struct.unpack_from('<IIQQ',b,at);print('version/index',ver,off,size,flush=True)
   ix=read(f,off,size);assert hashlib.sha1(ix).digest()==b[at+24:at+44]
   (ROOT/(name+'.index')).write_bytes(ix);print('index saved',len(ix),flush=True)
