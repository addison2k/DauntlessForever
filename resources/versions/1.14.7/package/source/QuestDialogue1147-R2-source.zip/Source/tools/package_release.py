# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import zipfile,json,hashlib
R=Path(__file__).resolve().parent.parent;P=R/'patch'
def archive(path,items):
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for f,name in items:z.write(f,name)
 with zipfile.ZipFile(path) as z:assert z.testzip() is None
items=[]
for f in sorted((R/'tools').glob('*')):
 if f.suffix in ('.py','.cjs'):items.append((f,'Source/tools/'+f.name))
for f in sorted((R/'assets').rglob('*')):
 if f.is_file() and f.suffix in ('.uasset','.uexp','.locres'):items.append((f,'Source/'+f.relative_to(R).as_posix()))
for f in sorted(P.rglob('*')):
 if f.is_file() and (f.parent==P/'Tools' or f.parent==P and f.suffix in ('.cmd','.txt','.md')):items.append((f,'Source/patch/'+f.relative_to(P).as_posix()))
for name in ['BUILD.md','Dauntless_1.14.7.647472.manifest','Legendary-LICENSE.txt']:items.append((R/name,'Source/'+name))
items.append((P/'LICENSE-AGPL-3.0.txt','Source/LICENSE-AGPL-3.0.txt'))
archive(P/'Source.zip',items)
revision=json.loads((P/'manifest.json').read_text())['revision'];name=f'Quest-Dialogue-1147-Standalone-R{revision}'
# Individual localization files are build/test intermediates, not additional installed files.
items=[(f,name+'/'+f.relative_to(P).as_posix()) for f in sorted(P.rglob('*')) if f.is_file() and not f.is_relative_to(P/'Payload/localization')]
archive(R/(name+'.zip'),items)
b=(R/(name+'.zip')).read_bytes();print(json.dumps({'path':str((R/(name+'.zip')).resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},indent=2))
