Quest Dialogue Fallback 1.14.7 R2 by KombatKing (AGPL-3.0-only).
This is the source of bin\zzzzzzzzzzzzzzzz_QuestDialogueFallback1147_P.pak in the Dauntless Forever 1.14.7 package.
Included: the build, audit, installer and test tools, BUILD.md and the licences.
Left out on purpose: the original game files the tools read (extracted from your own 1.14.7 game, or downloaded
from Epic as BUILD.md explains). Game content keeps its original rights and is not redistributed here.
Unchanged from KombatKing's release except for this file.
