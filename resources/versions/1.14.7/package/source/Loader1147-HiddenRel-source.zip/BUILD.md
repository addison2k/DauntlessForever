# Loader 1.14.7 - hidden relevancy build (Oct 31, 2026)

Source of `bin/dxgi.dll` in the Dauntless Forever 1.14.7 server files.
Copyright (C) 2026 Addison2k. https://github.com/addison2k/DauntlessForever
Licence: AGPL-3.0-only (LICENSE-AGPL-3.0.txt). MinHook by Tsuda Kageyu (BSD-2-Clause, minhook/LICENSE.txt).

Based on: Loader1147-ChatCpu-source (by Addison2k; its BUILD.md lists the earlier changes).

Changed Oct 31, 2026 by GoldenHeartbell (https://github.com/GoldenHeartbell), licensed under AGPL-3.0-only like the
rest of this source. Only d1147.cpp changed (DF-HIDDENREL):
- Server copies no longer open a channel to a player for an actor that is hidden, not always relevant, not that
  player's own, and whose root component has no collision (the engine's IsNetRelevantFor rule). A held-back actor is
  sent once it is shown; actors a player already has keep being sent. D1147_HIDDEN=0 turns it off.
- Why: Kharabak's 20 pooled hidden beams (bugbear_beam_bp) reached every player and each left a free-standing
  bugbear_sourceblast_p behind: a pulsing glow at a fixed spot until that Kharabak died (solo and Forever).

Build (Zig 0.17.0):

    zig c++ -target x86_64-windows-gnu -shared -O2 -o dxgi.dll d1147.cpp minhook/hook.c minhook/buffer.c minhook/trampoline.c minhook/hde/hde64.c -luser32 -lkernel32 -lgdi32
